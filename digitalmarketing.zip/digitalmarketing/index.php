<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

 <title>Digital Marketing </title>
  <meta name="description" content="">
  <meta name="keywords" content="" />
  <meta property="og:title" content="" />
  <meta property="og:description" content="" />
  <meta property="og:image" content="" />

<link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/stylec36f.css?v=1.1.6">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="fonts/fonts.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Global site tag (gtag.js) - Google Ads: 1065360964 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-1065360964"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-1065360964');
</script>
<script type="text/javascript">
$(document).ready(function(){
var position = $(window).scrollTop(); 
$(window).scroll(function() {
   var scroll = $(window).scrollTop();
   if(scroll > position) {
      //  console.log('scrollDown');
        $('.animatefix').addClass('active');
  } else {
       // console.log('scrollUp');
        $('.animatefix').removeClass('active');
   }
   position = scroll;
});
 $(window).bind("resize", function () {
        console.log($(this).width())
        if ($(this).width() < 767) {
            $('.navigation-bx').addClass('navigation-res')
        } else {
            $('.navigation-bx').addClass('navigation-res')
        }
    })

$('.responsive_nav').click(function(){
$('.navigation-bx').slideToggle();
});

//$('.navigation-bx ul li a').click(function(){
//$('.navigation-res').slideToggle();
//});

$('#explore-btn3').click(function(){
		$('body,html').animate({
				scrollTop: $(".web-component2").offset().top-55
			}, 800);
			return false;
									 });
$('#explore-btn4').click(function(){
		$('body,html').animate({
				scrollTop: $(".our-process-bx").offset().top-120
			}, 800);
			return false;
									 });

$('#explore-btn5').click(function(){
		$('body,html').animate({
				scrollTop: $(".about-business-component").offset().top-100
			}, 800);
			return false;
									 });


		
						   });
						   
$(function () {
$("a[href^='tel']").click(function(){
   ga('send', 'event', 'mobile', 'click', 'mobile click');
});

$("a[href^='mailto']").click(function(){
   ga('send', 'event', 'email', 'click', 'email click');
});
});

function callback(){
	var phonenumber = $("#phonenumber").val();
	if(phonenumber.length == 10){
		$.ajax({
			type: "POST",
			url: 'callback.php',
			data: {phone:phonenumber},
			success: function(response){
				
					//ga('send', 'event', 'click-to-call', 'click', 'Click To Call');
					gtag('event', 'conversion', {
					  'send_to': 'AW-1065360964/OdlJCODWxn4QxLyA_AM',
					  'event_callback': 'callback'
				  });
				
				$("#phonenumber").val('');
				$("#invalid_number").html('<i style="color: green;margin-top: 5px;float: left;">We will contact you shortly!</i>');
				$('#invalid_number').delay(3000).fadeOut();
			}
	   });
	} else {
		$("#invalid_number").html('<i style="color: red;margin-top: 5px;float: left;">Please enter valid number.</i>');
		$('#invalid_number').delay(3000).fadeOut();
	}
}
function getDataside(){
	var fdata = $("#formdataside").serialize();
	$.ajax({
		type: "POST",
		url: 'submit.php',
		data: fdata,
		success: function(response){
			//alert(response)
				//ga('send', 'event', 'click-to-call', 'click', 'Click To Call');
				   gtag('event', 'conversion', {
				  'send_to': 'AW-1065360964/OdlJCODWxn4QxLyA_AM',
				  'event_callback': 'Click To Call'
			});
			$("#formdataside")[0].reset();
			$("#responseside").html(response);
		}
   });
}

function getData(){
	var fdata = $("#formdata").serialize();
	$.ajax({
		type: "POST",
		url: 'submit.php',
		data: fdata,
		success: function(response){
			//alert(response)
			gtag('event', 'conversion', {
			  'send_to': 'AW-1065360964/OdlJCODWxn4QxLyA_AM',
			  'event_callback': callback
			});
				  
			$("#formdata")[0].reset();
			$("#response").html(response);
		}
   });
}						   			   
</script>

<!-- Slider Code Starts From Here ************************************************************************************************* -->
  <!-- Feather icons -->
  <script src="https://unpkg.com/feather-icons"></script>

  <!-- Fontawesome icons -->
  <link
    rel="stylesheet"
    href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"  />

  <!-- CSS & Normalize -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css" />
  <link rel="stylesheet" href="Footer-slider/dist/styles.css" />

  <!-- Owl carousel styles -->
  <link rel="stylesheet" href="Footer-slider/dist/owl.carousel.min.css" />

  <!-- Owl caousel & JQuery -->
  <script defer src="Footer-slider/dist/jquery.min.js"></script>
  <script defer src="Footer-slider/dist/owl.carousel.min.js"></script>

  <!-- JS -->
  <script defer src="Footer-slider/dist/script.js"></script>
<!-- Slider Ends Here ************************************************************************************************************* -->


</head>
<body>
<div class="wrapper">
  <div class="sticky-enq"><a href="#" data-toggle="modal" data-target="#myModal">ENQUIRE NOW</a></div>
  <div class="animatefix">
    <div class="container-fluid">
      <div class="head-component">
        <div class="sticky-logo"><img alt="" src="images/logo.png"></div>
        <div class="sticky-phone">
          <p> <!--span>Call Us:</span--><i class="fa fa-phone" style="font-size: 17px;"></i> <a href="tel:+918299125762" style="text-decoration: none; font-size: 14px;">+91-8299125762</a> </p>
          <p> <!--span>Write Us: </span--><i class="fa fa-envelope" style="font-size: 17px;"></i> <a class="email" href="mailto:gw17092019@gmail.com" style="text-decoration: none; font-size: 14px;">gw17092019@gmail.com</a> </p>
        </div>
        <div class="call-btn"><a href="tel:+918299125762">+91-8299125762</a></div>
        <div class="responsive_nav">
          <button><i class="fa fa-bars" aria-hidden="true" style="margin: 4px 8px 4px 9px;"></i></button>
        </div>
        <div class="navigation-bx">
          <ul>
            <li><a href="javascript:void(0);" id="explore-btn3">Services</a></li>
            <li><a href="javascript:void(0);" id="explore-btn4">Process</a></li>
            <li><a href="javascript:void(0);" id="explore-btn5">About Us</a></li>
            <li><a href="#vsl-sp">Clients</a></li>
			<li><a href="https://rzp.io/l/1ZWTc1Nsq7">Pay Now</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <section class="app-section-content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 col-sm-8 col-lg-8">
          <div class="banner-info-component">
            <div class="banenr-slides-app">
              <div id="myCarousel3" class="carousel slide" data-ride="carousel"  data-interval="2500">
                <div class="carousel-inner">
               
                  <div class="item active">
                    <h2>Take Your Business to the Next Level. Improve Your<span> Online Visibility</span>   </h2>
                   <p style="color: black;">Whether you are striving for more visitor traffic on your website or increased brand visibility, our <b>performance-based digital marketing</b> solutions can help. </p>  <div class="sc-counting">
                      <ul>
                        <li>More Customers</li>
                        <li>More Sales</li>
                        <li>More Revenue</li>
                      </ul>
                    </div>
                     
                  </div>
                     <div class="item">   
                    <h2>Promote your Business across <span>Digital Marketing Channels</span></h2>
                    <p  style="color: black;">We build and manage online marketing campaigns to engage your customers across channels including <b>search engine, social media, mobile marketing, and display ads.</b> </p>
                 <div class="dis-ads-ic"><img src="images/display-ads-icon.png" style="width: 250px;"></div>
                  </div>
                  <div class="item">
                    <h2> Assured Business Growth via<span> Performance Driven Digital Marketing </span> </h2>
                    <p  style="color: black;">Our performance marketing strategies ensure that new customers can find your business in the online space. We assure you of<b>  business growth </b>by improving your brand’s visibility.</p>
                    <div class="dis-ads-ic"><img src="images/doller-icon.png" style="width: 50px;"></div>
                  </div>
                </div>
                <ol class="carousel-indicators">
                  <li data-target="#myCarousel3" data-slide-to="0" class="active"></li>
                  <li data-target="#myCarousel3" data-slide-to="1"></li>
                  <li data-target="#myCarousel3" data-slide-to="2"></li>
                </ol>
              </div>
            </div>
          </div>
        </div>
        <!--div class="mb-price">
          <h3>Plans <span>Start @</span></h3>
           <div class="br-price">INR 12,999/m</div>
        </div-->
        <div class="col-md-4 col-sm-4 col-lg-4">
          <div class="quick-contact-form">
            <h2>Enquire Now</h2>
            <p>Fill out the information below and we will
              call you soon</p>
            <form method="POST" action="https://formsubmit.co/gw17092019@gmail.com" id="formdata">
              <div class="form-fields">
                <input type="text" value="" name="name" placeholder="NAME *" class="fields" required>
              </div>
              <div class="form-fields">
                <input type="text" value="" name="mobile" placeholder="MOBILE *" class="fields" required>
              </div>
              <div class="form-fields">
                <input type="text" value="" name="email" placeholder="EMAIL *" class="fields" required>
              </div>
              <!--div class="form-fields">
                <select name="service">
                  <option value="">Select Service</option>
                  <option value="Search Engine Optimization">Search Engine Optimization</option>
                  <option value="Social Media Marketing">Social Media Marketing</option>
                  <option value="Display Ads">Display Ads</option>
                  <option value="Email Marketing">Email Marketing</option>
                  <option value="SMS Marketing">SMS Marketing</option>
                  <option value="Analytics">Analytics</option>
                </select>
              </div-->
              <div class="form-fields">
                <textarea class="msgbx" name="comments" placeholder="MESSAGE"></textarea>
              </div>
              <div class="form-fields text-center">
                <button type="submit">SUBMIT</button>
              </div>
            </form>
            <div class="ft-note" id="response"></div>
            <div class="ft-note">*All the information will be treated as confidential</div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="call-back-section">
    <div class="container">
      <div class="call-back-action">
        <div class="row">
          <div class="col-md-4">
            <h4>5 MINUTES <span>Call Back</span></h4>
          </div>
          <div class="col-md-8">
            <div class="select-country-code-field">
              <select>
                <option>+91</option>
              </select>
              <div class="phone-num-field">
                <form action="https://formsubmit.co/gw17092019@gmail.com" method="post">
                <input type="number" value="" name="phonenumber" id="phonenumber" placeholder="Type Your Number" required>
                <button type="submit" onClick="callback();">Call Me</button>
              </form>
                <span id="invalid_number"></span> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="web-component1">
    <div class="container">
      <div class="section-head">
        <h2>Performance Driven <span>Digital Marketing</span> Solutions</h2>
        <div class="we-help">10X Your Organic Website Traffic </div>
      </div>
      <div class="row">
        <div class="col-md-10">      <p>Digital Marketing Services is a result-driven performance marketing agency with focus on 100% 
          measurable returns.  our performance-based marketing plans will always deliver the results you pay for. Strategies built 
          around individual mediums don't necessarily have a huge impact. Thus, we use them in conjunction to create a more influential
           online presence.  Our team <strong>combines technology and communication mediums to ideate, create and optimize 
             performance-centric campaigns that reduce risks involved and deliver higher ROI.</strong> No matter the size of your 
             organization, we make sure that every dollar spent on advertising work and maximize your overall return on investment.
            </p></div>
        <div class="col-md-2">
         <img src="images/plans-str.png" alt="plans">
        </div>
      </div>

    </div>
  </section>
  <style>
    .imgWidth
    {
      width: 80px;
    }
  </style>
  <section class="web-component2">
    <div class="container">
      <div class="section-head">
        <h2><span>Integrated </span> Digital Marketing Channels</h2>
        <div class="we-help">Be Found. Be Heard</div>
      </div>
      <div class="integrated-service">
        <div class="row">
          <div class="col-md-4 col-sm-6">
            <div class="service--item p1">
              <figure><img src="images/Search-Engine-Optimization.png" class="imgWidth"></figure>
              <h3><span>Search Engine</span> Optimization </h3>
              <p>Get into the top of the search results for most competitive keywords. Drive traffic and boost conversion. </p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="service--item">
              <figure><img src="images/Social-Media-Marketing.png" class="imgWidth"></figure>
              <h3><span>Social Media </span> Marketing </h3>
              <p>Engage and connect with your audience on premium social networks. Enhance your brand visibility. </p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="service--item p1">
              <figure><img src="images/display-ads-icon3.png" style="width: 56px;"></figure>
              <h3><span>Display</span> Ads </h3>
              <p>Get highly targeted traffic that converts into leads and translates into paying customers. Scale your business growth.</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="service--item">
              <figure><img src="images/Email-Marketing.png" class="imgWidth"></figure>
              <h3><span>Email </span> Marketing </h3>
              <p>Drive more customer engagement with highly converting email campaigns with guaranteed inbox delivery.</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="service--item p1">
              <figure><img src="images/sms-marketing.png" class="imgWidth"></figure>
              <h3><span>SMS </span> Marketing </h3>
              <p>Reach your targeted customers on mobile and drive massive engagement at scale.</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="service--item">
              <figure><img src="images/Analytics.png" class="imgWidth"></figure>
              <h3><span>Analytics </span> </h3>
              <p>Measure performance to make the right decisions and drive your business Forward. </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <section class="web-component2" style="background-color: #E8E7E7;">
    <div class="container">
      <div class="section-head">
        <h2><span>We </span> Love to develope</h2>
        <div class="we-help">Create, curate, teach.</div>
      </div>
      <div class="integrated-service">
        <div class="row">
          <div class="col-md-4 col-sm-6">
            <div class="service--item p1">
              <figure><i class="fa fa-globe" style="color: #A70000; font-size: 60px;"></i></figure>
              <h3><span>Web</span> Development </h3>
              <p>Web development is the work involved in developing a website for the Internet  (World Wide Web). </p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="service--item">
              <figure><i class="fa fa-android" style="color: #A70000; font-size: 60px;"></i></figure>
              <h3><span>Android App </span> Development </h3>
              <p>Develop the app your business needs today. Get a guaranteed price and timeline up front. </p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6">
            <div class="service--item p1">
              <figure><i class="fa fa-bullhorn" style="color: #A70000; font-size: 60px;"></i></figure>
              <h3><span>Digital Marketing</span> Entern </h3>
              <p>Any strategy that gets a message to rise above the clutter is terrific from the advertiser's perspective. </p>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </section>



  <section class="web-component2">
    <div class="container">
      <div class="section-head">
        <h2><span></span> Markting Process </h2>
        <div class="we-help">Good marketing makes the company look smart.</div>
      </div>
      <div class="integrated-service">
        <div class="row">
          <div class="col-md-3 col-sm-6">
            <div class="service--item">
              <figure><img src="images/1M.png" alt=""></figure>
              <h3><span></span> Marketing Products </h3>
              <p></p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="service--item">
              <figure><img src="images/2M.png" alt=""></figure>
              <h3><span></span> Advertising Agency </h3>
              <p> </p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="service--item">
              <figure><img src="images/1M.png" alt=""></i></figure>
              <h3><span></span> <br> Process Planning </h3>
              <p> </p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <div class="service--item">
              <figure><img src="images/2M.png" alt=""></i></figure>
              <h3><span></span><br> Product Sales </h3>
              <p> </p>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </section>



  <section class="web-component3 text-center">
  <div class="container">
    <div class="section-head">
      <h2><span>Strategies</span> to Get You Growing</h2>
    </div>
    <div class="key-pillers">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <ul>
            <li class="e1"><span>Effective</span><br>
              Brand Communication</li>
            <li class="e2">Targeting<br>
              <span>Right</span> Audience</li>
            <li class="e3"><span>Reliable</span><br>
              Conversion Strategies</li>
          </ul>
        </div>
        <div class="col-md-6 col-sm-6">
          <figure><img src="images/key-pillers-img.jpg" style="width: 300px;"></figure>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="web-component4">
  <div class="container">
    <div class="our-process-bx">
      <div class="section-head text-center">
        <h2>ROI Driven Digital Marketing <span>Process</span></h2>
      </div>
      <ul>
        <li>
          <figure><img src="images/goal-analysis.jpg"></figure>
          <h3>Goal Analysis</h3>
        </li>
        <li>
          <figure><img src="images/Audience-Research.jpg"></figure>
          <h3> Audience Research</h3>
        </li>
        <li>
          <figure><img src="images/Competition-Analysis.jpg"></figure>
          <h3>Competition Analysis</h3>
        </li>
        <li>
          <figure><img src="images/Finding-Channels.jpg"></figure>
          <h3>Finding Channels</h3>
        </li>
        <li>
          <figure><img src="images/Creating-Content.jpg"></figure>
          <h3>Creating Content</h3>
        </li>
        <li>
          <figure><img src="images/Measuring-Results.jpg"></figure>
          <h3>Measuring Results</h3>
        </li>
      </ul>
    </div>
    <!-- div class="app-number-component">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="nm-component" >
            <h3 style="border-left: 5px solid #AF0C0C;"><span>Numbers</span> Speak</h3>
            <ol>
              <li>
                <h4>3500+</h4>
                <p><span>Clients</span> Served</p>
              </li>
              <li>
                <h4>5000+</h4>
                <p><span>Project </span> Handled</p>
              </li>
              <li>
                <h4>120 CR+</h4>
                <p><span>Budget</span> Managed</p>
              </li>
              <li>
                <h4>98.99%</h4>
                <p>Client <span>Retention</span></p>
              </li>
            </ol>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="nm-component" style=" border:3px solid #3c3c3c">
            <h3>We Are in <span>Nutshell</span></h3>
            <ol>
              <li>
                <h4>20+</h4>
                <p><span>Years</span> in Business</p>
              </li>
              <li>
                <h4>200+</h4>
                <p>Strong <span>Team </span></p>
              </li>
              <li>
                <h4>15+</h4>
                <p><span>Countries</span> Covered</p>
              </li>
              <li>
                <h4>10+</h4>
                <p><span>Affiliations</span></p>
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div-->
    
    <div class="about-business-component">
      <div class="row">
        <br><br>
        <div class="col-md-5 col-sm-5">
          <figure><img src="images/group-team.jpg"></figure>
        </div>
        <div class="col-md-7 col-sm-7">
          <h3>DigitalMarketingServices: <span>Empowering</span> Businesses <span>Since 2017</span></h3>
          <p> Started in 2017, DigitalMarketingServices has so far helped several thousands of online businesses with digital solutions specially designed to address their business challenges.  Our performance based digital marketing plans are a perfect mix of team, strategy and process that <strong>helps brands to identify real-time opportunities, connect with their target audience and acquire new customers.</strong> If you’re looking for a digital marketing  agency to improve your search rankings, increase your reach or generate business leads, we are a perfect fit.  We have a range of integrated digital marketing plans on offer. Choose the best without being locked into a long-term contract. </p>
        </div>
      </div>
    </div>
    <!--div class="about-business-sp">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="clients-st">
            <h3>Our Esteemed <span>Clients</span></h3>
            <figure><img src="images/clients-img.jpg"></figure>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="testimonial-bx">
            <h3>Clients’ <span>Speak </span></h3>
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
                <div class="item active">
                  <p>I am really happy that that keywords are ranking high. But, we should get all keywords at ranking #1. I know you people will work on fast track. Thanks for doing such a great job. Your SEO team handled the project very professionally and devoted efforts honestly.</p>
                  <span class="name">JC Das</span> </div>
                <div class="item ">
                  <p>Hi All, I see that the rankings are recovering. Brilliant. Keep up the good work. PGS backs to number 1 soon for Promotional Gifts. Your hard work starts converting into the visible results. I appreciate the level of dedication you people put in the project. Thanks for that rock solid results.</p>
                  <span class="name">Robin Koffler</span> </div>
                <div class="item">
                  <p>Good work ! I can see the same ! We are only 1 month in as well which is excellent Keep up the good work. You people worked really well, and of course, results are encouraging. Your dedicated efforts are commendable. Keep doing that level of work folks.</p>
                  <span class="name">Hackney Richard</span> </div>
              </div>
              <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div-->
  </div>
</section>


<!-- Footer slider Start ********************************************************************************************************************* -->
<div class="container-fluid" style="padding: 0px;">

 
  <div class="clients-st">
    <h3 >&nbsp; Our Esteemed <span style="color: #FACB0D;">Clients</span></h3>
    
    <footer class="footer" id="vsl-sp">
      <div class="owl-carousel">
        <a href="#" class="gallery__photo">
          <img src="Footer-slider/app/img/1.png" alt="" />
          <div class="gallery__fade">
            <i class="gallery__icon" data-feather="instagram"></i>
          </div>
        </a>
        <a href="#" class="gallery__photo">
          <img src="Footer-slider/app/img/2.png" alt="" />
          <div class="gallery__fade">
            <i class="gallery__icon" data-feather="instagram"></i>
          </div>
        </a>
        <a href="#" class="gallery__photo">
          <img src="Footer-slider/app/img/3.png" alt="" />
          <div class="gallery__fade">
            <i class="gallery__icon" data-feather="instagram"></i>
          </div>
        </a>
        <a href="#" class="gallery__photo">
          <img src="Footer-slider/app/img/4.png" alt="" />
          <div class="gallery__fade">
            <i class="gallery__icon" data-feather="instagram"></i>
          </div>
        </a>
        <a href="#" class="gallery__photo">
          <img src="Footer-slider/app/img/5.png" alt="" />
          <div class="gallery__fade">
            <i class="gallery__icon" data-feather="instagram"></i>
          </div>
        </a>
        <a href="#" class="gallery__photo">
          <img src="Footer-slider/app/img/6.png" alt="" />
          <div class="gallery__fade">
            <i class="gallery__icon" data-feather="instagram"></i>
          </div>
        </a>
        <a href="#" class="gallery__photo">
          <img src="Footer-slider/app/img/7.png" alt="" />
          <div class="gallery__fade">
            <i class="gallery__icon" data-feather="instagram"></i>
          </div>
        </a>
      </div>
      
    </footer>
  </div>
</div>
<!-- //Footer slider Ends ********************************************************************************************************************* -->

<div class="copyrightinfo">
  <!--p class="address"><i class="fa fa-map-marker" aria-hidden="true"></i> 
    C-102, sector 65 Noida  Uttar Pradesh  201301 - India</p--> &copy; 2022 Genoviqweb Pvt. Ltd. All Rights Reserved.
  </div>
</div>
<div class="sticky-footer" >
  <div class="sticky-phone"><a class="mobile-num" href="tel:08527795844"><img src="images/stk-phone.html" alt="phone"> +91-8527795844</a><a href="mailto:sales@brainpulse.com" class="email"><img src="images/email-icon2.html" alt="email"> sales@brainpulse.com</a></div>
</div>
<div id="myModal" class="modal model-bx fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <button type="button" class="close" data-dismiss="modal">&times;</button>
      <div class="modal-body">
        <div class="quick-contact-form">
          <h2>Enquire Now</h2>
          <p>Fill out the information below and we will
            call you soon</p>
          <form method="POST" action="https://formsubmit.co/gw17092019@gmail.com" id="formdataside">
            <div class="form-fields">
              <input type="text" value="" name="name" placeholder="NAME *" class="fields" required>
            </div>
            <div class="form-fields">
              <input type="text" value="" name="mobile" placeholder="MOBILE *" class="fields" required>
            </div>
            <div class="form-fields">
              <input type="text" value="" name="email" placeholder="EMAIL *" class="fields" required>
            </div>
            <!--div class="form-fields">
              <select name="service">
                <option value="">Select Service</option>
                <option value="Search Engine Optimization">Search Engine Optimization</option>
                <option value="Social Media Marketing">Social Media Marketing</option>
                <option value="Display Ads">Display Ads</option>
                <option value="Email Marketing">Email Marketing</option>
                <option value="SMS Marketing">SMS Marketing</option>
                <option value="Analytics">Analytics</option>
              </select>
            </div-->
            <div class="form-fields">
              <textarea class="msgbx" name="comments" placeholder="MESSAGE *" required></textarea>
            </div>
            <div class="form-fields text-center">
              <button type="submit" onClick="getDataside();">SUBMIT</button>
            </div>
          </form>
          <div class="ft-note" id="responseside"></div>
          <div class="ft-note">*All the information will be treated as confidential</div>
        </div>
      </div>
    </div>
  </div>
</div>


<script> document.addEventListener("contextmenu", function(e){ e.preventDefault(); }, false); </script>
</body>

</html>
