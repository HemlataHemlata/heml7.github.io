<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enquiry_Form</title>
    <?php
include('includes/link.php');
?>
</head>
<body>
    <!-- Start Top Header -->
    <?php
     include('includes/top_header.php');
     ?>
    <!-- End Top Header -->

    <!-- Start Main Menu -->
     <?php
     include('includes/header.php');
     ?>
    <!-- End Main Menu -->

    <?php
    include('includes/mobile_header.php');
    ?>
    <style>
       
.credit-card{
 background-color: #f4f4f4;
  height: 100vh;
  width: 100%;
  
  display: flex;
  flex-direction: column;
  /* justify-content: center; */
  align-items: center;
}
.card-holder {
  margin: 2em 0;
}

.img-box {
 padding-top: 20px;    
 display: flex;
 justify-content: center;
}
.card-box {
  font-weight: 800;
  /* padding: 1em 1em; */
  border-radius: 0.25em;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}
.bg-news {
  background: -webkit-linear-gradient(70deg, #ee050b 40%, #ffffff 40%);
  background: -o-linear-gradient(70deg, #ee050b 40%, #ffffff 40%);
  background: -moz-linear-gradient(70deg, #ee050b 40%, #ffffff 40%);
  background: linear-gradient(70deg, #ee050b 40%, #ffffff 40%);
}
.btn-primary{
 background-image: -webkit-linear-gradient(315deg, #ee050b 0%, #fd8965 100%);
background-image: -moz- oldlinear-gradient(315deg, #ee050b 0%, #fd8965 100%);
background-image: -o-linear-gradient(315deg, #ee050b 0%, #fd8965 100%);
background-image: linear-gradient(135deg, #ee050b 0%, #fd8965 100%);
-webkit-filter: hue-rotate(0deg);
filter: hue-rotate(0deg);
border: none !important;
}

.credit-card form{
	background-color: #ffffff;
	padding: 0;
	max-width: 600px;
	margin: auto;
}

.credit-card .title{
	font-family: 'Abhaya Libre', serif;
	font-size: 2em;
	color: #2C3E50;
	border-bottom: 1px solid rgba(0,0,0,0.1);
	margin-bottom: 0.8em;
	font-weight: 600;
	padding-bottom: 8px;
}
.credit-card .card-details{
	padding: 25px 25px 15px;
}

.inner-addon {
  position: relative;
}

.inner-addon .fas, .inner-addon .far {
  position: absolute;
  padding: 10px;
  pointer-events: none;
  color: #bcbdbd !important;
}
.right-addon .fas, .right-addon .far { right: 0px; top: 40px;}
.right-addon input { padding-right: 30px; }

.credit-card .card-details label{
	font-family: 'Abhaya Libre', serif;
	font-size: 14px;
	font-weight: 400;
	margin-bottom: 15px;
	color: #79818a;
	text-transform: uppercase;
}

.credit-card .card-details input[type="text"] {
	font-family: "Poppins", sans-serif;
	font-size: 16px;
	font-weight: 500;
	padding: 10px 10px 10px 5px;
	/* -webkit-appearance: none; */
	display: block;
	background: #fafafa;
	color: #636363;
	border: none;
	border-radius: 0;
	border-bottom: 1px solid #757575;	
}
.credit-card .card-details input[type="text"]:focus { outline: none; }

.credit-card .card-details button{
	margin-top: 0.6em;
	padding:12px 0;
	font-weight: 600;
}

.credit-card .date-separator{
 	margin-left: 10px;
    margin-right: 10px;
    margin-top: 5px;
}

@media (max-width: 768px) {
	.credit-card{
	  /* height: 250vh; */
	  width: 100%;
	}
	.credit-card .title {
		font-size: 1.2em; 
	}

	/* .credit-card .row .col-lg-6 {
		margin-bottom: 40px; 
  	} */
  	.credit-card .card-details {
    	padding: 40px 40px 30px; 
    }

  	.credit-card .card-details button {
    	margin-top: 2em; 
    } 
}
    </style>
<section class="credit-card">
		 <div class="container">
		  
			<div class="card-holder " >
			  <div class="card-box bg-news">
		       <div class="row">
				<div class="col-lg-6">
				 <div class="img-box">
				   <img src="assets/images/cta-men.png" class="img-fluid" data-aos="zoom-in-up" />
				 </div>
				</div>
				<div class="col-lg-6">
				
				<form action="https://formsubmit.co/bookashoktravels@gmail.com" method="POST" > 
					<input type="hidden" name="_subject" value="New Enquiry!"> 
				  <div class="card-details">
					<h3 class="title" data-aos="zoom-in"> Make contact</h3>
					<div class="row" data-aos="zoom-out-down">
					  <div class="form-group col-sm-12">
					   <div class="inner-addon right-addon">
						<!-- <label for="card-holder">Name</label> -->
                        <!-- <i class="fa fa-user"></i> -->
						<input id="card-holder" type="text" name="name" class="form-control" placeholder="Enter Your Name" required >
					   </div>	
					  </div>
					  <div class="form-group col-sm-12">
					   <div class="inner-addon right-addon">
						<!-- <label for="card-number">Card Number</label> -->
                        <!-- <i class="far fa-credit-card"></i> -->
						<input id="card-number" type="text" name="number" class="form-control" placeholder="Enter Your  Number" required >
					   </div>	
					  </div>
                      <div class="form-group col-sm-12">
						  <textarea id="cvc"  type="text" name="message" class="form-control" placeholder="Enter Message Here..." rows="4" cols="50" ></textarea>
					  </div>
                      
					  <div class="form-group col-sm-12" data-aos="fade-up">
                      <input type="hidden" class="box-div" name="-" value="send enquiry" />                    
        
        <input type="hidden" name="_captcha" value="false">
        <input type="hidden" name="_template" value="box">
        <input type="hidden" name="_next" value="https://ashoktravelsvns.com/welcome">
						<button type="submit" class="btn btn-primary btn-block" value="submit" >Proceed</button>
					  </div>
					</div>
				  </div>
				</form>				
				
				</div><!--/col-lg-6 --> 
		  
		       </div><!--/row -->
			  </div><!--/card-box -->
			</div><!--/card-holder -->		 
			
		 </div><!--/container -->
		</section>
        <!-- Start Footer Area -->
     <?php
     include('includes/footer.php');
     ?>
    <!-- End Footer Area -->
<!-- icons start -->
<?php
     require('includes/sociallinks.php');
     ?>
 <!-- icons end -->
        <!-- jQuery min js -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <!-- Bootstrap JS file -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Popper JS -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Owl-Carousel JS file -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Slick-Nav JS file -->
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <!-- Magnific Popup JS file -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Mixitup JS file -->
    <script src="assets/js/mixitup.min.js"></script>
    <!-- WOW JS file -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Jquery Counterup JS file -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Waypoints JS file -->
    <script src="assets/js/waypoints.min.js"></script>
    <!-- Custom JS file -->
    <script src="assets/js/active.js"></script>

</body>
</html>