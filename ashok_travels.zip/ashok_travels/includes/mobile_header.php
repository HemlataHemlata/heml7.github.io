<nav class="navbar navbar-expand-md n-ds-none">
        <!-- Brand -->
        <a class="navbar-brand" href="index">
            <img src="assets/img/Ashok-Travel-logo.png" class="img-logoone mob-view" alt="logoone">
        </a>

        <!-- Toggler/collapsibe Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <i class="fa fa-bars"></i>
        </button>

        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index#about">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index#service">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="other">Other</a>
                </li>
                <li class="nav-item">
                    <!-- <a class="nav-link" href="enquiry">Enquire</a> -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="enquiry">Contact</a>
                </li>
            </ul>
        </div>
    </nav>