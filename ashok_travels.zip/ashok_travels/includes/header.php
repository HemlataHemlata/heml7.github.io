<div class="mainmenu-area mble-hddn" >
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3">
                    <div class="logoone">
                        <a href="index">
                            <img src="assets/img/Ashok-Travel-logo.png" class="img-logoone" alt="eventer logo" style="width: 245px;">
                        </a>
                    </div>
                    <!-- Responsive Menu -->
                    <div class="responsive-menu-wrap"></div>
                </div>
                <div class="col-lg-9">
                    <div class="mainmenu">
                        <ul id="navigation">
                            <li class="active"><a href="index">Home</a></li>
                            <li><a href="index#about">About</a></li>
                            <li><a href="index#service">Services</a></li>
                            <li><a href="other">Other</a></li>
<!--                            <li><a href="index#contact-us">Contact</a></li>-->
                            <li><a href="enquiry">Contact</a></li>
                            <!-- <li class="header-callButton"><a href="tel:9555976325" class="custum-btn"><i
                                        class="fa fa-phone"></i> Call Now <i class="fa fa-arrow-right"></i></a></li> -->
                        </ul>
                    </div>
                    
                    

                </div>
            </div>
        </div>
    </div> 

