<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="car rent agency, car rent agency near me, petani agency rent a car, best rental car agency, car rental agency for rent, can you rent a car rental agency, budget rent a car travel agency, car rental agency america, car rental agency airport, car rental agency all, car rental agency alternatives, a car rental agency has 20 cars, a car rental agency, car rental agency brands, car rental agency best, car rental agencies bandra, car rental agency names, car rental agency calgary, tour and travel, logo tour and travel, tour and travel agency, ashok tour and travel, tour and travel agency near me, tour and travel advertisement, tour and travel agent, ashok tour and travel reviews, all india tour and travel reviews, tour and travel banner, tour and travel varanasi, tour and travel bus, tour and travel business card, best tour and travel company, tour and travel companies in varanasi, tour and travel company near me, tour and travel course online, tour and travel card, tour and travel difference, difference between tour and travel, destination vacation tour and travel varanasi, discovery tour and travel, tour and travel exhibition, tour and travel essay, executive tour and travel, 8573958805, 9555976325, Umraha Babatpur, Varanasi, Ashok-Travel, ashoktravels, bookashoktravels@gmail.com, Enquire, travelling, travelling or traveling, sisterhood of the travelling pants, benefits of travelling, best wishes for travelling abroad, travelling alone, travelling accessories, travelling around the world, travelling abroad checklist, about travelling essay, about travelling quotes, travelling bag, travelling backpack, travelling bags for sale, travelling box, travelling bag for men, backpack for travelling, good travelling, best travelling backpack, best budget camera for travelling, best camera for travelling, travelling cart stardew, travelling captions, travelling companion, chris de burgh a spaceman came travelling, travelling doctor, travelling domestically, home, about, service, travel, other, contact us, ashok, amit, travellers, location, varanasi, umraha, babatpur, wedding cars, varanasi car rentals, car rental, wedding car rental, innova for rent, ertiga for rent, address-umraha babatpur varanasi">
    <meta name="description" content="With over a decade of experience, our car rental service has become the go-to choice for both residents and visitors seeking convenient, stress-free travel. We are proud to be the trusted car rental provider in the city, consistently staying ahead of other service providers. In addition to transporting passengers to offices and homes, we also offer trips to all major points of interest across Varanasi. Below are some of the most beautiful tourist attractions you might want to explore with us." >
    <meta name="author" content="Ashok Travels">
    <meta name="robots" content="index">
    <meta name="google-site-verification" content="iJTGRcng-OvXZqqMBuEcNaehPnpgGoI6n8NXBAonG_I" />

    <title>Ashok Travels</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Font-awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/fontawesome.min.css"/> -->
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Slick Nav CSS -->
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- Default Color CSS -->
    <link rel="stylesheet" href="assets/css/color/default-color.css">
    <!-- Color Switcher CSS -->
    <link rel="stylesheet" href="assets/dist/color-switcher.css">
    <!-- aos cdn -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/img/Ashok-Travel-logo.png">
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-VLSPLYSJ97"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-VLSPLYSJ97');
</script>
</head>