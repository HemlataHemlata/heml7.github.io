

<style>
    @media only screen and (max-width: 600px) {
        .header-top-right{
            display: none !important;
        }
        
    }
</style>

<div class="header-top-area" >
        <div class="container">
            <div class="row header-top-row">
                <div class="col-12 d-flex justify-content-between align-items-center" data-aos="fade-down">
                    <div class="header-top-left">
                        <!-- <a href="tel:9555976325"><i class="fa fa-phone"></i><span>+91 9555976325,</span></a>
                        <a href="tel:8573958805"><span>+91 8573958805</span></a> -->
                        <a href="https://maps.app.goo.gl/uvpGC4n54CVNajfE7"><i class="fa fa-location-arrow"></i><span>Umraha Babatpur, Varanasi</span></a>

                    </div>
                    <div class="header-top-right d-flex "  >
<!--                        <a href="https://www.facebook.com/profile.php?id=61566020992699"><i class="fa fa-facebook" aria-hidden="true"></i></a>-->
                        <!-- <a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a> -->
<!--                        <a href="https://www.instagram.com/ashoktravelsvaranasi/"><i class="fa fa-instagram" aria-hidden="true"></i></a>-->
                        <!-- <a href="#" target="_blank"><i class="fa fa-youtube-play" aria-hidden="true"></i></a> -->
						<a href="tel:9555976325"><i class="fa fa-phone" style="margin-right: 8px;" ></i><span>+91 9555976325,</span></a>
                        <a href="tel:8573958805"><span>+91 8573958805</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>