<footer class="site-footer " id="contact-us">
        <!-- Footer Top Area -->
        <div class="footer-top-area ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-wid">
                            <h3 class="footer-wid-title">Address</h3>

                            <div class="footer-address">
                                <p><i class="fa fa-location-arrow"></i>
                                    <span>Umraha Babatpur, Varanasi</span>
                                </p>
                                <p><a href="tel:9555976325"><i class="fa fa-phone"></i>+91 9555976325</a>, <a href="tel:8573958805"><span>8573958805</span></a></p>
                                <p><a href="mailto:bookashoktravels@gmail.com">
                                    <i class="fa fa-envelope-o"></i>bookashoktravels@gmail.com</a>
                                </p>
                                <ul class="d-flex footer-social-icon">
                                    <li><a href="https://www.facebook.com/profile.php?id=61566020992699"><i class="fa fa-facebook"></i></a></li>
                                    <!-- <li><a href="#" target="_blank"><i class="fa fa-twitter" target="_blank"></i></a></li> -->
                                    <!-- <li><a href="#" target="_blank"><i class="fa fa-youtube-play" target="_blank"></i></a></li> -->
                                    <li><a href="https://www.instagram.com/ashoktravelsvaranasi/"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-wid footer-menu">
                            <h3 class="footer-wid-title">Services</h3>
                            <ul>
                                <!-- <li><a href="#car-rental-mumba"><i class="fa fa-chevron-circle-right"></i> Car Rental In Varanasi</a></li> -->
                                <li><a href="#Varanasi-lonavla-car-rental"><i class="fa fa-chevron-circle-right"></i> Varanasi Car Rental</a></li>
                                <li><a href="#Varanasi-pune-car-rental"><i class="fa fa-chevron-circle-right"></i> Car Rental</a></li>
                                <li><a href="#book-outstation-cab"><i class="fa fa-chevron-circle-right"></i> Wedding Car Rental</a></li>
                                <li><a href="#innova-for-rent"><i class="fa fa-chevron-circle-right"></i> Innova for Rent</a></li>
                                <li><a href="#innova-for-rent"><i class="fa fa-chevron-circle-right"></i> Ertiga for rent</a></li>
<!--                                <li><a href="#book-outstation-cab"><i class="fa fa-chevron-circle-right"></i> Book Outstation Cab</a></li>-->
                                <!-- <li><a href="#car-on-rent-near-me"><i class="fa fa-chevron-circle-right"></i> Car On rent near me</a></li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-wid footer-menu pl-30">
                            <h3 class="footer-wid-title">Useful Links</h3>
                            <ul>
                                <li><a href="index"><i class="fa fa-chevron-circle-right"></i> home</a></li>
                                <li><a href="index#about"><i class="fa fa-chevron-circle-right"></i> About</a></li>
                                <li><a href="index#service"><i class="fa fa-chevron-circle-right"></i> services</a></li>
                                <li><a href="other"><i class="fa fa-chevron-circle-right"></i> Other</a></li>
                                <li><a href="enquiry"><i class="fa fa-chevron-circle-right"></i> contact us</a></li>
                            </ul>
                        </div>
                    </div>



                    <div class="col-lg-3 col-md-6">
                        <div class="footer-wid footer-menu">
                            <h3 class="footer-wid-title">location</h3>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7208.982766642934!2d83.0602027871306!3d25.388357303064932!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x398e2f446b45c8f5%3A0xc8b8d8e94afa333e!2sUmaraha%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1726647543546!5m2!1sen!2sin"  height="250" width="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- End Footer Top -->

        <!-- Footer Bottom Area -->
        <div class="footer-copyright-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <p class="text-center" style="margin-bottom:0px;">© 2024 Ashok Travels. All Rights Reserved |
                            Created by: <a href="http://genoviqweb.com/">GWPL </a></p>
                        </p>
                    </div>

                </div>
            </div>
        </div> <!-- End Footer Bottom Area -->
    </footer> 
    <!-- aos cdn -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
  AOS.init();
</script>