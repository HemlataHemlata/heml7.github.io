<!DOCTYPE html>
<html lang="en">
<!-- head start -->
<?php
include('includes/link.php');
?>
<!-- head end -->
<body>
    <!-- <div class="wrap b-button">
        <div class="container">
            <div class="row">
                <div class="col-6 ">
                    <a data-toggle="modal" data-target="#myModal" class="enq-call blink">Enquiry Now </a>

                </div>
                <div class="col-6 ">
                    <a href="tel:9555976325" class="enq-call blink">Call Now</a>

                </div>
            </div>
        </div>
    </div>
    <div id="callme">
        <a href="tel:9555976325">
            <div id="callmeMain"></div>
        </a>
    </div> -->
    <!-- <span data-toggle="modal" data-target="#myModal" id="btn-fix"><img src="assets/enquar.png" alt=""></span> -->

    <!-- Modal -->
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-sm">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <!-- redirect Code -->


                    <h4 class="modal-title">Enquiry Form
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class=" col-sm-12 col-xs-12">
                            <form  id="ContactUsCaptchaWebForm" method="post"
                                onSubmit="return ValidateForm(this);">

                                <div class="row">
                                    <input id="name" name="name" class="form-control" placeholder="Name" type="text"
                                        required>
                                    <input type="text" name="mobile" class="form-control" placeholder="Mobile No"
                                        pattern="[0-9]{10,10}" autocomplete="on" class="form-control" required
                                        maxlength="10" required>
                                    <textarea id="msg" name="msg" class="form-control" placeholder="Message"
                                        required></textarea>
                                </div>
								<input type="hidden" class="box-div" name="email" value="send enquiry" />
					   
                                  

    
								<input class="btn sub-btn center-block" type="submit" id="submit" value="Submit">
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start Top Header -->
     <?php
     include('includes/top_header.php');
     ?>
    <!-- End Top Header -->

    <!-- Start Main Menu -->
     <?php
     include('includes/header.php');
     ?>
    <!-- End Main Menu -->

    <?php
    include('includes/mobile_header.php');
    ?>
    


    <!-- Start About Us Area -->
    <section class="cleaning-content-block about-us" id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="who-we-info">
                        <div class="section-title mob-center">
                            <h2>WELCOME TO KNOW About<br> Amit Constructions</h2>
                            <img src="assets/images/border-line.jpg" alt="border-line-img">
                        </div>

                        <p class="text-justify">Works trucks, self-propelled, not fitted with lifting or handling equipment, of the type used in factories, warehouses, dock areas or airports for short distance transport of goods; tractors of the type used on railway station platforms; parts of the foregoing vehicles vehicles: electrical.</p>
                        <a href="tel:9555976325" class="custum-btn">Call Now <i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="promo-video">
                        <img src="assets/images/amit-about.png" alt="amit-construction" />
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Start About Us Area -->

    <!-- Start scroll to top feature -->
    <a href="#" id="back-to-top" title="Back to Top">
        <i class="fa fa-long-arrow-up"></i>
    </a>
    <!-- End scroll to top feature -->

    <!-- Start Footer Area -->
     <?php
     include('includes/footer.php');
     ?>
    <!-- End Footer Area -->
<!-- icons start -->
<?php
     require('includes/sociallinks.php');
     ?>
 <!-- icons end -->
    <!-- jQuery min js -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <!-- Bootstrap JS file -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Popper JS -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Owl-Carousel JS file -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Slick-Nav JS file -->
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <!-- Magnific Popup JS file -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Mixitup JS file -->
    <script src="assets/js/mixitup.min.js"></script>
    <!-- WOW JS file -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Jquery Counterup JS file -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Waypoints JS file -->
    <script src="assets/js/waypoints.min.js"></script>
    <!-- Custom JS file -->
    <script src="assets/js/active.js"></script>

</body>

</html>