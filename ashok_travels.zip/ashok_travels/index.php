<!DOCTYPE html>
<html lang="en">
<!-- head start -->
<?php
include('includes/link.php');
?>
<!-- head end -->
	<style>
        #demo{
            display: block;
        }
        #demo-1{
            display: none;
        }
		@media only screen and (max-width: 767px) {
			#about{
				padding: 0;
			}
			.carousel-item img{
				height: 410px;
				width: 100%;
			}
          #demo-1{
            display: block;
          }
          #demo{
            display: none;
          }
		}
	</style>
<body>
    <!-- <div class="wrap b-button">
        <div class="container">
            <div class="row">
                <div class="col-6 ">
                    <a data-toggle="modal" data-target="#myModal" class="enq-call blink">Enquiry Now </a>

                </div>
                <div class="col-6 ">
                    <a href="tel:9555976325" class="enq-call blink">Call Now</a>

                </div>
            </div>
        </div>
    </div>
    <div id="callme">
        <a href="tel:9555976325">
            <div id="callmeMain"></div>
        </a>
    </div> -->
    <!-- <span data-toggle="modal" data-target="#myModal" id="btn-fix"><img src="assets/enquar.png" alt=""></span> -->

    <!-- Modal -->
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog modal-sm">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <!-- redirect Code -->


                    <h4 class="modal-title">Enquiry Form
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class=" col-sm-12 col-xs-12">
                            <form  id="ContactUsCaptchaWebForm" method="post"
                                onSubmit="return ValidateForm(this);">

                                <div class="row">
                                    <input id="name" name="name" class="form-control" placeholder="Name" type="text"
                                        required>
                                    <input type="text" name="mobile" class="form-control" placeholder="Mobile No"
                                        pattern="[0-9]{10,10}" autocomplete="on" class="form-control" required
                                        maxlength="10" required>
                                    <textarea id="msg" name="msg" class="form-control" placeholder="Message"
                                        required></textarea>
                                </div>
								<input type="hidden" class="box-div" name="email" value="send enquiry" />
					   
                                  

    
								<input class="btn sub-btn center-block" type="submit" id="submit" value="Submit">
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start Top Header -->
     <?php
     include('includes/top_header.php');
     ?>
    <!-- End Top Header -->

    <!-- Start Main Menu -->
     <?php
     include('includes/header.php');
     ?>
    <!-- End Main Menu -->

    <?php
    include('includes/mobile_header.php');
    ?>
    <!-- Homepage Slider -->

    <div id="demo" class="carousel slide" data-ride="carousel" >

        <!-- Indicators -->
        <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>

        </ul>

        <!-- The slideshow -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="assets/images/banner-01.png" alt="slider-img" >
            </div>
            <div class="carousel-item ">
                <img src="assets/images/Subah-e-Banaras.png" alt="slider-img"  >
            </div>
            <div class="carousel-item">
                <img src="assets/images/banner-2.png" alt="slider-img" >
            </div>
            
        </div>

        <!-- Left and right controls -->
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>

    </div>
    <!-- mobile start  -->
     
    <div id="demo-1" class="carousel slide" data-ride="carousel">

<!-- Indicators -->
<ul class="carousel-indicators">
    <li data-target="#demo-1" data-slide-to="0" class="active"></li>
    <li data-target="#demo-1" data-slide-to="1"></li>
    <li data-target="#demo-1" data-slide-to="2"></li>

</ul>

<!-- The slideshow -->
<div class="carousel-inner">
    <div class="carousel-item active">
        <img src="assets/images/mobile-3.png" alt="slider-img" >
    </div>
    <div class="carousel-item ">
        <img src="assets/images/mobile-2.png" alt="slider-img"  >
    </div>
    <div class="carousel-item">
        <img src="assets/images/mobile-1.png" alt="slider-img" >
    </div>
    
</div>

<!-- Left and right controls -->
<a class="carousel-control-prev" href="#demo-1" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
</a>
<a class="carousel-control-next" href="#demo-1" data-slide="next">
    <span class="carousel-control-next-icon"></span>
</a>

</div>
     <!-- mobile end -->

    <!-- End Homepage Slider -->


    <!-- Start About Us Area -->
    <section class="cleaning-content-block about-us" id="about" >
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="who-we-info">
                        <div class="section-title mob-center">
                            <h2>WELCOME TO KNOW About<br> Ashok Travels</h2>
                            <img src="assets/images/border-line.jpg" alt="border-line-img">
                        </div>

                        <p class="text-justify">With over a decade of experience, our car rental service has become the go-to choice for both residents and visitors seeking convenient, stress-free travel. We are proud to be the trusted car rental provider in the city, consistently staying ahead of other service providers. In addition to transporting passengers to offices and homes, we also offer trips to all major points of interest across Varanasi. Below are some of the most beautiful tourist attractions you might want to explore with us.</p>
                        <a href="tel:9555976325" class="custum-btn">Call Now <i class="fa fa-arrow-right"></i></a>
                        
                        
<!-- <style>                        
#style-btn a {
    position: relative;
    padding: 30px 65px;
    color: #ee050b;
    text-decoration: none;
    display: inline-block;
    text-transform: uppercase;
    letter-spacing: 0.2em;
    font-size: 1.5em;
    border: 2px solid transparent;
    transition: 0.5s;
    -webkit-transition: 0.5s;
    -moz-transition: 0.5s;
    -ms-transition: 0.5s;
    -o-transition: 0.5s;
}

#style-btn a:hover {
    border: 2px solid #ee050b;
}

#style-btn a::before {
    content: '';
    position: absolute;
    inset: 0 8px;
    border-left: 2px solid #ee050b;
    border-right: 2px solid #ee050b;
    transition: 1s;
    -webkit-transition: 1s;
    -moz-transition: 1s;
    -ms-transition: 1s;
    -o-transition: 1s;
}

#style-btn a::after {
    content: '';
    position: absolute;
    inset: 8px 0;
    border-top: 2px solid #ee050b;
    border-bottom: 2px solid #ee050b;
    transition: 1s;
    -webkit-transition: 1s;
    -moz-transition: 1s;
    -ms-transition: 1s;
    -o-transition: 1s;
}

#style-btn a.btn1:hover::before {
    inset: 16px 8px;
}

#style-btn a.btn1:hover::after {
    inset: 8px 16px 8px;
}
</style>
                        <div id="style-btn" >
                        <a href="tel:9555976325" class="btn1"><i class="fa fa-phone"></i> Call Now</a>
                        </div> -->
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="promo-video"  data-aos="zoom-out-down">
                        <img src="assets/img/abt-img.jpeg" alt="about-img" />
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Start About Us Area -->

    <div class="Ourproduct mob-padding" id="service">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <h2 id="innova-for-rent">Our Services</h2>
                        <img src="assets/images/border-line.jpg" alt="border-line-img">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="car-rental-Varanasi">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/01.jpg" alt="service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>7 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                            <a href="tel: +91 9555976325"> <h5>Innova Crysta</h5> </a>
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i> Airport Transfer Rs.1400</li>
                            <li><i class="fa fa-check-circle"></i>  8Hr / 80Km Rs.2600</li>
                            <li><i class="fa fa-check-circle"></i>  Full Day / 200Km Rs.4000</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.17/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="Varanasi-lonavla-car-rental">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/02.webp" alt="service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>5 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                            <a href="tel: +91 9555976325" > <h5>Swift Dizire</h5> </a>
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i> Airport Transfer Rs.800 </li>
                            <li><i class="fa fa-check-circle"></i> 8Hr / 80Km Rs.1600</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km Rs.2200</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.11/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="Varanasi-pune-car-rental">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/03.webp" alt="service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>7 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                            <a href="tel: +91 9555976325" > <h5>Ertiga</h5> </a>
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i>  Airport Transfer Rs.1200</li>
                            <li><i class="fa fa-check-circle"></i>  8Hr / 80Km Rs.2000</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km Rs.2600</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.13/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="wedding-car-rental">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/04.webp" alt="service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>10 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                           <a href="tel: +91 9555976325"><h5>Trax Cruiser</h5></a> 
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i> Airport Transfer Rs.1600</li>
                            <li><i class="fa fa-check-circle"></i> 8Hr / 80Km Rs.2600</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km Rs.3200</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.17/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" >
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/05.png" alt="service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp">7 seater</i> -->
                                     <p>26 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                         <a href="tel: +91 9555976325"><h5>Tempo Traveller</h5></a>   
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i> Airport Transfer Rs.2300</li>
                            <li><i class="fa fa-check-circle"></i> 8Hr / 80Km Rs.4000</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km Rs.5000</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.23/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="car-rental-Varanasi">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/08.png" alt="service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>7 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                        <a href="tel: +91 9555976325"><h5>Fortuner</h5></a>    
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i>  Airport Transfer Rs.3500</li>
                            <li><i class="fa fa-check-circle"></i> 8Hr / 80Km Rs.10000</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km</li>
                            <li><i class="fa fa-check-circle"></i>  Outstation Rs.40/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <h2>Special Car's</h2>
                        <img src="assets/images/border-line.jpg" alt="border-line-img">
                    </div>
                </div>
            </div>
            <div class="row">
                
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="ertiga-for-rent">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/06.webp" alt="special-service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>7 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                         <a href="tel: +91 9555976325"><h5>Audi</h5></a>   
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i>  Airport Transfer Rs.4500</li>
                            <li><i class="fa fa-check-circle"></i>  8Hr / 80Km Rs.14000</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km Rs.18000</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.90/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="ertiga-for-rent">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/10.png" alt="special-service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>7 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                          <a href="tel: +91 9555976325"><h5>Mercedeze Benz</h5></a>  
                           
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i>  Airport Transfer Rs.5000</li>
                            <li><i class="fa fa-check-circle"></i>  8Hr / 80Km Rs.13000</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km Rs.18000</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.90/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="OurproductItem wow fadeInUp" data-wow-delay="0.4s">
                        <div class="OurproductItem_Top" id="book-outstation-cab">
                            <a href="https://api.whatsapp.com/send?phone=918573958805" target="_blank">
                                <figure>
                                    <img src="assets/images/07.webp" alt="special-service-img">
                                </figure>
                                <div class="OurproductItem_Toplist">
                                    <!-- <i class="fa fa-whatsapp"></i> -->
                                 <p>6 Seaters</p>
                                </div>
                            </a>
                            <!-- <a href="tel:9555976325">
                                <div class="shopNow">
                                    <i class="fa fa-phone"></i>
                                    <span>Call Now</span>
                                </div>
                            </a> -->
                        </div>
                        <div class="OurproductItem_text">
                         <a href="tel: +91 9555976325"><h5>BMW</h5></a>   
                            
                        </div>
                        <div class="ul-li" >
                        <ul>
                            <li><i class="fa fa-plane"></i> Airport Transfer Rs.5500</li>
                            <li><i class="fa fa-check-circle"></i> 8Hr / 80Km Rs.15000</li>
                            <li><i class="fa fa-check-circle"></i> Full Day / 200Km Rs.20000</li>
                            <li><i class="fa fa-check-circle"></i> Outstation Rs.100/Km</li>
                            <!-- <li><i class="fa fa-check-circle"></i> Capacity 5</li> -->
                        </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .cta-section {
    background-image: url(images/texture.png);
    clip-path: polygon(0 0, 100% 0, 100% 50%, 80% 100%, 0 100%);
    background-repeat: repeat;
    background-size: cover;
    background-color: #222;
    position: relative;
    z-index: 1
}

.cta-men {
    background-image: url(assets/images/cta-men.png);
    background-repeat: no-repeat;
    background-position: bottom right;
    background-size: contain;
    width: 100%;
    height: 100%;
    position: absolute;
    right: 130px;
    bottom: -30px;
    z-index: -1
}

.cta-content .cta-call {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-top: 25px
}

.cta-content .cta-call p span {
    display: block
}

.cta-content .cta-call p a {
    color: #d21419;
    font-size: 32px;
    font-weight: 700;
    line-height: 1
}

.cta-content .cta-call i {
    background-color: rgba(255, 153, 0, .1);
    width: 60px;
    height: 60px;
    line-height: 60px;
    text-align: center;
    font-size: 40px;
    color: #d21419;
    border-radius: 2px
}

.cta-content h2 {
    font-size: 46px;
    line-height: 52px;
    color: #fff;
    margin-bottom: 20px
}

.cta-content h2 span {
    color: #d21419
}

.cta-content p {
    font-size: 18px;
    font-weight: 500;
    color: #ccc;
    margin: 0
}

.cta-section-2 {
    position: relative;
    z-index: 1
}

.cta-section-2:before {
    background-color: #d21419;
    background-image: url(images/cta-map.png);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    width: 90%;
    height: 100%;
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    z-index: -1
}

.cta-section-2 .cta-content h4 {
    text-transform: uppercase;
    font-size: 16px;
    letter-spacing: 1px
}

.cta-section-2 .cta-content h2 {
    margin: 0;
    font-size: 36px;
    line-height: 42px
}

.cta-section-2 .cta-content .default-btn {
    background-color: #222;
    margin-top: 20px
}

.cta-section-2 .cta-content .default-btn:hover {
    color: #222
}

.cta-section-2 .cta-content .default-btn:after, .cta-section-2 .cta-content .default-btn:before {
    background-color: #fff
}

.cta-section-2 .check-list i {
    background-color: #222;
    clip-path: polygon(15% 0%, 100% 0%, 85% 100%, 0% 100%);
    font-size: 12px;
    color: #d21419;
    width: 30px;
    height: 20px;
    line-height: 20px;
    text-align: center
}

.cta-section-2 .check-list li {
    color: #fff
}

.cta-section-2 .check-list li:not(:last-of-type) {
    margin-bottom: 10px
}

.cta-section-2 .cta-men {
    background-size: 95%;
    right: 90px;
    bottom: 0;
    width: 500px;
    height: 420px
}
.padding{
    padding: 100px 0;
}

@media(min-width:993px) and (max-width:1200px) {
    .cta-men {
        width: 450px;
        right: 70px;
        bottom: -5px;
    }
}
@media only screen and (max-width: 767px){
    .cta-men {
        background-image: none;
    }
}
    </style>
    <section class="cta-section padding">
                <div class="cta-men wow fade-in-bottom" data-aos="zoom-in-up" data-wow-delay="200ms"></div>
                <div class="container">
                        <div class="cta-content" >
                                <h2 data-aos="zoom-in">Call Us Now <span>Book Your Taxi</span> <br> For Your Next Ride!</h2>
                                <!-- <p>We successfully cope with tasks of varying complexity,<br>guarantees and regularly
                                        master new
                                        technologies.</p> -->
                                <div class="cta-call" id="enquire" >
                                        <i class="fa fa-phone"></i>
                                        <p>
                                            <!-- <span>Call For Taxi</span> -->
                                            <a href="tel:9555976325" data-aos="zoom-out-up">+91-9555976325</a></p>
                                </div>
                        </div>
                </div>
        </section>
    <!-- Achivment Section -->
    <!-- <section class="cleaning-content-block achivment-section">
        <div class="container">
            <div class="row enq-banner" id="enquire">
                <div class="col-sm-12 col-lg-8">
                    <h5>For further enquiries, feel free to request a quote</h5>
                    <p>We're always here to listen to you first</p>
                </div>
                <div class="col-sm-12 col-lg-4">
                    <h5 class="cllbtn"><a href="tel:9555976325">+91 9555976325</a></h5>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End Achivment Section -->


    <!-- Start scroll to top feature -->
    <a href="#" id="back-to-top" title="Back to Top">
        <i class="fa fa-long-arrow-up"></i>
    </a>
    <!-- End scroll to top feature -->
    
    <!-- Start Footer Area -->
     <?php
     include('includes/footer.php');
     ?>
    <!-- End Footer Area -->
    <?php
     require('includes/sociallinks.php');
     ?>
     <!-- icons start  -->
      <!-- <style>
   
.btn-floating:hover img {
  margin-bottom: -3px
}

.btn-floating {
    position: fixed;
    right: 25px;
    overflow: hidden;
    width: 50px;
    height: 50px;
    border-radius: 100px;
    border: 0;
    z-index: 9999;
    color: white;
    transition: .2s;
}

.btn-floating:hover {
    width: auto;
    padding: 0 20px;
    cursor: pointer;
}

.btn-floating span {
    font-size: 16px;
    margin-left: 5px;
    transition: .2s;
    line-height: 0px;
    display: none;
}

.btn-floating:hover span {
    display: inline-block;
}

Phone
.btn-floating.phone {
    bottom: 85px;
    background-color: #ee050b;
}

.btn-floating.phone:hover {
    background-color: #c03421;
}

WhatsApp
.btn-floating.whatsapp {
    background-color: #34af23;
    bottom: 25px;
}

.btn-floating.whatsapp:hover {
    background-color: #1f7a12
}
      </style> -->
      <!-- <a href="tel:9555976325">
  <button class="btn-floating phone">
    <img src="https://i.imgur.com/FZuns9L.png" alt="Phone">
    <span>+91 9555976325</span>
  </button>
</a>

<a href="https://api.whatsapp.com/send?phone=918573958805">
  <button class="btn-floating whatsapp">
    <img src="https://i.imgur.com/LBW2Lso.png" alt="WhatsApp">
    <span>+91 8573958805</span>
  </button>
</a> -->
      <!-- floating end -->

    <!-- <p><a href="https://api.whatsapp.com/send?phone=918573958805" target="blank"><img src="assets/whatsapp.png"
        class="whatsup"></a>
    </p> -->

    <!-- jQuery min js -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <!-- Bootstrap JS file -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Popper JS -->
    <script src="assets/js/popper.min.js"></script>
    <!-- Owl-Carousel JS file -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Slick-Nav JS file -->
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <!-- Magnific Popup JS file -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Mixitup JS file -->
    <script src="assets/js/mixitup.min.js"></script>
    <!-- WOW JS file -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Jquery Counterup JS file -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Waypoints JS file -->
    <script src="assets/js/waypoints.min.js"></script>
    <!-- Custom JS file -->
    <script src="assets/js/active.js"></script>
    <script>
        $(document).ready(function () {



            $('.navbar-collapse a').on('click', function () {
                $(".navbar-collapse").collapse('hide');
            });


            $('#Myclients').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                autoplay: true,
                autoplayTimeout: 3000,
                responsive: {
                    0: {
                        items: 2
                    },
                    600: {
                        items: 3
                    },
                    1000: {
                        items: 5
                    }
                }
            })
        })
    </script>

</body>

</html>