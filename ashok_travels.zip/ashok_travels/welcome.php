<!DOCTYPE html>
<html lang="en-US">

<!-- head start -->
<?php
include('includes/link.php');
?>
<!-- head end -->

<body>


   <!-- Header Top Area Start -->
   <?php //include 'inc/navbar.php'; ?>
   <style>
.thankyou-wrapper{
  width:100%;
  height:auto;
  margin:auto;
  background:#ffffff; 
  /* padding:10px 0px 50px; */
}
.thankyou-wrapper h1{
  font:100px Arial, Helvetica, sans-serif;
  text-align:center;
  color:#333333;
  padding:0px 10px 10px;
}
.thankyou-wrapper p{
  font:26px Arial, Helvetica, sans-serif;
  text-align:center;
  color:#333333;
  padding:5px 10px 10px;
}
.thankyou-wrapper a{
  font:26px Arial, Helvetica, sans-serif;
  text-align:center;
  color:#ffffff;
  display:block;
  text-decoration:none;
  width:250px;
  background:#ee050b;
  margin:10px auto 0px;
  padding:15px 20px 15px;
  border-bottom:5px solid #ee050b63;
}
.thankyou-wrapper a:hover{
  font:26px Arial, Helvetica, sans-serif;
  text-align:center;
  color:#ee050b;
  display:block;
  text-decoration:none;
  width:250px;
  background:#ffffff;
  margin:10px auto 0px;
  padding:15px 20px 15px;
  border:5px solid #ee050b;
  box-shadow: 2px 2px #ee050b63;
}
</style>

   <!-- welcome Area Start -->
   <section class="login-main-wrapper">
      <div class="main-container">
          <div class="login-process">
              <div class="login-main-container">
                  <div class="thankyou-wrapper">
                      <h1 style="margin: 0 !important;" ><img src="assets/img/thankyou.png" alt="thanks" /></h1>
                        <p style="margin: 0 !important;" >Thank you for reaching out! We'll be in touch with you shortly...</p>
                        <a href="index">Back to home</a>
                        <div class="clr"></div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="clr"></div>
        </div>
    </section>                        
   <!-- welcome Area End -->
  

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  



   <!-- Footer Area Start -->
   <?php //include 'inc/footer.php'; ?>
   <!-- Footer Area End -->
   <?php //include 'inc/footer-js.php'; ?>

</body>

</html>