<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <?php
    include('includes/link.php');
    ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


          <!-- header start  -->
       <?php
       include('includes/header.php'); 
       ?>
        <!-- header end  -->



        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Programs</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Programs</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->

<!-- Programs section start  -->
<div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                <?php
  include('connection.php');
   if(isset($_GET['program'])){
      $programid=$_GET['program'];
      $sql="SELECT * FROM `dpis_program` WHERE `id`='$programid' ORDER BY `id` DESC";
      $result=mysqli_query($conn,$sql);
      $row=mysqli_fetch_assoc($result);
      
   
  ?>
                <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid w-80  rounded-circle bg-light p-3" src="<?php echo $row['photo']; ?>" alt="Programs-img" style="height: 400px; width: 400px; " >
                            </div>
                            <div class="col-6 text-start" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="img/facility-2.jpg" alt="Programs-img" style="height: 250px; width: 250px; ">
                            </div>
                            <div class="col-6 text-end" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="img/facility-3.jpg" alt="Programs-img" style="height: 250px; width: 250px; ">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4"><?php echo ucwords(base64_decode($row['heading'])) ; ?></h1>
                        <h5 class="text-primary" >Age Group <?php echo $row['age_group']; ?> years</h5>
                        <p><?php echo ucfirst(base64_decode($row['description'])) ;  ?></p>
                       <ul>
                        <li>Developing listening and language skills</li>
                        <li>Emotional, physical and social engagement</li>
                        <li>Developing a grasp hold to enable scribbling</li>
                        <li>Exploration of letters, Numbers, primary shapes and colors</li>
                        <li>Development of fine and gross motor skills</li>
                        <li>Cognitive development through sensorial activities</li>
                       </ul>

                        
                    </div>
                  <?php
   }
                  ?>
                </div>
            </div>
        </div>
 <!-- Programs section end   -->
       


        <!-- Footer Start -->
        <?php
       include('includes/footer.php');
       ?>
        <!-- Footer End -->



        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>


<!-- Mirrored from themewagon.github.io/kider/facility.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 04 Sep 2024 06:17:28 GMT -->
</html>