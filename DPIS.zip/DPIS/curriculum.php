<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <?php
    include('includes/link.php');
    ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- header start  -->
       <?php
       include('includes/header.php'); 
       ?>
        <!-- header end  -->


        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Curriculum</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Curriculum</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- curriculum Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4">Our Curriculum</h1>
                        <p>Delhi Public International School offers a comprehensive and engaging curriculum designed to foster holistic development. Starting with play-based learning in the Early Years Program, the curriculum progresses through core subjects and creative activities in Primary School, focusing on inquiry and critical thinking. In Middle School, students explore a broad range of subjects while developing essential study and life skills. The Secondary School Program prepares students for higher education with advanced coursework and career guidance, culminating in the rigorous International Baccalaureate (IB) Program for Grades 11 and 12. Complemented by a variety of co-curricular activities and tailored support programs, our curriculum aims to inspire academic excellence, personal growth, and global awareness.
                        </p>
                        <p class="mb-4">
                        <strong>Our curriculum </strong> is crafted in “Core Value Circle” which helps children in the refinement of their senses; communication & language development, motor skill development, physical development, creative development, social development, personality development, problem-solving, reasoning & numeracy skills, practical life/ care for self & environment and understanding of the world.
                        </p>
                        <!-- <div class="row g-4 align-items-center">
                            <div class="col-sm-6">
                                <a class="btn btn-primary rounded-pill py-3 px-5" href="about">Read More</a>
                            </div>
                        </div> -->
                    </div>
                    <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid w-80 rounded-circle bg-light p-3" src="img/Core-value.png" alt="about-img">
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- curriculum End -->
         <!-- second  section start  -->
          <style>
          
.section {
    padding: 100px 0;
    position: relative;
}
.gray-bg {
    background-color: #f5f5f5;
}
.section-title h2 {
    font-weight: 700;
    color: #20247b;
    font-size: 45px;
    margin: 0 0 15px;
    border-left: 5px solid #d50302;
    padding-left: 15px;
}
.section-title {
    padding-bottom: 45px;
}
.section-title p {
    margin: 0;
    font-size: 18px;
}

/* Resume Box
---------------------*/
.resume-box {
  background: #ffffff;
  box-shadow: 0 0 1.25rem rgba(31, 45, 61, 0.08);
  border-radius: 10px;
}
.resume-box ul {
  margin: 0;
  padding: 30px 20px;
  list-style: none;
}
.resume-box li {
  position: relative;
  padding: 0 20px 0 60px;
  margin: 0 0 30px;
}
.resume-box li:last-child {
  margin-bottom: 0;
}
.resume-box li:after {
  content: "";
  position: absolute;
  top: 0px;
  left: 20px;
  border-left: 1px dashed #d50302;
  bottom: 0;
}
.resume-box .icon {
  width: 40px;
  height: 40px;
  position: absolute;
  left: 0;
  right: 0;
  color: #d50302;
  line-height: 40px;
  background: #ffffff;
  text-align: center;
  z-index: 1;
  border: 1px dashed;
  border-radius: 50%;
}
.resume-box .time {
  background: #d50302;
  color: #ffffff;
  font-size: 10px;
  padding: 2px 10px;
  display: inline-block;
  margin-bottom: 12px;
  border-radius: 20px;
  font-weight: 600;
}
.resume-box h5 {
  font-weight: 700;
  color: #20247b;
  font-size: 16px;
  margin-bottom: 10px;
}
.resume-box p {
  margin: 0;
}

.resume-box li:after {
    content: "";
    position: absolute;
    top: 0px;
    left: 20px;
    border-left: 1px dashed #d50302;
    bottom: 0;
}
          </style>
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" integrity="sha256-mmgLkCYLUQbXn0B1SRqzHar6dCnv9oZFPEC1g1cwlkk=" crossorigin="anonymous" />
<section class="section gray-bg" id="resume">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title">
                            <h2>The Areas of learning & Development are as follows:</h2>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 m-15px-tb">
                        <div class="resume-box">
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-book-reader"></i>
                                    </div>
                                    <!-- <span class="time">2019 - Present</span> -->
                                    <h5>SENSORY SKILLS ENHANCEMENT</h5>
                                    <p>From birth, children begin to use all five senses to explore and understand their environment. Early in life, they are naturally curious and eager to discover new sensations, making every new sight, taste, smell, and sound a source of excitement.</p>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-book-reader"></i>
                                    </div>
                                    <!-- <span class="time">2019 - Present</span> -->
                                    <h5>LANGUAGE & COMMUNICATION SKILLS DEVELOPMENT</h5>
                                    <p>We offer numerous opportunities for advancing language skills through our well-resourced book corner and engaging role-play area. Regular activities such as story time, Drop Everything and Read (D.E.A.R), and news time are integral to our program.</p>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-book-reader"></i>
                                    </div>
                                    <!-- <span class="time">2019 - Present</span> -->
                                    <h5>PHYSICAL SKILL DEVELOPMENT</h5>
                                    <p>We offer specially crafted activities and tools to enhance children’s motor skills, supporting their physical growth and strengthening bones, muscles, and their ability to interact with their environment.
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 m-15px-tb">
                        <div class="resume-box">
                            <ul>
                                <li>
                                    <div class="icon">
                                       <i class="fa fa-book-reader"></i>
                                    </div>
                                    <!-- <span class="time">2019 - Present</span> -->
                                    <h5>PHYSICAL DEVELOPMENT</h5>
                                    <p>Children at their early age experience a wide range of activities that help them to develop and strengthen their muscular skills, manipulative skills, and control of their body and an awareness of space.</p>
                                </li>
                                <li>
                                    <div class="icon">
                                       <i class="fa fa-book-reader"></i>
                                    </div>
                                    <!-- <span class="time">2019 - Present</span> -->
                                    <h5>CREATIVE DEVELOPMENT</h5>
                                    <p>Our schools have a stimulating and informative atmosphere for early learners. They will explore a new topic related to the curriculum plan. Activities, such as painting, drawing, multi media and model making and role-plays ensure that the children are actively involved in their school activities. </p>
                                </li>
                                <li>
                                    <div class="icon">
                                       <i class="fa fa-book-reader"></i>
                                    </div>
                                    <!-- <span class="time">2019 - Present</span> -->
                                    <h5>UNDERSTANDING OF THE WORLD</h5>
                                    <p>We encourage our students to look at the world and all its surroundings. The children are encouraged to portray self-images in every term through drawing, model making, painting and self-expression. We help them to develop their moral values to take care of the environment and surrounding being a good citizen of the nation.  </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
          <!-- second section end  -->


       <!-- Footer Start -->
       <?php
       include('includes/footer.php');
       ?>
        <!-- Footer End -->



        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>