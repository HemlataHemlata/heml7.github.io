<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <?php
    include('includes/link.php');
    ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- header start  -->
        <?php
         include('includes/header.php'); 
        ?>
        <!-- header end  -->
        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Activities</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Activities</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->

        <!-- activity Start -->
         <style>
            .nav-pills .nav-link {
  color: #2f3c4e !important;
  margin: auto 15px;
  border: 1px solid #e9ecef;
}

.nav-pills .nav-link.active {
  background-color: #f89d36;
  color: #ffffff !important;
  -webkit-box-shadow: 0 0 3px rgba(47, 60, 78, 0.15);
          box-shadow: 0 0 3px rgba(47, 60, 78, 0.15);
}

.nav-pills a .screenshot .title {
  font-size: 18px;
}
         </style>
         
        <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 text-center">
                        <div class="section-title mb-4 pb-2">
                            <h4 class="title mb-4">Our School Activities</h4>
                            <!-- <p class="text-muted mx-auto para-desc mb-0">Splash your dream color Bring your home to lively Colors. We make it a priotity to offer flexible services to accomodate your needs</p> -->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
                
                <div class="row mt-4 pt-2 align-items-center">
                
                    <div class="col-lg-3 col-md-4 col-12">
                        <ul class="nav nav-pills nav-justified" id="pills-tab" role="tablist">
                        <?php
      include('connection.php');
      $i = 1;
      $sql="SELECT * FROM `dpis_activity` ORDER BY `id` DESC";
      $result= mysqli_query($conn, $sql);
      foreach($result as $res){
        if($i==1){
            $active = 'active';
           
            
        }
        else{
            $active = '';
           
        }
?>
                            <li class="nav-item mb-4 pt-2">
                                <a class="nav-link rounded-pill <?php echo $active ;  ?>" id="pills-cloud-tab" data-toggle="pill" href="#<?php echo $res['heading'].'1' ; ?>" role="tab" aria-controls="<?php echo $res['heading'].'1' ; ?>" aria-selected="false">
                                    <div class="screenshot text-center pt-2 pb-2">
                                        <h4 class="title font-weight-normal mb-0"><?php echo base64_decode($res['heading']) ; ?></h4>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->
                            
                            <!-- <li class="nav-item mb-4 pt-2">
                                <a class="nav-link rounded-pill" id="pills-smart-tab" data-toggle="pill" href="#pills-smart" role="tab" aria-controls="pills-smart" aria-selected="false">
                                    <div class="screenshot text-center pt-2 pb-2">
                                        <h4 class="title font-weight-normal mb-0">hello india</h4>
                                    </div>
                                </a>
                            </li>
                            
                            <li class="nav-item mb-4 pt-2">
                                <a class="nav-link rounded-pill" id="pills-apps-tab" data-toggle="pill" href="#pills-apps" role="tab" aria-controls="pills-apps" aria-selected="false">
                                    <div class="screenshot text-center pt-2 pb-2">
                                        <h4 class="title font-weight-normal mb-0">hello india</h4>
                                    </div>
                                </a>
                            </li>

                            <li class="nav-item mb-4 pt-2">
                                <a class="nav-link rounded-pill active" id="pills-intelligence-tab" data-toggle="pill" href="#pills-intelligence" role="tab" aria-controls="pills-intelligence" aria-selected="true">
                                    <div class="screenshot text-center pt-2 pb-2">
                                        <h4 class="title font-weight-normal mb-0">hello india</h4>
                                    </div>
                                </a>
                            </li> -->
                            <?php
                            $i++;
      }
                        ?>
                        </ul><!--end nav pills-->
                       
                    </div><!--end col-->

                    <div class="col-lg-9 col-md-8 col-12 mt-4 pt-2 mt-sm-0 pt-sm-0">
                    
                        <div class="tab-content" id="pills-tabContent">
                        <?php
      include('connection.php');
      $i = 1;
      $sql="SELECT * FROM `dpis_activity` ORDER BY `id` DESC";
      $result= mysqli_query($conn, $sql);
      foreach($result as $res){
        if($i==1){
            $active = 'active';
            $show = 'show';
            
        }
        else{
            $active = '';
            $show = '';
        }
?>
                            <div class="tab-pane fade <?php echo $active . ' ' . $show ;  ?> " id="<?php echo $res['heading'].'1' ; ?>" role="tabpanel" aria-labelledby="pills-cloud-tab">
                                <img src="<?php echo $res['photo']; ?>" class="img-fluid img-responsive  img-thumbnail" alt="activity-img" style="height: 550px; width: 100%; ">
                            </div><!--end teb pane-->
                            
                            <!-- <div class="tab-pane fade" id="pills-smart" role="tabpanel" aria-labelledby="pills-smart-tab">
                            <img src="img/activity-2.png" class="img-fluid img-responsive  img-thumbnail" alt="activity-img" style="height: 450px; width: 100%; ">
                            </div>

                            <div class="tab-pane fade" id="pills-apps" role="tabpanel" aria-labelledby="pills-apps-tab">
                                <img src="img/competition.png" class="img-fluid img-responsive  img-thumbnail" alt="competition-img" style="height: 550px; width: 100%; " >
                            </div>

                            <div class="tab-pane fade active show" id="pills-intelligence" role="tabpanel" aria-labelledby="pills-intelligence-tab">
                            <img src="img/activity-3.png" class="img-fluid img-responsive  img-thumbnail" alt="activity-img" style="height: 550px; width: 100%; ">
                            </div> -->
                            <?php
        
                            $i++;
      }
                    ?>
                        </div><!--end tab content-->
                    </div><!--end col-->
                   
                    
                </div><!--end row-->
            </div>
        <!-- activity End -->
         <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" ></script>

        <!-- Team Start -->
       <?php
       include('includes/teacher.php');
       ?>
        <!-- Team End -->


       <!-- Footer Start -->
       <?php
       include('includes/footer.php');
       ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>