<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
                        
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="../about">About</a></li>
  <!-- <li class="active">Data</li> -->
</ol>
                    </div>
                </div>
			 <div class="row">
                    <!-- <div class="col-md-12">
                        <h1 class="page-header">
                             Page Heading <small>Create new page.</small>
                        </h1>
                    </div> -->
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Add About Details</h4>
        </div>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="form-group">
            <label class="col-sm-2 control-label">Choose Image</label>
            <div class="col-sm-10">
              <input type="file" class="form-control" name="addaboutimg">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Add Content</label>
            <div class="col-sm-10">
               <textarea class="form-control" name="addtext"></textarea>
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="uploadabout">Submit</button>
        </div>
        </form>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
//include Database Connection
include("../connection.php");

// check if form submitted
if(isset($_POST['uploadabout'])){

	// set target Directory
	$target_dir = "about_dpis/";
  $addtext=base64_encode($_POST['addtext']) ;

	//Define Target FIle Path
	$date=date('Y-m-d').time();
	$encry =base64_encode($date);

	$target_file =$target_dir . $encry.'.png';
	$target_file1 ="../about_dpis/" . $encry.'.png';

	move_uploaded_file($_FILES["addaboutimg"]["tmp_name"], $target_file1);
		

		
		// Insert file information into database
		$query ="INSERT INTO `dpis_about` (`about_img`, `content`)
		 VALUES ('$target_file', '$addtext')";
		if(mysqli_query($conn, $query)){
			
			//handle Query Execution Result
			echo "
            <script>
           alert('the file has been uploaded.');
           window.location.href='about_dpis.php';
            </script>
            ";
		}
		else{

			// handle query execution error
			echo "
            <script>
            alert('Failed!');
            </script>
            ";
			
		}
	
	
}
?>