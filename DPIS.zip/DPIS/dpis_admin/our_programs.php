<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
           
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="our_programs">Our Programs</a></li>
  <li><a href="addour_programs">Add Our Programs Details</a></li>
</ol>
                    </div>
                </div>
			 <div class="row">
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Show Our Programs</h4>
        </div>
        <!-- <div class="panel-body"> -->
        <div class="col-md-12">
                     <!--    Context Classes  -->
                    <div class="panel panel-default">  
                        <div class="panel-body">
                            <div class="table-responsive">
                            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Date</th>
                                            <th>Image</th>
                                            <th>Age Group</th>
                                            <th>Heading</th>
                                            <th>Description</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
        include('../connection.php');
		$i=1;
      // Fetch data from the database
                $query = "SELECT * FROM `dpis_program` ORDER BY `id` DESC"; 
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
					echo "<td>" . $i++ . "</td>";
                    echo "<td>" .  $row['time']. "</td>";
                    ?>
                    <td > <img src="../<?php echo $row['photo']; ?>" style="width:90px;"></td> 
                    <?php
                    echo "<td>" . $row['age_group'] . "</td>";
                    echo "<td>" . base64_decode($row['heading'])  . "</td>";
                    echo "<td>" . base64_decode($row['description']) . "</td>";
                   
                     ?>
    
    <td style=" DISPLAY: FLEX; ALIGN-ITEMS: CENTER; JUSTIFY-CONTENT: CENTER; HEIGHT: 155px;"><a href='?id=<?php echo $row['id']?>' onClick="return confirm('Do you really want to delete');"> <button style="margin-bottom:10px; background: #ff0303;"><i class="fa fa-trash" style="color: white;"></i></button> </a> &nbsp;
    <a href="updateprogram?UDTId=<?php echo $row['id'] ?>"><button style="margin-bottom:10px; background: #3e3ef5;"><i class="fa fa-edit" style="color:white;"></i></button></a>
                     
              </td> 
                    
                   <?php echo "</tr>";
                }
                ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--  end  Context Classes  -->
        </div>
      <!-- </div> -->
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php

include('../connection.php');
if(isset($_GET['id'])){
$id=$_GET['id'];
$query = "SELECT * FROM `dpis_program` WHERE `id`='$id'"; 
                $result = mysqli_query($conn, $query);
				$row=mysqli_fetch_assoc($result);
                 
					//    echo "<td>" . $row['photo'] . "</td>"; 
					   $path1="../".$row['photo'];  
					     unlink($path1);
						//  $id=$_GET['id'];
						 $sql="DELETE FROM `dpis_program` WHERE `id`='$id'";

        $result=mysqli_query($conn,$sql);
		if($result>0)
        {
            echo "
            <script>
           
           window.location.href='our_programs.php';
            </script>
            ";
        }
        else{
            echo "
            <script>
            alert('Failed!');
            </script>
            ";
        }
}
  ?>
