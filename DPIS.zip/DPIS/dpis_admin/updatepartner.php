<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                        <marquee direction="left" style="color: #223670; font-weight: 400;">ADARSH MANAS <span style="color: #b52e31;">SEVA</span> SANSTHA</marquee>
                        </h1>
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="../index">Our  Partners</a></li>
  <li class="active">Update Our Partner</li>
</ol>
                    </div>
                </div>
			 <div class="row">
                    <!-- <div class="col-md-12">
                        <h1 class="page-header">
                             Page Heading <small>Create new page.</small>
                        </h1>
                    </div> -->
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Update Partners Details</h4>
        </div>
        <?php
include('../connection.php');
  if(isset($_GET['UDTId']))
  {
      $id=$_GET['UDTId'];
   $sql="SELECT * FROM `ngopartner` WHERE `id`='$id'";
      $result=mysqli_query($conn,$sql);
      $row=mysqli_fetch_assoc($result); ?>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
        <div class="form-group">
            <label class="col-sm-2 control-label">Our Partner</label>
            <div class="col-sm-10">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
              <input type="text" class="form-control" name="pname" value="<?php echo $row['pname']; ?>">
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="savepname">Submit</button>
        </div>
        </form>
        <?php
  }
  ?>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
include('../connection.php');
  if(isset($_POST['savepname'])){
	$id=$_POST['id'];
	
    $pname=$_POST['pname'];
	


	  $update="UPDATE `ngopartner` SET `pname`='$pname' WHERE `id`='$id' ";
	$result=mysqli_query($conn,$update);
	if($result>0)
	{
		echo "
		<script>
	   alert('Done');
     window.location.href='showpartner.php';
		</script>
		";
	}
	else{
		echo "Fail  ";
	}
}
echo mysqli_error($conn);
 ?>
