<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="activity">Our Activity</a></li>
</ol>
                    </div>
                </div>
			 <div class="row">
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Add Activity</h4>
        </div>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="form-group">
            <label class="col-sm-2 control-label">Choose Images</label>
            <div class="col-sm-10">
              <input type="file" class="form-control" accept="image/*" name="addactivityimg[]" multiple required>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Heading</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="heading" placeholder="Enter Heading">
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="saveaward">Submit</button>
        </div>
        </form>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
//include Database Connection
include("../connection.php");

if(!empty($_FILES['addactivityimg']['name']))
{

$countfiles = count($_FILES['addactivityimg']['name']);

$totalFileUploaded = 0;
for($i=0;$i<$countfiles;$i++){
$filename = $_FILES['addactivityimg']['name'][$i];

## Location
$target_dir ="../activity_photo/";	
	
$filecount =1;
$files = glob($target_dir . "*");
if ($files)
{
$filecount = count($files)+1;
}
$encode=date('d/m/Y').time();
$final="gallery".base64_encode($encode)."-".$filecount;
$gal_thumb = "activity_photo/".$final. '.png' ;
$gal_thumb1 = '../activity_photo/' . $final. '.png' ;
$heading = base64_encode($_POST['heading']) ;
	
if(move_uploaded_file($_FILES['addactivityimg']['tmp_name'][$i],$gal_thumb1)){

$sql1="INSERT INTO dpis_activity (`photo`,`heading`) 
       VALUES ('$gal_thumb', '$heading')";
$result=mysqli_query($conn,$sql1);
$totalFileUploaded++;
}
}
if($result>0)
{
	echo "
	<script>
   alert('Done');
   window.location.href='activity.php';
	</script>
	";
}
else{
	echo "
	<script>
	alert('Failed!');
	</script>
	";
}
}
?>
