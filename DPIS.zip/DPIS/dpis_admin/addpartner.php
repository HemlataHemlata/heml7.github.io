<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                        <marquee direction="left" style="color: #223670; font-weight: 400;">ADARSH MANAS <span style="color: #b52e31;">SEVA</span> SANSTHA</marquee>
                        </h1>
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="../index">Our Partners</a></li>
  <!-- <li class="active">Data</li> -->
</ol>
                    </div>
                </div>
			 <div class="row">
                    <!-- <div class="col-md-12">
                        <h1 class="page-header">
                             Page Heading <small>Create new page.</small>
                        </h1>
                    </div> -->
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Add Partners</h4>
        </div>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="form-group">
            <label class="col-sm-2 control-label">Partners</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="pname" placeholder="Enter Partner Name">
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="savepartner">Submit</button>
        </div>
        </form>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
//include Database Connection
include("../connection.php");

// check if form submitted
if(isset($_POST['savepartner'])){

	// set target Directory
	
    $pname = $_POST['pname'];


	
		
		// Insert file information into database
		$query ="INSERT INTO `ngopartner` (`pname`)
		 VALUES ('$pname')";
		if(mysqli_query($conn, $query)){
			
			//handle Query Execution Result
			echo "
            <script>
           alert('the file has been uploaded.');
           window.location.href='showpartner.php';
            </script>
            ";
		}
		else{

			// handle query execution error
			echo "
            <script>
            alert('Failed!');
            </script>
            ";
			
		}
	
	
}
?>