<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="parents_says">Parents Says</a></li>
  <!-- <li class="active">Data</li> -->
</ol>
                    </div>
                </div>
			 <div class="row">
                    <!-- <div class="col-md-12">
                        <h1 class="page-header">
                             Page Heading <small>Create new page.</small>
                        </h1>
                    </div> -->
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Add Parents Says</h4>
        </div>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="form-group">
            <label class="col-sm-2 control-label">Choose Images</label>
            <div class="col-sm-10">
              <input type="file" class="form-control" name="addparentsimg">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="name" placeholder="Enter Name">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Profession</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="profession" placeholder="Enter Profession">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Description</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="description" placeholder="Enter Description">
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="saveparents">Submit</button>
        </div>
        </form>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
//include Database Connection
include("../connection.php");

// check if form submitted
if(isset($_POST['saveparents'])){

	// set target Directory
	$target_dir = "parents_says_img/";
  $name = $_POST['name'];
    $profession = $_POST['profession'];
    $description = base64_encode( $_POST['description']);

	//Define Target FIle Path
	$date=date('Y-m-d').time();
	$encry =base64_encode($date);

	$target_file =$target_dir . $encry.'.png';
	$target_file1 ="../parents_says_img/" . $encry.'.png';

	move_uploaded_file($_FILES["addparentsimg"]["tmp_name"], $target_file1);
		

		
		// Insert file information into database
		$query ="INSERT INTO `dpis_parents_says` (`name`, `photo`, `profession`, `description`)
		 VALUES ('$name','$target_file', '$profession', '$description')";
		if(mysqli_query($conn, $query)){
			
			//handle Query Execution Result
			echo "
            <script>
           alert('The Details has been uploaded.');
           window.location.href='parents_says.php';
            </script>
            ";
		}
		else{

			// handle query execution error
			echo "
            <script>
            alert('Failed!');
            </script>
            ";
			
		}
	
	
}
?>