<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="classes">Our Classes</a></li>
  <li class="active">Our Classes</li>
</ol>
                    </div>
                </div>
			 <div class="row">
                    <!-- <div class="col-md-12">
                        <h1 class="page-header">
                             Page Heading <small>Create new page.</small>
                        </h1>
                    </div> -->
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Update Our Classes</h4>
        </div>
        <?php
include('../connection.php');
  if(isset($_GET['UDTId']))
  {
      $id=$_GET['UDTId'];
      $sql="SELECT * FROM `dpis_classes` WHERE `id`='$id'";
      $result=mysqli_query($conn,$sql);
      $row=mysqli_fetch_assoc($result); ?>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="form-group">
            <div class="col-sm-10">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
                                            <input type="hidden" name="old_photo" value="<?php echo $row['photo']; ?>"/>
              <img src="../<?php echo $row['photo']; ?>" style="width:100px; border:1px solid black; box-shadow: 5px 10px #dfcfcf;">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Choose New img</label>
            <div class="col-sm-10">
              <input type="file" class="form-control" name="programimg">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Age Group</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="age_group" value="<?php echo $row['age_group']; ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Time</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="time" value="<?php echo $row['time'] ; ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Heading</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="heading" value="<?php echo base64_decode($row['heading']) ; ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Capacity</label>
            <div class="col-sm-10">
              <textarea class="form-control" name="des"><?php echo base64_decode($row['description']); ?></textarea>
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="saveprogram">Submit</button>
        </div>
        </form>
        <?php
  }
  ?>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
  
  if(isset($_POST['saveprogram'])){
	$id=$_POST['id'];
	$target_file1=$_POST['old_photo'];
  $age_group=$_POST['age_group'];
  $time=$_POST['time'];
	$heading= base64_encode($_POST['heading']) ;
    $des=base64_encode($_POST['des']);

// set target Directory
$target_dir = "classes_img";
if(!empty($_FILES["programimg"]["name"])){

//Define Target FIle Path
$target_file ='../'. $target_file1;



// Move Upload File
move_uploaded_file($_FILES["programimg"]["tmp_name"], $target_file);
}
	
 $update="UPDATE `dpis_classes` SET `photo`='$target_file1', `heading`='$heading', `description`='$des', `age_group`='$age_group', `time`='$time' WHERE `id`='$id'";
	$result=mysqli_query($conn,$update);
	if($result>0)
	{
		echo "
		<script>
	   alert('update successfully');
       window.location.href='classes.php';
		</script>
		";
	}
	else{
		echo "Fail  ";
	}
}

 ?>
