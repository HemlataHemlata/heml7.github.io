<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="our_programs">Our Programs</a></li>
</ol>
                    </div>
                </div>
			 <div class="row">
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Add Our Programs</h4>
        </div>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="form-group">
            <label class="col-sm-2 control-label">Choose Images</label>
            <div class="col-sm-10">
              <input type="file" class="form-control" name="addprogramimg">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Heading</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="heading" placeholder="Enter Heading">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Age Group</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="age_group" placeholder="Enter Age Group">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Time</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="time" placeholder="Enter Time">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Description</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="description" placeholder="Enter Description">
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="saveprograms">Submit</button>
        </div>
        </form>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
//include Database Connection
include("../connection.php");

// check if form submitted
if(isset($_POST['saveprograms'])){

	// set target Directory
	$target_dir = "programs_img/";
    $time = $_POST['time'];
    $age_group = $_POST['age_group'];
    $heading = base64_encode($_POST['heading']);
    $description = base64_encode( $_POST['description']);

	//Define Target FIle Path
	$date=date('Y-m-d').time();
	$encry =base64_encode($date);

	$target_file =$target_dir . $encry.'.png';
	$target_file1 ="../programs_img/" . $encry.'.png';

	move_uploaded_file($_FILES["addprogramimg"]["tmp_name"], $target_file1);
		

		
		// Insert file information into database
		$query ="INSERT INTO `dpis_program` (`photo`, `heading`, `description`, `time`, `age_group`)
		 VALUES ('$target_file', '$heading', '$description', '$time', '$age_group')";
		if(mysqli_query($conn, $query)){
			
			//handle Query Execution Result
			echo "
            <script>
           alert('the file has been uploaded.');
           window.location.href='our_programs.php';
            </script>
            ";
		}
		else{

			// handle query execution error
			echo "
            <script>
            alert('Failed!');
            </script>
            ";
			
		}
	
	
}
?>