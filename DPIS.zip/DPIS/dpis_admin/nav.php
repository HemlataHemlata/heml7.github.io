       <nav class="navbar navbar-default top-navbar"  role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index"> 
                    <!-- <img src="../img/logo.png" alt="logo" style="width:25%;">  -->
                     <h1><i class="fa fa-book-reader me-3"></i> D.P.I.S.</h1>
                </a>
            </div>
            <style>
                @media only screen and (max-width: 600px){
                    #hide-dropdown{
                        display: none;
                    }
                }
            </style>

            <ul class="nav navbar-top-links navbar-right" id="hide-dropdown" >
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li>
                            <a href="../logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="about_dpis"><i class="fa-solid fa-sliders"></i> About @DPIS</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa-solid fa-sliders"></i>Home<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="appointment">Appointment Details</a>
                            </li>
                            <li>
                                <a href="teachers">Popular Teachers</a>
                            </li>
                            <li>
                                <a href="parents_says">Parents Says</a>
                            </li>
                            <li>
                                  <a href="our_programs">Our Programs</a>
                             </li>
                        </ul>
                    </li>                    
                    <li>
                        <a href="activity"><i class="fa-solid fa-award"></i> Activity</a>
                    </li>
                    <li>
                        <a href="career"><i class="fa-solid fa-fire"></i>career</a>
                    </li>
                  <li>
                        <a href="classes"><i class="fa-solid fa-users-rectangle"></i>Classes</a>
                    </li>
                    <li>
                        <a href="events"><i class="fa-solid fa-photo-film"></i> Events & Celebrations</a>
                    </li>
                    <li>
                        <a href="contactus"><i class="fa-solid fa-address-book"></i> Contact Us Details</a>
                    </li>
                    <li>
                            <a href="../logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                </ul>

            </div>

        </nav>