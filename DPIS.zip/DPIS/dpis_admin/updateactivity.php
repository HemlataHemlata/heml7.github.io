<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<head>
<?php
    require_once('link.php');
    ?>
</head>
<body>
    <div id="wrapper">
    <?php
    require_once('nav.php');
    ?>
    <style>
        .form-control{
            margin-bottom: 18px !important;
        }
        .butn-self{
            display: flex;
            margin: auto;
        }
    </style>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
            <div class="row">
                    <div class="col-md-12">
						<ol class="breadcrumb">
  <li><a href="../index">Home</a></li>
  <li><a href="activity">Activity</a></li>
  <li class="active">Update Activity</li>
</ol>
                    </div>
                </div>
			 <div class="row">
                    <div class="panel panel-default">
        <div class="panel-heading">
        <h4 class="panel-title">Update Activity</h4>
        </div>
        <?php
include('../connection.php');
  if(isset($_GET['UDTId']))
  {
      $id=$_GET['UDTId'];
      $sql="SELECT * FROM `dpis_activity` WHERE `id`='$id'";
      $result=mysqli_query($conn,$sql);
      $row=mysqli_fetch_assoc($result); ?>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="form-group">
            <div class="col-sm-10">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
                                            <input type="hidden" name="old_photo" value="<?php echo $row['photo']; ?>"/>
              <img src="../<?php echo $row['photo']; ?>" style="width:100px; border:1px solid black; box-shadow: 5px 10px #dfcfcf;">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Choose New Image</label>
            <div class="col-sm-10">
              <input type="file" class="form-control" name="activityimg">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Heading</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="heading" value="<?php echo base64_decode($row['heading']) ; ?>">
            </div>
          </div>
          <button type="submit" class="btn btn-primary butn-self" name="saveactivity">Submit</button>
        </div>
        </form>
        <?php
  }
  ?>
      </div>
                </div> 
                 <!-- /. ROW  -->
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
<?php
  
  if(isset($_POST['saveactivity'])){
	$id=$_POST['id'];
	$target_file1=$_POST['old_photo'];
  $heading = base64_encode($_POST['heading']) ;

// set target Directory
$target_dir = "activity_photo";
if(!empty($_FILES["activityimg"]["name"])){

//Define Target FIle Path
$target_file ='../'. $target_file1;



// Move Upload File
move_uploaded_file($_FILES["activityimg"]["tmp_name"], $target_file);
}
	
 $update="UPDATE `dpis_activity` SET `photo`='$target_file1', `heading`='$heading' WHERE `id`='$id'";
	$result=mysqli_query($conn,$update);
	if($result>0)
	{
		echo "
		<script>
	   alert('Done');
       window.location.href='activity.php';
		</script>
		";
	}
	else{
		echo "Fail  ";
	}
}
 ?>
