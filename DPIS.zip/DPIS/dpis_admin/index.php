﻿<?php
    session_start();
    if(isset($_SESSION['id'])){

   ?>
	    <?php
    }
    else{
        echo "
        <script>
       alert('Please Login');
       window.location.href='../admin';
        </script>
        ";
    }
    ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <?php
    require_once('link.php');
    ?>
</head>
<style>
    .box-title{
        margin-bottom: 28px;
    }
</style>
<body>

    <div id="wrapper">
 <!-- nav start  -->
<?php
require_once('nav.php');
?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                        <marquee direction="left" style="color: #223670; font-weight: 400;">DELHI PUBLIC <span style="color: #b52e31;">INTERNATIONAL</span> SCHOOL KAIMUR, BIHAR</marquee>
                        </h1>
						<ol class="breadcrumb">
   <li><a href="../index">Delhi Public International School</a></li>
  <li><a href="index">Home</a></li>
  <!-- <li class="active">Data</li> -->
</ol>
                    </div>
                </div>	
                <div class="container-fluid">
     	<div class="row">
            <div class="col-md-12" >
<img src="../img/logo.png" alt="logo-DPIS" style="height:360px; margin: auto; display: flex; ">
            </div>
			
<!-- 			
		    <div class="col-lg-4 col-12 text-center" style="border: 1px solid black; padding: 18px; height: 350px;">
                <div class="box-column">
                    <div class="box-header box-header-instagram">
                        <i class="fa fa-pencil fa-3x" aria-hidden="true"></i>
                    </div>
                    <div class="box-bottom">
                        <div class="box-title instagram-title">
					    	<h3 class="text-danger"></h3>
					    </div>
						<div class="box-text" style="height: 150px;">
						At Petroleum Trading Group, we navigate the vast sea of the petroleum industry, and provide tailored solutions for offshore operations.
						</div>
						<a href="index" class="btn btn-info" style="margin-top: 18px;">Show More</a>
                    </div>
				 </div>
			</div>	  -->
				 
			<!-- <div class="col-lg-4 col-12 text-center" style="border: 1px solid black; padding: 18px; height: 350px;">
                <div class="box-column">
                    <div class="box-header box-header-facebook">
                        <i class="fa fa-pencil fa-3x" aria-hidden="true"></i>
                    </div>
                    <div class="box-bottom">
                        <div class="box-title facebook-title">
					       <h3 class="text-danger">Commercial Brokers</h3>
					    </div>
				     	<div class="box-text" style="height: 150px;">
						 Brokers
Exclusive Property
Our mission is simple yet profound – to empower businesses, investors and property owners to achieve their real estate goals. We believe that success is built on a foundation of trust, transparency and tireless dedication to the ambitions of our clients.
						</div>
				    	<a href="../../Commercial Brokers/dash_boardC/index" class="btn btn-info" style="margin-top: 18px;">Show More</a>
                    </div>
				 </div>
			</div>	 -->
            <!-- <div class="col-lg-4 col-12 text-center" style="border: 1px solid black; padding: 18px; height: 350px;">
                <div class="box-column">
                    <div class="box-header box-header-twitter">
                        <i class="fa fa-pencil fa-3x" aria-hidden="true"></i>
                    </div>
                    <div class="box-bottom">
                        <div class="box-title twitter-title">
					    	<h3 class="text-danger">Shipping services</h3>
					    </div>
						<div class="box-text" style="height: 150px;">
						We understand that one size does not fit all. Our shipment management solutions are customizable to meet the unique requirements of each client, ensuring flexibility and adaptability.
						</div>
						<a href="../../dashboard/index" class="btn btn-info" style="margin-top: 18px;">Show More</a>
                    </div>
				 </div>
			</div>  -->
		</div>		
    </div>
				
		
				<!-- <footer><p>All right reserved. Template by: <a href="#"></a></p></footer> -->
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
	 
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
	
	
	<script src="assets/js/easypiechart.js"></script>
	<script src="assets/js/easypiechart-data.js"></script>
	
	
    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>


</body>


</html>