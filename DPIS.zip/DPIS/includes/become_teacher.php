 <div class="container-xxl py-5">
            <div class="container">
                <div class="bg-light rounded">
                    <div class="row g-0">
                        <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s" style="min-height: 400px;">
                            <div class="position-relative h-100" style="box-shadow: -9px -7px 9px 0px #c9c2c2;" >
                                <img class="position-absolute w-100 h-100 rounded" src="img/call-to-action.jpeg"
                                    style="object-fit: cover;">
                            </div>
                        </div>
                        <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s" style="box-shadow: 9px 9px 13px gray;" >
                            <div class="h-100 d-flex flex-column justify-content-center p-5">
                                <h1 class="mb-4">Become A Teacher</h1>
                                <p class="mb-4">Our teachers are experienced, qualified, passionate and motivated to create an enriching learning experience for little ones. They are engrossed in creating varied teaching and learning techniques within an innovative curriculum. Our teachers with various learning pedagogies kindle child’s interest towards their first step of learning and nurture them holistically.
                                </p>
                                <a class="btn btn-primary py-3 px-5" href="career">Get Started Now<i
                                        class="fa fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>