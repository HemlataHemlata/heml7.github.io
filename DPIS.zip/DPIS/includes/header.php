 <!-- top-header -->
 <style>
            .top-img img{
                width: 70px;
            }
.maa-img img{
width: 90px;
}
.text-danger{
    color: #ed3237 !important;
}
.bg-warning{
    background-color: #fff212 !important;
}
.top-heading h2{
    font-size: 37px;
    font-weight: 1000 ;
    font-family: "Noto Serif", serif;
    font-optical-sizing: auto;
}
#second-slider{
    display: none;
}
#first-slider{
    display: block;
}
           

@media only screen and (max-width: 600px) {
  .top-img img {
    width: 40px;
  }
  .maa-img img{
    width: 50px;
  }
  .top-heading h2{
    font-family: "Noto Serif", serif;
    font-optical-sizing: auto;
    font-size: 18px;
    font-weight: bolder;
    text-align: center;
    padding: 1px;
  }
  #second-slider{
    display: block;
  }
  #first-slider{
    display: none;
  }
}
         </style>
        <div class="d-flex align-items-center justify-content-between mx-auto container-fluid py-2 border-bottom bg-warning">
            <div class="top-img" >
            <a href="index"><img src="img/logo.png" alt="logo"></a>
            </div>
            <div class="top-heading d-flex align-items-center">
                <h2 class="text-danger" >DELHI PUBLIC INTERNATIONAL SCHOOL KAIMUR, BIHAR </h2>
            </div>
            <div class="maa-img" >
                <img src="img/saraswati_maa.png" alt="maa-img"  >
            </div>
        </div>
        <!-- top-heade-end -->

        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top px-4 px-lg-5 py-lg-0">
            <a href="index" class="navbar-brand">
                <h1 class="m-0 text-primary"><i class="fa fa-book-reader me-3"></i></h1>
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-auto">
                    <a href="index" class="nav-item nav-link active">Home</a>
                    <a href="about" class="nav-item nav-link">About Us</a>
                    <a href="classes" class="nav-item nav-link">Classes</a>
                    <a href="activity" class="nav-item nav-link">Activities</a>
                    <a href="events" class="nav-item nav-link">Events & Celebrations </a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu rounded-0 rounded-bottom border-0 shadow-sm m-0">
                        <a href="curriculum" class="dropdown-item">Our Curriculum</a>
                            <a href="index#programs" class="dropdown-item">Our Programs</a>
                            <!-- <a href="activity" class="dropdown-item">Activities @DPIS</a> -->
                            <!-- <a href="events" class="dropdown-item">Events & Celebrations </a> -->
                            <a href="team" class="dropdown-item">Popular Teachers @DPIS</a>
                            <a href="call-to-action" class="dropdown-item">Become A Teachers</a>
                            <a href="appointment" class="dropdown-item">Make Appointment</a>
                            <a href="parents" class="dropdown-item">Parent's Connect</a>
                            <a href="testimonial" class="dropdown-item">Testimonial</a>
                            <a href="career" class="dropdown-item">Career</a>
                        </div>
                    </div>
                    <a href="contact" class="nav-item nav-link">Contact Us</a>
                    <a href="admin" class="nav-item nav-link">Admin</a>
                </div>
                <a href="contact#enquiry" class="btn btn-primary rounded-pill px-3 d-none d-lg-block">Enquiry<i
                        class="fa fa-arrow-right ms-3"></i></a>
            </div>
        </nav>
        <!-- Navbar End -->

