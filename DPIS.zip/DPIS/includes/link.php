<meta charset="utf-8">
    <title>Delhi Public International School Kaimur, Bihar</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    
    <meta name="keywords" content="delhi public school, south delhi public school, delhi public school fees, delhi public school varanasi, about delhi public school, address of delhi public school, admission fees of delhi public school, delhi public school board, branches of delhi public school, delhi public school chairman, delhi public school coimbatore reviews, delhi public school contact number, chairman of delhi public school, central books delhi public school, career in delhi public school, contact number of delhi public school, delhi public school banaras, delhi public school delhi, digital campus delhi public school, east delhi public school, delhi public school email id, east delhi public school photos, eastern delhi public school, delhi public school founder, fee structure of delhi public school, fulbari delhi public school, famous alumni of delhi public school, delhi public school ghana, hindi teacher vacancy in delhi public school, how is delhi public school, delhi public school india, delhi public school international, international delhi public school, is delhi public school good, junior delhi public school, junior delhi public school near me, junior delhi public school limited, kids delhi public school, delhi public school logo, delhi public school login, list of delhi public school in india, library of delhi public school, delhi public school monthly fees class 1, delhi public school monthly fees class 6, modern delhi public school, modern delhi public school, delhi public school near me, north delhi public school vacancy, future kids school, kids school lunch ideas, kids school supplies, kids school shoes, kids school uniforms, kids school backpacks, kids school clothes, kids school labels, kids school desk, kids school snacks, kids school age, kids school accessories, kids school art book, kids school art storage, kids school art organizer, activities for kids school holidays, apple kids school, amazing kids school, kids school bag, kids school bus toy, black kids school shoes, kids school clothes near me, kids school events, kids school events, kids school essentials, kids school earbuds, kids school email, kids school enrollment, DELHI PUBLIC INTERNATIONAL SCHOOL KAIMUR, BIHAR, dpis01principal@gmail.com, 9305263363, 7781979062, Kaimur, Bihar, Get In Touch, Contact, mail, D.P.I.S.">

    <meta name="description" content="Delhi Public International School's mission is to offer a stimulating and enriching educational journey for young learners as they embark on their initial steps in their academic path. We are dedicated to cultivating a serene, engaging, and stimulating environment that promotes the social, physical, emotional, and cognitive growth of each child.Our goal is to instill social, moral, and cultural values in young learners while fostering a deep sense of respect and responsibility toward the environment.">

    <!-- Favicon -->
    <link href="img/logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&amp;family=Inter:wght@600&amp;family=Lobster+Two:wght@700&amp;display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="cdn.jsdelivr.net/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">