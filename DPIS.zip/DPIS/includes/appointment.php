<div class="container-xxl py-5">
            <div class="container">
                <div class="bg-light rounded">
                    <div class="row g-0">
                        <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                            <div class="h-100 d-flex flex-column justify-content-center p-5">
                                <h1 class="mb-4">Make Appointment</h1>
                                <form method="POST" >
                                    <div class="row g-3">
                                        <div class="col-sm-6">
                                            <div class="form-floating">
                                                <input type="text" class="form-control border-0" id="gname" name="name" placeholder="Enter Parents Name">
                                                <label for="gname">Enter Parents Name</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-floating">
                                                <input type="number" class="form-control border-0" id="number" name="email" placeholder="Enter Parents Mobile" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                                <label for="number">Enter Parents Mobile</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-floating">
                                                <input type="text" class="form-control border-0" id="cname" name="child_name" placeholder="Enter Your Child Name">
                                                <label for="cname">Enter Your Child Name</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-floating">
                                                <input type="text" class="form-control border-0" id="cage" name="child_age" placeholder="Enter Your Address">
                                                <label for="cage">Enter Your Address</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <textarea class="form-control border-0" placeholder="Leave a message here" id="message" name="message" style="height: 100px"></textarea>
                                                <label for="message">Write a message</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button class="btn btn-primary w-100 py-3" type="submit" name="submitbutton" >Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s" style="min-height: 400px;">
                            <!-- <div class="position-relative h-100" style="box-shadow: 9px 9px 13px gray;" >
                                <img class="position-absolute w-100 h-100 rounded" src="img/back-to-school-gif.gif" style="object-fit: cover;">
                            </div> -->
                            <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/appointment-sllider-1.jpg" class="d-block w-100" alt="slider-img" style="height: 490px;" >
    </div>
    <div class="carousel-item">
      <img src="img/appointment-sllider-4.jpg" class="d-block w-100" alt="slider-img"  style="height: 490px;">
    </div>
    <div class="carousel-item">
      <img src="img/appointment-sllider-3.jpg" class="d-block w-100" alt="slider-img"  style="height: 490px;">
    </div>
    <div class="carousel-item">
      <img src="img/appointment-sllider-5.jpg" class="d-block w-100" alt="slider-img"  style="height: 490px;">
    </div>

    <div class="carousel-item">
      <img src="img/appointment-sllider-6.jpg" class="d-block w-100" alt="slider-img"  style="height: 490px;">
    </div>  </div>
  <button class="carousel-control-prev visually-hidden" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next visually-hidden" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
include('connection.php');
if(isset($_POST['submitbutton'])){
      $name = $_POST["name"];
       $email = $_POST["email"];
       $child_name = $_POST["child_name"];
       $child_age = $_POST["child_age"];
       $message = $_POST["message"];
$query="INSERT INTO `dpis_appointment` (`name`, `email`, `child_name`, `child_age`, `message`) VALUES('$name', '$email', '$child_name', '$child_age', '$message')";
$result=mysqli_query($conn,$query);
// echo mysqli_error($conn);
if($result){
echo " <script>
alert('Data Inserted');
</script> ";
}
else{
   echo "data is not inserted";
}

}

?>