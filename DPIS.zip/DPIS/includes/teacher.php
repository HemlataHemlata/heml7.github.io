<div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Popular Teachers</h1>
                    <p class="text-primary">The Heart of Our School</p>
                </div>
                <div class="row g-4">
                <?php
      include('connection.php');
      $sql="SELECT * FROM `dpis_teachers`   ORDER BY `id` DESC";
      $result= mysqli_query($conn, $sql);
      foreach($result as $res){
?>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item position-relative">
                            <img class="img-fluid rounded-circle" style="height: 500px; width: 100%; padding: 15px; box-shadow: -12px -9px 16px 0px gray; "  src="<?php echo $res['photo']; ?>" alt="teacher-img">
                            <div class="team-text">
                                <h3 style="font-size: 16px;" ><?php echo ucwords($res['name']) ; ?></h3>
                                <p><?php echo ucwords($res['description']) ; ?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                  }
                    ?>
                    <!-- <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item position-relative">
                            <img class="img-fluid rounded-circle w-75" src="img/team-2.jpg" alt="teacher-img">
                            <div class="team-text">
                                <h3>Full Name</h3>
                                <p>Designation</p>
                                <div class="d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href="#"><i
                                            class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href="#"><i
                                            class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary  mx-1" href="#"><i
                                            class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item position-relative">
                            <img class="img-fluid rounded-circle w-75" src="img/team-3.jpg" alt="teacher-img">
                            <div class="team-text">
                                <h3>Full Name</h3>
                                <p>Designation</p>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>