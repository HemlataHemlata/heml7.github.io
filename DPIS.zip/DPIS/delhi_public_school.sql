-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2024 at 02:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `delhi_public_school`
--

-- --------------------------------------------------------

--
-- Table structure for table `dpis_about`
--

CREATE TABLE `dpis_about` (
  `id` int(11) NOT NULL,
  `about_img` varchar(125) NOT NULL,
  `content` varchar(1500) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_about`
--

INSERT INTO `dpis_about` (`id`, `about_img`, `content`, `date&time`) VALUES
(2, 'about_dpis/MjAyNC0wOS0wMzE3MjUzNjI0MTg=.png', 'TmlyYWogS3VtYXIgTWlzaHJhIGlzIEZvdW5kZXIsIENoYWlybWFuICYgTUQgb2YgRGVsaGkgUHVibGljIEludGVybmF0aW9uYWwgU2Nob29sIEdyb3VwIG9mIFNjaG9vbHMuIEhlIGlzIEZvdW5kaW5nIFByZXNpZGVudCBvZiBFYXJseSBDaGlsZGhvb2QgQ2FyZSAmIERldmVsb3BtZW50IEVkdWNhdG9y4oCZcyBBc3NvY2lhdGlvbiAoRUNDREEpLCBhIHZvbHVudGFyeSBvcmdhbmlzYXRpb24gd29ya2luZyBmb3IgdGhlIHdlbGZhcmUgb2YgZWFybHkgbGVhcm5lcnMsIGVkdWNhdG9ycywgYW5kIHBhcmVudHMuIEhlIGlzIFZpY2UgUHJlc2lkZW50IG9mIEVhcmx5IENoaWxkaG9vZCBBc3NvY2lhdGlvbiAoRUNBKSBhbmQgQ2hhaXJtYW4tU2Nob29sIEVkdWNhdGlvbiBEZXBhcnRtZW50LCBDZW50cmUgZm9yIEVkdWNhdGlvbiBHcm93dGggYW5kIFJlc2VhcmNoIChDRUdSKS4gaW4gc2Nob29sIGVkdWNhdGlvbi4gTmlyYWogTWlzaHJhIGlzIGEgd2VsbC1rbm93biBuYW1lIGluIFNjaG9vbCBFZHVjYXRpb24gU2VjdG9yOyBoZSBpcyBhIFRFRCBTcGVha2VyIGFuZCBpcyB0aGUgbW9zdCBzb3VnaHQtYWZ0ZXIgc3BlYWtlciBvbiBlZHVjYXRpb24gYW5kIGVudHJlcHJlbmV1cnNoaXAgaW4gdGhlIGNvdW50cnkuIEhlIGluc3BpcmVzIGFuZCBlbmNvdXJhZ2VzIHRob3VzYW5kcyBvZiBwZW9wbGUgdG8gcmVhbGlzZSB0aGVpciB0cnVlIHBvdGVudGlhbCBhbmQgaGVscCB0aGVtIHRvIGJlY29tZSBzdWNjZXNzZnVsIEVudHJlcHJlbmV1cnMuIFRlbnMgb2YgdGhvdXNhbmRzIG9mIHBhcmVudHMgaGF2ZSBiZWVuIGJlbmVmaXR0ZWQgZnJvbSBoaXMgUGFyZW50aW5nIFdvcmtzaG9wcyDigJxBcnQgb2YgUGFyZW50aW5n4oCdLg==', '2024-09-03 11:20:18');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_activity`
--

CREATE TABLE `dpis_activity` (
  `id` int(11) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `heading` varchar(200) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_activity`
--

INSERT INTO `dpis_activity` (`id`, `photo`, `heading`, `date&time`) VALUES
(7, 'activity_photo/galleryMTAvMDkvMjAyNDE3MjU5NjU1NzA=-2.png', 'RWR1Y2F0aW9uYWwgVG91cnMg', '2024-09-10 10:52:50'),
(10, 'activity_photo/galleryMTAvMDkvMjAyNDE3MjU5NjU2NTU=-4.png', 'cGxheWdyb3Vw', '2024-09-10 10:54:15'),
(11, 'activity_photo/galleryMTAvMDkvMjAyNDE3MjU5Njc2MTQ=-5.png', 'IENvbXBldGl0aW9u', '2024-09-10 11:26:54'),
(12, 'activity_photo/galleryMTAvMDkvMjAyNDE3MjU5Njc4Mzc=-4.png', 'IFdvcmtzaG9w', '2024-09-10 11:30:37');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_admin`
--

CREATE TABLE `dpis_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(125) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `password` varchar(125) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_admin`
--

INSERT INTO `dpis_admin` (`id`, `name`, `email`, `mobile`, `password`, `date&time`) VALUES
(1, 'niraj', 'YWRtaW5AYWRtaW4=', '7781979062', 'YWRtaW5AYWRtaW4=', '2024-09-03 09:59:15');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_appointment`
--

CREATE TABLE `dpis_appointment` (
  `id` int(11) NOT NULL,
  `name` varchar(125) NOT NULL,
  `email` varchar(55) NOT NULL,
  `child_name` varchar(50) NOT NULL,
  `child_age` varchar(10) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_appointment`
--

INSERT INTO `dpis_appointment` (`id`, `name`, `email`, `child_name`, `child_age`, `message`, `date&time`) VALUES
(1, 'hello', 'admin@admin', 'jiya', '7', 'hg', '2024-09-07 11:45:08');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_career`
--

CREATE TABLE `dpis_career` (
  `id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `resume` varchar(500) NOT NULL,
  `message` varchar(1500) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_career`
--

INSERT INTO `dpis_career` (`id`, `name`, `email`, `mobile`, `resume`, `message`, `date&time`) VALUES
(5, 'testing', 'india@gmail.com', '1212121212', 'career_pdf/MjAyNC0wOS0wNzE3MjU3MTE3MzY2NmRjNDU3OGUzZjA3.pdf', 'NA', '2024-09-07 12:22:16');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_classes`
--

CREATE TABLE `dpis_classes` (
  `id` int(11) NOT NULL,
  `heading` varchar(200) NOT NULL,
  `age_group` varchar(20) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `time` varchar(20) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_classes`
--

INSERT INTO `dpis_classes` (`id`, `heading`, `age_group`, `photo`, `description`, `time`, `date&time`) VALUES
(7, 'QXJ0ICYgRHJhd2luZw==', '3-5 ', 'classes_img/MjAyNC0wOS0xMTE3MjYwMzQzOTQ=.png', 'MzAgS2lkcw0K', '9-10 AM', '2024-09-11 05:59:54'),
(8, 'Q29sb3IgTWFuYWdlbWVudA==', '3-5 ', 'classes_img/MjAyNC0wOS0xMTE3MjYwMzQ0NDc=.png', 'MzAgS2lkcw==', '9-10 AM', '2024-09-11 06:00:47'),
(9, 'QXRobGV0aWMgJiBEYW5jZQ==', '3-8 ', 'classes_img/MjAyNC0wOS0xMTE3MjYwMzQ1MzY=.png', 'MzAgS2lkcw==', '9 - 11 am', '2024-09-11 06:02:16'),
(10, 'TGFuZ3VhZ2UgJiBTcGVha2luZw==', '3-12 ', 'classes_img/MjAyNC0wOS0xMTE3MjYwMzQ1NzA=.png', 'MzAgS2lkcw==', '9-12 pm', '2024-09-11 06:02:50'),
(11, 'UmVsaWdpb24gJiBIaXN0b3J5', '3-15 ', 'classes_img/MjAyNC0wOS0xMTE3MjYwMzQ2MTE=.png', 'MzAgS2lkcw==', '12- 3 pm', '2024-09-11 06:03:31'),
(12, 'R2VuZXJhbCBLbm93bGVkZ2U=', '8-15 ', 'classes_img/MjAyNC0wOS0xMTE3MjYwMzQ2NDc=.png', 'MzAgS2lkcw==', '9-12 pm', '2024-09-11 06:04:07');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_contact`
--

CREATE TABLE `dpis_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(125) NOT NULL,
  `email` varchar(125) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `place` varchar(150) NOT NULL,
  `message` varchar(1500) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_contact`
--

INSERT INTO `dpis_contact` (`id`, `name`, `email`, `mobile`, `place`, `message`, `date&time`) VALUES
(2, 'hema', 'admin@admin', '09878909865', '', 'NA', '2024-09-07 10:59:07'),
(6, 'testing', 'india@gmail.com', '2222222222', 'bihar', 'Nothing', '2024-09-11 07:19:12'),
(9, 'testing', 'admin@admin', '8786453423', 'jlkalksa', 'wasfdgh', '2024-09-12 11:33:19'),
(10, 'testing', 'admin@admin', '8786453423', 'jlkalksa', 'wasfdgh', '2024-09-12 11:34:08');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_events`
--

CREATE TABLE `dpis_events` (
  `id` int(11) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_events`
--

INSERT INTO `dpis_events` (`id`, `photo`, `date&time`) VALUES
(4, 'events_img/galleryMTEvMDkvMjAyNDE3MjYwMzc3MTg=-4.png', '2024-09-11 06:55:18'),
(5, 'events_img/galleryMTEvMDkvMjAyNDE3MjYwMzc3MTg=-5.png', '2024-09-11 06:55:18'),
(6, 'events_img/galleryMTEvMDkvMjAyNDE3MjYwMzc3MTg=-6.png', '2024-09-11 06:55:18'),
(7, 'events_img/galleryMTEvMDkvMjAyNDE3MjYwMzc3MTg=-7.png', '2024-09-11 06:55:18'),
(8, 'events_img/galleryMTEvMDkvMjAyNDE3MjYwMzg0MTI=-5.png', '2024-09-11 07:06:52'),
(9, 'events_img/galleryMTEvMDkvMjAyNDE3MjYwMzg0MTI=-6.png', '2024-09-11 07:06:52');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_parents_says`
--

CREATE TABLE `dpis_parents_says` (
  `id` int(11) NOT NULL,
  `name` varchar(125) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `profession` varchar(250) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_parents_says`
--

INSERT INTO `dpis_parents_says` (`id`, `name`, `photo`, `description`, `profession`, `date&time`) VALUES
(6, 'hello mini', 'parents_says_img/MjAyNC0wOS0wOTE3MjU4NzI1MTQ=.png', 'VGVtcG9yIHN0ZXQgbGFib3JlIGRvbG9yIGNsaXRhIHN0ZXQgZGlhbSBhbWV0IGlwc3VtIGRvbG9yIGR1byBpcHN1bSByZWJ1bSBzdGV0IGRvbG9yIGFtZXQgZGlhbSBzdGV0LiBFc3Qgc3RldCBlYS', 'profession here', '2024-09-09 09:01:54'),
(7, 'testing', 'parents_says_img/MjAyNC0wOS0wOTE3MjU4NzMzNzk=.png', 'VGVtcG9yIHN0ZXQgbGFib3JlIGRvbG9yIGNsaXRhIHN0ZXQgZGlhbSBhbWV0IGlwc3VtIGRvbG9yIGR1byBpcHN1bSByZWJ1bSBzdGV0IGRvbG9yIGFtZXQgZGlhbSBzdGV0LiBFc3Qgc3RldCBlYSBsYWJvcmUgZG9sb3IgY2xpdGEgc3RldCBkaWFtIGFtZXQgaXBzdW0gZG9sb3IgZHVvIGlwc3VtIHJlYnVtIHN0ZXQgZG9sb3IgYS', 'profession here', '2024-09-09 09:16:19'),
(8, 'Bunny', 'parents_says_img/MjAyNC0wOS0wOTE3MjU4ODQ1MzM=.png', 'RGVzY3JpcHRpb24gaGVyZQ==', 'profession here', '2024-09-09 12:22:13');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_program`
--

CREATE TABLE `dpis_program` (
  `id` int(11) NOT NULL,
  `heading` varchar(200) NOT NULL,
  `age_group` varchar(20) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `time` varchar(20) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_program`
--

INSERT INTO `dpis_program` (`id`, `heading`, `age_group`, `photo`, `description`, `time`, `date&time`) VALUES
(2, 'YWN0aXZpdHkgY2x1Yg==', '1.5 - 3', 'programs_img/MjAyNC0wOS0wOTE3MjU4NzgzMDY=.png', 'YSBjaGlsZCdzIGVhcmx5IHllYXJzIGFyZSBjcml0aWNhbCBmb3IgdGhlaXIgZGV2ZWxvcG1lbnQsIGFzIHRoZXkgYXJlIGV4Y2VwdGlvbmFsbHkgcXVpY2sgdG8gbGVhcm4uIEF0IERQSVMsIHdlIHJlY29nbml6ZSB0aGUgaW1wb3J0YW5jZSBvZiB0aGlzIGZvcm1hdGl2ZSBwZXJpb2QgYW5kIGhhdmUgY3JhZnRlZCBvdXIgcHJvZ3JhbXMgdG8gY2F0ZXIgdG8gZWFjaCBjaGlsZCdzIGluZGl2aWR1YWwgZWR1Y2F0aW9uYWwgam91cm5leSBhbmQgcGxheWZ1bCBleHBsb3JhdGlvbi4gT3VyIGdvYWwgaXMgdG8gb2ZmZXIgZW5yaWNoaW5nLCBtb3RpdmF0aW5nLCBhbmQgaW5zcGlyaW5nIGV4cGVyaWVuY2VzIGZyb20gYSB5b3VuZyBhZ2UuIFRocm91Z2ggb3VyIHRob3VnaHRmdWxseSBkZXNpZ25lZCBBQ01FUyBjdXJyaWN1bHVtLCB3ZSBwcm92aWRlIGEgaGFybW9uaW91cyBibGVuZCBvZiBhY2FkZW1pYyBhbmQgcGxheS1iYXNlZCBhY3Rpdml0aWVzIHRoYXQgZW5nYWdlIGFuZCBzdGltdWxhdGUgY2hpbGRyZW4uIFdpdGggc21hbGxlciBjbGFzcyBzaXplcyBhbmQgYSBmbGV4aWJsZSwgcGxheS1mb2N1c2VkIGFwcHJvYWNoLCB3ZSBlbnN1cmUgdGhhdCBldmVyeSBjaGlsZCByZWNlaXZlcyBwZXJzb25hbGl6ZWQgYXR0ZW50aW9uLCBwcm9ncmVzc2VzIGF0IHRoZWlyIG93biBwYWNlLCBhbmQgYnVpbGRzIGNvbmZpZGVuY2Uu', '9-12 pm', '2024-09-09 10:38:26'),
(3, 'bnVyc2VyeQ==', '2.5 - 3.5', 'programs_img/MjAyNC0wOS0xMDE3MjU5NTE1ODk=.png', 'RGVzY3JpcHRpb24gaGVyZQ==', '9 - 11 am', '2024-09-10 06:59:49'),
(4, 'cGxheWdyb3Vw', '1.8 - 2.5', 'programs_img/MjAyNC0wOS0xMDE3MjU5NTE2ODg=.png', 'RGVzY3JpcHRpb24gaGVyZS4uLg==', '9-12 pm', '2024-09-10 07:01:28');

-- --------------------------------------------------------

--
-- Table structure for table `dpis_teachers`
--

CREATE TABLE `dpis_teachers` (
  `id` int(11) NOT NULL,
  `name` varchar(125) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `date&time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dpis_teachers`
--

INSERT INTO `dpis_teachers` (`id`, `name`, `photo`, `description`, `date&time`) VALUES
(2, 'hello first', 'popular_teachers/MjAyNC0wOS0wOTE3MjU4NjAyMTk=.png', 'testing', '2024-09-09 05:36:59'),
(3, 'shiva testing', 'popular_teachers/MjAyNC0wOS0wOTE3MjU4NjI0NDg=.png', 'add designation here', '2024-09-09 06:14:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dpis_about`
--
ALTER TABLE `dpis_about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_activity`
--
ALTER TABLE `dpis_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_admin`
--
ALTER TABLE `dpis_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_appointment`
--
ALTER TABLE `dpis_appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_career`
--
ALTER TABLE `dpis_career`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_classes`
--
ALTER TABLE `dpis_classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_contact`
--
ALTER TABLE `dpis_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_events`
--
ALTER TABLE `dpis_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_parents_says`
--
ALTER TABLE `dpis_parents_says`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_program`
--
ALTER TABLE `dpis_program`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dpis_teachers`
--
ALTER TABLE `dpis_teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dpis_about`
--
ALTER TABLE `dpis_about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dpis_activity`
--
ALTER TABLE `dpis_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `dpis_admin`
--
ALTER TABLE `dpis_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dpis_appointment`
--
ALTER TABLE `dpis_appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dpis_career`
--
ALTER TABLE `dpis_career`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dpis_classes`
--
ALTER TABLE `dpis_classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `dpis_contact`
--
ALTER TABLE `dpis_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `dpis_events`
--
ALTER TABLE `dpis_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dpis_parents_says`
--
ALTER TABLE `dpis_parents_says`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dpis_program`
--
ALTER TABLE `dpis_program`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dpis_teachers`
--
ALTER TABLE `dpis_teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
