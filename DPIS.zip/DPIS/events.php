<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <?php
    include('includes/link.php');
    ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- header start  -->
       <?php
       include('includes/header.php'); 
       ?>
        <!-- header end  -->


        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Events & Celebrations</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Events & Celebrations</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->

 <!-- About-events Start -->
 <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                
                    <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s" style="box-shadow: 9px 12px 13px gray; padding: 15px;" >
                    <div class="text-center mx-auto mb-2 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">School Events & Celebrations</h1>
                    <p class="text-primary" >Unite, Celebrate, Shine!</p>
                </div>
                        <p> At Delhi Public International School, events & celebrations are a key component of our curriculum. We make it a priority to observe a variety of national and regional festivals, special days, and other events throughout the academic year. This approach helps our students learn about and appreciate diverse values, beliefs, and cultures. Key celebrations include festivals such as Diwali, Christmas, Holi, Baisakhi, Raksha Bandhan, Janmashtami, Dussehra, Gurpurab, and Eid, as well as events like the Christmas Carnival, Winter Carnival, and the Annual Function – Udaan. Additionally, special days such as Earth Day, Save the Tiger Day, Penguin Day, Environment Day, Mango Day, Colours & Shapes Day, Fruits & Vegetable Day, Birds Day, and Animal Day provide valuable learning experiences for our children.</p>

                        
                    </div>
               
                </div>
            </div>
        </div>
        <!-- About-events End -->
        <!-- Events Start -->
        <div class="container-xxl py-5">
            <div class="container">
                
                <div class="row g-4">
                <?php
      include('connection.php');
      $sql="SELECT * FROM `dpis_events` ORDER BY `id` DESC";
      $result= mysqli_query($conn, $sql);
      foreach($result as $res){
?>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="classes-item">
                            <div class="bg-light  w-85 p-3">
                                <img class="img-fluid" src="<?php echo $res ['photo']; ?>" alt="events-img" style="height: 300px; width: 100%;" >
                            </div>
                           
                        </div>
                    </div>
                    <?php
      }
                    ?>
                    <!-- <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="classes-item">
                            <div class="bg-light  w-85  p-3">
                                <img class="img-fluid " src="img/classes-2.jpg" alt="">
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="classes-item">
                            <div class="bg-light  w-85  p-3">
                                <img class="img-fluid " src="img/classes-3.jpg" alt="">
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="classes-item">
                            <div class="bg-light  w-85  p-3">
                                <img class="img-fluid " src="img/classes-4.jpg" alt="">
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="classes-item">
                            <div class="bg-light  w-85  p-3">
                                <img class="img-fluid " src="img/classes-5.jpg" alt="">
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="classes-item">
                            <div class="bg-light  w-85  p-3">
                                <img class="img-fluid " src="img/classes-6.jpg" alt="">
                            </div>
                            
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        <!-- Events End -->


        <!-- Appointment Start -->
       <?php
       include('includes/appointment.php');
       ?>
        <!-- Appointment End -->


      <!-- Testimonial Start -->
      <?php
      include('includes/parents_says.php');
      ?>
        <!-- Testimonial End -->


       <!-- Footer Start -->
       <?php
       include('includes/footer.php');
       ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>


</html>