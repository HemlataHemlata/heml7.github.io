<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <?php
    include('includes/link.php');
    ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- header start  -->
        <?php
         include('includes/header.php'); 
        ?>
        <!-- header end  -->
        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">About Us</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">About Us</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->

        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                <?php
      include('connection.php');
      $sql="SELECT * FROM `dpis_about` ORDER BY `id` DESC";
      $result= mysqli_query($conn, $sql);
      $res = mysqli_fetch_assoc($result);
      
      ?>
                <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid rounded-circle bg-light p-3" src="<?php echo $res['about_img'] ?>" alt="about-img" style="height: 450px; width:400px; " >
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="box-shadow: 9px 12px 13px gray; padding: 15px;" >
                        <h1 class="mb-4">The Leadership</h1>
                        <h5 class="text-primary" >N K Mishra</h5>
                        <p> <?php echo base64_decode( $res['content']) ?></p>

                        <div class="row g-4 align-items-center">
                            <div class="col-sm-6">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle flex-shrink-0" src="<?php echo $res['about_img'] ?>" alt="" style="width: 45px; height: 45px;">
                                    <div class="ms-3">
                                        <h6 class="text-primary mb-1">Niraj Kumar Mishra</h6>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
               
                </div>
            </div>
        </div>
        <!-- About End -->


       

        <!-- father about start  -->
        <div class="container-xxl py-5" style="background-color: #fff7ea;">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="box-shadow: -14px -9px 6px #f7e1dd;" >
                        <h1 class="my-4">Late Dr. Bipin Bihari Mishra</h1>
                        <p> Dr. Bipin Bihari Mishra, born on June 23, 1958, and who passed away on February 8, 2022, held a B.Sc Hons and M.Sc in Mathematics from B.H.U. He served as a lecturer at Mahendra Multiple Campus in Dang, Nepal, and as a professor at Kapilvastu Multiple Campus in Taulihqwa (Kapilvastu), Nepal. Dr. Mishra was also the founder Chairman and Principal of West Point English Boarding School in Taulihawa (Kapilvastu), Nepal. Additionally, he was associated with The Scholars Home in Golgadda, Varanasi, and Sanskriti International School in Mairwa, Siwan, Bihar. His leadership extended to serving as President of Vishwa Hindu Mahasang, Nepal, and President of Nepal Bharatmatrisung.</p>

                        <div class="row g-4 align-items-center">
                            <div class="col-sm-6">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle flex-shrink-0" src="img/father.png" alt="" style="width: 45px; height: 45px;">
                                    <div class="ms-3">
                                        <h6 class="text-primary mb-1">Late Dr. Bipin Bihari Mishra</h6>
                                        <small>Chairman</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid w-75 rounded-circle bg-light p-3" src="img/father.png" alt="about-img">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         <!-- father about end  -->

         <!-- NGO Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
               
                <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid bg-light p-3" src="img/ngo-certificate.png" alt="NGO-certificate-img" >
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="box-shadow: 9px 12px 13px gray; padding: 15px;" >
                        <h1 class="mb-4">NGO - <span class="text-primary" >Certificate</span> </h1>
                        <!-- <h5 class="text-primary" >N K Mishra</h5> -->
                        <p>Last year we provided scholarships to 500 students in 20 schools and trained 100 teachers. Highlight specific examples of how your work has made a difference. This could include detailed stories of individual students or schools that have seen significant improvements. Describe how people can contribute their time and skills to your NGO. Example: "Join us as a volunteer teacher and help students excel in their studies." Provide information about how people can donate money, supplies or other resources.</p>

                        <!-- <div class="row g-4 align-items-center">
                            <div class="col-sm-6">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle flex-shrink-0" src="" alt="" style="width: 45px; height: 45px;">
                                    <div class="ms-3">
                                        <h6 class="text-primary mb-1">Niraj Kumar Mishra</h6>
                                      
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
               
                </div>
            </div>
        </div>
        <!-- NGO End -->

          <!-- vission & mission start -->
           <style>
            
.blur {
    -webkit-box-shadow: 0 0 15px rgba(188,191,200,0.1),0 0 15px rgba(188,191,200,0.2) !important;
    box-shadow: 0 0 15px rgba(188,191,200,0.1),0 0 15px rgba(188,191,200,0.2) !important;
}
.mr-5 {
    margin-right: 5px !important;
}
.va-middle {
    vertical-align: middle !important;
}
.bg-img {
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
}
.timeline {
    list-style: none;
    padding: 20px 0;
    position: relative;
}
.timeline:before {
    top: 0;
    bottom: 0;
    position: absolute;
    content: " ";
    width: 4px;
    background-color: #dddfe6;
    left: 50%;
    margin-left: -2px;
}
.timeline.w-icons:before {
    top: 0;
    bottom: 0;
    position: absolute;
    content: " ";
    width: 3px;
    background-color: #dddfe6;
    left: 50%;
    margin-left: -1.5px;
}
.timeline > li {
    margin-bottom: 20px;
    position: relative;
}
.timeline > li:before,
.timeline > li:after {
    content: " ";
    display: table;
}
.timeline > li:after {
    clear: both;
}
.timeline > li:before,
.timeline > li:after {
    content: " ";
    display: table;
}
.timeline > li:after {
    clear: both;
}
.timeline > li > .timeline-panel {
    background-color: #fff7ea;
    width: 50%;
    float: left;
    border-radius: 5px;
    padding: 20px;
    position: relative;
    -moz-transition: 0.2s ease-in-out;
    -o-transition: 0.2s ease-in-out;
    -webkit-transition: 0.2s ease-in-out;
    transition: 0.2s ease-in-out;
    box-shadow: 0 2px 12px rgba(188, 191, 200, 0.1), 0 2px 12px rgba(188, 191, 200, 0.2) !important;
}
.timeline > li > .timeline-panel:hover {
    transform: translateY(-3px);
    -webkit-box-shadow: 0 3px 20px rgba(188, 191, 200, 0.1), 0 3px 20px rgba(188, 191, 200, 0.3) !important;
    box-shadow: 0 3px 20px rgba(188, 191, 200, 0.1), 0 3px 20px rgba(188, 191, 200, 0.3) !important;
}
.timeline > li:not(.timeline-inverted) {
    padding-right: 50px;
}
.timeline > li.timeline-inverted {
    padding-left: 50px;
}
.timeline.w-icons > li:not(.timeline-inverted) {
    padding-right: 85px;
}
.timeline.w-icons > li.timeline-inverted {
    padding-left: 85px;
}
.timeline > li > .timeline-badge {
    color: #fff;
    background: #dddfe6;
    width: 25px;
    height: 25px;
    line-height: 15px !important;
    font-size: 0.75rem;
    text-align: center;
    position: absolute;
    top: 20px;
    left: 50%;
    margin-left: -12.5px;
    z-index: 100;
    border: 5px solid #fff;
    border-radius: 50%;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.15);
}
.timeline.w-icons > li > .timeline-badge {
    color: #fff;
    background: #5d3997;
    width: 60px;
    height: 60px;
    line-height: 65px !important;
    font-size: 1rem;
    text-align: center;
    position: absolute;
    top: 20px;
    left: 50%;
    margin-left: -30px;
    z-index: 100;
    border: 0;
    border-radius: 50%;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.15);
}
.timeline.w-icons > li > .timeline-badge .material-icons {
    line-height: 60px !important;
}
.timeline > li.timeline-inverted > .timeline-badge {
    top: 0;
}
.timeline > li.timeline-inverted > .timeline-panel {
    float: right;
}
ul.timeline {
    margin-bottom: 0;
}
.timeline-body > p,
.timeline-body > ul {
    margin-bottom: 0;
}
.timeline-body > p + p {
    margin-top: 5px;
}
@media only screen and (max-width: 600px) {
    .timeline > li > .timeline-panel {
   width: 100%;
  }
  .timeline > li > .timeline-badge{
    top: 0;
  }
  .timeline > li.timeline-inverted > .timeline-badge{
    top: -19px;
  }
}
           </style>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />

<div class="container mt-5">
    <div class="p-x-15 blur">
        <div class="row">
            <!-- <div class="col-md-6 bg-img" style="background-image: url(https://www.bootdey.com/image/600x600/FFB6C1/000000); min-height:320px"><p class="mb-0"></p>
            </div> -->
            <!-- / box-bg-image -->
            <div class="col-md-12 col-md-offset-6 p-30 text-center bg-white">
                    <!-- <h4 class="mb-50 fw-bold">ACHIEVEMENTS</h4> -->
                    <ul class="timeline">
                        <li class="timeline">
                            <div class="timeline-badge"></div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h5 class="timeline-title">OUR <span class="text-primary" >Mission</span> </h5>
                                    <p class="text-sm">Delhi Public International School's mission is to offer a stimulating and enriching educational journey for young learners as they embark on their initial steps in their academic path.</p>
                                    We are dedicated to cultivating a serene, engaging, and stimulating environment that promotes the social, physical, emotional, and cognitive growth of each child.</p>
                                    <p>Our goal is to instill social, moral, and cultural values in young learners while fostering a deep sense of respect and responsibility toward the environment.</p>
                                </div><!-- / time-line-heading -->
                                <!-- <div class="timeline-body">
                                    <p>Quisque sit amet urna et neque porttitor mattis.</p>
                                </div> -->
                                <!-- / timeline-body -->
                            </div><!-- / timeline-panel -->
                        </li><!-- timeline -->

                        <li class="timeline-inverted">
                            <div class="timeline-badge"></div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h5 class="timeline-title">OUR <span class="text-primary" >Vision</span>  </h5>
                                    <!-- <p class="text-sm">Web Design</p> -->
                                    <p class="timeline-meta text-xs">Our vision for Delhi Public International School, Kaimur, Bihar, is to cultivate a dynamic and inclusive educational environment that empowers students to become thoughtful, innovative, and responsible global citizens. We aspire to equip them with the skills, values, and knowledge needed to excel in an ever-evolving world and contribute positively to society.</p>
                                </div><!-- / time-line-heading -->
                                <!-- <div class="timeline-body">
                                    <p>Quisque sit amet urna et neque porttitor mattis.</p>
                                </div> -->
                                <!-- / timeline-body -->
                            </div><!-- / timeline-panel -->
                        </li><!-- timeline-inverted -->
                    </ul><!-- / timeline -->
            </div><!-- / column -->
        </div><!-- / row -->
    </div><!-- / p-15 -->
</div>
           <!-- vission & mission end -->


        <!-- Team Start -->
       <?php
       include('includes/teacher.php');
       ?>
        <!-- Team End -->


       <!-- Footer Start -->
       <?php
       include('includes/footer.php');
       ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>