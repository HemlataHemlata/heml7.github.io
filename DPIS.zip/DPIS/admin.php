<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta
    content="" name="description">
  <meta
    content="" name="keywords">
    <title>Admin_DPIS</title>
    <!-- css file cdn  -->
    <link rel="stylesheet" href="login.css">
    <!-- google fonts  -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Source+Sans+Pro:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,600;1,700&display=swap"
    rel="stylesheet">
    <!-- Favicon -->
    <link href="img/logo.png" rel="icon">
</head>
<body>
    <section id="login">
        <div  class="row">
        <div class="login" class="col-md-12 col-lg-12 col-sm-12">
            <div class="login-triangle"></div>
            
            <h2 class="login-header">Log in</h2>
          
            <form class="login-container" method="POST">
              <p><input type="email" name="email" placeholder="Email"></p>
              <p><input type="password" name="password" placeholder="Password"></p>
              <p><input type="submit" name="subbtn" value="Log in"></p>
              <!-- <button type="submit" name="subbtn">Login</button> -->
            </form>
          </div>
        </div>
    </section>
</body>
</html>

<?php
include('connection.php');
if(isset($_POST['subbtn'])){
    echo $email=base64_encode($_POST['email']);
    echo "<br>". $password=base64_encode($_POST ['password']);
    $sql="SELECT * FROM `dpis_admin` WHERE  `email`= BINARY '$email' AND  `password`= BINARY '$password'";
    $result=mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)){
        // echo "correct";
        $result1=mysqli_fetch_assoc($result);
        session_start();
        $_SESSION['id']=$result1['id'];
        $_SESSION['name']=$result1['name'];
        $_SESSION['mobile']=$result1['mobile'];
        $_SESSION['email']=$result1['email'];
        $_SESSION['password']=$result1['password'];
        $_SESSION['date&time']=$result1['date&time'];
        header('Location:dpis_admin/index.php');
    }
    else{
        echo "Please check your email and password  ";
    }
}
?>