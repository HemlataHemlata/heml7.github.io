<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <?php
    include('includes/link.php');
    ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- header start  -->
        <?php
         include('includes/header.php'); 
        ?>
        <!-- header end  -->
        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Career</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Career</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->

        <!-- career Start -->
         <style>
           
.account-settings .user-profile {
    margin: 0 0 1rem 0;
    /* padding-bottom: 1rem; */
    text-align: center;
}
.account-settings .user-profile .user-avatar {
    margin: 0 0 1rem 0;
}
.account-settings .user-profile .user-avatar img {
    width: 90px;
    height: 100px;
    /* -webkit-border-radius: 100px;
    -moz-border-radius: 100px;
    border-radius: 100px; */
}
.account-settings .user-profile h5.user-name {
    margin: 0 0 0.5rem 0;
}
.account-settings .user-profile h6.user-email {
    margin: 0;
    font-size: 0.8rem;
    font-weight: 400;
    color: #9fa8b9;
}
.account-settings .about {
    margin: 2rem 0 0 0;
    text-align: center;
}
.account-settings .about h5 {
    margin: 0 0 15px 0;
    color: #007ae1;
}
.account-settings .about p {
    font-size: 0.825rem;
}
.form-control {
    border: 1px solid #cfd1d8;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
    font-size: .825rem;
    background: #ffffff;
    color: #2e323c;
}

.card {
    background: #ffffff;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
    border: 0;
    margin-bottom: 1rem;
}
         </style>
        <div class="container">
<div class="row gutters">
<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
		<div class="account-settings">
			<div class="user-profile">
				<div class="user-avatar">
					<img src="img/logo.png" alt="Maxwell Admin">
				</div>
				<h5 class="user-name">DPIS</h5>
				<h6 class="user-email">dpis01principal@gmail.com</h6>
			</div>
			<div class="about">
				<h5>About</h5>
				<p>Our teachers are experienced, qualified, passionate and motivated to create an enriching learning experience for little ones. </p>
			</div>
		</div>
	</div>
</div>
</div>
<div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
    <div class="bg-light rounded">
                    <div class="row g-0">
                        <div class="col-lg-12 wow fadeIn" data-wow-delay="0.1s">
                            <div class="h-100 d-flex flex-column justify-content-center p-5">
                               
                                <form method="POST" enctype="multipart/form-data" >
                                    <div class="row g-3">
                                        <div class="col-sm-6 ">
                                            <div class="form-floating">
                                                <input type="text" class="form-control border-0" id="name" name="name" placeholder="Your Name">
                                                <label for="name">Enter Your Name</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-floating">
                                                <input type="email" class="form-control border-0" id="email" name="email" placeholder="Your Email">
                                                <label for="email">Enter Your Email</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input type="number" class="form-control border-0" id="mobile" name="mobile" placeholder="mobile">
                                                <label for="mobile">Enter Your Mobile</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input type="file" class="form-control border-0" id="resume" name="resume" placeholder="mobile">
                                                <!-- <label for="mobile">Mobile</label> -->
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <textarea class="form-control border-0" placeholder="Leave a message here" id="message"  name="message" style="height: 100px"></textarea>
                                                <label for="message">Write a message</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button class="btn btn-primary w-100 py-3" name="submitbutton" type="submit">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                 
                    </div>
                </div>
	</div>
</div>
</div>
</div>
</div>
        <!-- career End -->
        <?php
include('connection.php');
if(isset($_POST['submitbutton'])){
      $name = $_POST["name"];
       $email = $_POST["email"];
       $mobile = $_POST["mobile"];
       $resume = $_FILES["resume"] ['name'] ;
       $message = $_POST["message"];
       $targetfolder = "career_pdf/";
       $file_pdf ='career_pdf/'.base64_encode(date('Y-m-d').time().uniqid()).'.pdf';
       move_uploaded_file($_FILES['resume']['tmp_name'], $file_pdf);
$query="INSERT INTO `dpis_career` (`name`, `email`, `mobile`, `message`, `resume`) VALUES('$name', '$email', '$mobile', '$message', '$file_pdf')";
$result=mysqli_query($conn,$query);
if($result){
echo " <script>
alert('Data Inserted');
window.location.href='welcome';
</script> ";
}
else{
   echo "data is not inserted";
}

}

?>


        <!-- Team Start -->
       <?php
       include('includes/teacher.php');
       ?>
        <!-- Team End -->


       <!-- Footer Start -->
       <?php
       include('includes/footer.php');
       ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>