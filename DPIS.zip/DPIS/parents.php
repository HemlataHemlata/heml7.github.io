<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <?php
    include('includes/link.php');
    ?>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- header start  -->
       <?php
       include('includes/header.php'); 
       ?>
        <!-- header end  -->


        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Parent's Connect</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Parent's Connect</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        
<!-- self section start  -->
 <style>
    .card-big-shadow {
    /* max-width: 320px; */
    position: relative;
}

.coloured-cards .card {
    margin-top: 30px;
}

.card[data-radius="none"] {
    border-radius: 0px;
}
.card {
    border-radius: 8px;
    box-shadow: 0 2px 2px rgba(204, 197, 185, 0.5);
    background-color: #FFFFFF;
    color: #252422;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
}


.card[data-background="image"] .title, .card[data-background="image"] .stats, .card[data-background="image"] .category, .card[data-background="image"] .description, .card[data-background="image"] .content, .card[data-background="image"] .card-footer, .card[data-background="image"] small, .card[data-background="image"] .content a, .card[data-background="color"] .title, .card[data-background="color"] .stats, .card[data-background="color"] .category, .card[data-background="color"] .description, .card[data-background="color"] .content, .card[data-background="color"] .card-footer, .card[data-background="color"] small, .card[data-background="color"] .content a {
    color: #FFFFFF;
}
.card.card-just-text .content {
    padding: 50px 15px;
    text-align: center;
}
.card .content {
    padding: 20px 20px 10px 20px;
}
.card[data-color="blue"] .category {
    color: #7a9e9f;
}

.card .category, .card .label {
    font-size: 14px;
    margin-bottom: 0px;
}
.card-big-shadow:before {
    background-image: url("img/shadow.png");
    background-position: center bottom;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    bottom: -12%;
    content: "";
    display: block;
    left: -12%;
    position: absolute;
    right: 0;
    top: 0;
    z-index: 0;
}
h4, .h4 {
    font-size: 1.5em;
    font-weight: 600;
    line-height: 1.2em;
}
h6, .h6 {
    font-size: 0.9em;
    font-weight: 600;
    text-transform: uppercase;
}
.card .description {
    font-size: 16px;
    color: #66615b;
}
.content-card{
    margin-top:30px;    
}
a:hover, a:focus {
    text-decoration: none;
}

/*======== COLORS ===========*/
.card[data-color="blue"] {
    background: #b8d8d8;
}
.card[data-color="blue"] .description {
    color: #506568;
}

.card[data-color="green"] {
    background: #d5e5a3;
}
.card[data-color="green"] .description {
    color: #60773d;
}
.card[data-color="green"] .category {
    color: #92ac56;
}

.card[data-color="yellow"] {
    background: #ffe28c;
}
.card[data-color="yellow"] .description {
    color: #b25825;
}
.card[data-color="yellow"] .category {
    color: #d88715;
}

.card[data-color="brown"] {
    background: #d6c1ab;
}
.card[data-color="brown"] .description {
    color: #75442e;
}
.card[data-color="brown"] .category {
    color: #a47e65;
}

.card[data-color="purple"] {
    background: #baa9ba;
}
.card[data-color="purple"] .description {
    color: #3a283d;
}
.card[data-color="purple"] .category {
    color: #5a283d;
}

.card[data-color="orange"] {
    background: #ff8f5e;
}
.card[data-color="orange"] .description {
    color: #772510;
}
.card[data-color="orange"] .category {
    color: #e95e37;
}
 </style>
<div class="container bootstrap snippets bootdeys">
<div class="row">
    <div class="col-md-6 col-sm-6 content-card">
        <div class="card-big-shadow">
            <div class="card card-just-text" data-background="color" data-color="blue" data-radius="none">
                <div class="content">
                    
                    <h4 class="title mb-4"><a href="#">"Parent Engagement Events"</a></h4>
                    <p class="description">While Delhi Public International School offers various opportunities for parents to engage in events such as birthday and festival celebrations, we also organize special events exclusively for parents and grandparents, including Orientation Programs, Parenting Workshops, Seminars, Mother's Day, Parent's Day, and Grandparent's Day.</p>
                    <p class="description mb-4">Securing admission to a preferred school has become increasingly challenging for parents in metropolitan areas. To ease this process, we organize seminars that offer comprehensive information on formal school admissions. These sessions are led by experienced professionals and principals/directors from esteemed schools, addressing all queries parents may have about the admission process.</p>
                </div>
            </div> <!-- end card -->
        </div>
    </div>
    
    <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid w-75 rounded-circle bg-light p-3" src="img/parents-1.png" alt="parents-img" style="height: 400px; width: 400px; ">
                            </div>
                            <div class="col-6 text-start" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="img/parents-2.jpg" alt="parents-img" style="height: 250px; width: 250px; ">
                            </div>
                            <div class="col-6 text-end" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="img/parents-3.jpg" alt="parents-img" style="height: 250px; width: 250px; ">
                            </div>
                        </div>
                    </div>
</div>
</div>
 <!-- self section end -->
   <!-- Parents Start -->
 <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                
                    <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s" style="box-shadow: 9px 12px 13px gray; padding: 15px;" >
                    <div class="text-center mx-auto mb-2 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Partnership With Parents</h1>
                    <p class="text-primary" >"Partnering for Success: Together in Every Step"</p>
                </div>
                        <p>Home is the first learning environment for children, with parents serving as their initial teachers. They guide their children's development and model the behavior they wish to see through their own actions.</p>
                        <p class="mb-4" >We believe that a strong partnership between school and parents is vital to a child’s growth. Regular communication between teachers and parents helps us share important information about the child. We value being updated on any changes at home that may impact the child and will handle such information with the utmost confidentiality and care.</p>
                        <p class="mb-4" >We hold regular parent-teacher meetings to discuss each child's progress with their parents. At Delhi Public International School, we have an open-door policy, allowing parents to schedule appointments with teachers or school officials to address any concerns related to their child's development.</p>

                        
                    </div>
               
                </div>
            </div>
        </div>
        <!-- Parents End -->

        <!-- Appointment Start -->
       <?php
       include('includes/appointment.php');
       ?>
        <!-- Appointment End -->


      <!-- Testimonial Start -->
      <?php
      include('includes/parents_says.php');
      ?>
        <!-- Testimonial End -->


       <!-- Footer Start -->
       <?php
       include('includes/footer.php');
       ?>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>


</html>