<?php
if(isset($_POST['proceed-button'])){
    $logo_photo = $_FILES['logo_photo']['name'];
    $photo = $_FILES['photo']['name'];
    $target_file1 = 'camping-img/' . uniqid().'.png';
    $target_file2 = 'camping-img/' . uniqid().'.png';
    move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file1);
    move_uploaded_file($_FILES["logo_photo"]["tmp_name"], $target_file2);
    $maintitle = $_POST['maintitle'];
    $subtitle = $_POST['subtitle'];
    $subcategory = $_POST['subcategory'];
    ?>

<img src="<?php echo $target_file1; ?>" alt="main-photo">
<img src="<?php echo $target_file2; ?>" alt="logo_photo">


    <?php
    }
?>