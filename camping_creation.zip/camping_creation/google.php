
<html>
<html lang="en">
<head>
  <title>Google_Camping</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,500i,700,800i" rel="stylesheet">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <!-- icons cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

    </head>
    
    <body>
        <style>     
        a{
            text-decoration: none;
        }                   
.ibox-content {
    background-color:#ffffff;
    color: inherit;
    padding: 15px 20px 20px 20px;
    border-color: #E7EAEC;
    border-image: none;
    border-style: solid solid none;
    border-width: 1px 0px;
}

.hr-line-dashed {
    border-top: 1px dashed #E7EAEC;
    color: #ffffff;
    background-color: #ffffff;
    height: 1px;
    margin: 20px 0;
}

h2 {
    font-size: 24px;
    font-weight: 100;
}

.context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}

.social-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    padding: 23px;
    font: 900 13px/1 "Lato", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.5);
}    
.text-navy{
    color: rgb(35 36 39);
    font-weight: 500;
}

    </style>
         
    <div class="container bootstrap snippet">
    <?php
if(isset($_POST['proceed-button'])){
    $name = $_POST['name'];
    $url = $_POST['url'];
    $heading = $_POST['heading'];
    $content = $_POST['content'];
    $number = $_POST['number'];
    ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <h2>
                      <span class="text-navy">Sponsored</span>
                    </h2>

                    <div class="hr-line-dashed"></div>
                    <div class="search-result"> 
                        <div style="display: flex; margin-bottom: 15px; " >
                        <i class="fa-solid fa-earth-asia" style="margin-right: 10px;
                        background:#80808045;
                        border-radius:50%;
                        padding:10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
" ></i>
                       <div>
                       <h3 style="margin-bottom: 0;" ><a href="#" style="color: rgb(35 36 39);
    font-weight: 400;
    font-size: 18px;" > <?php echo $name; ?></a></h3>
                       <a href="#" class="search-link"> <?php echo $url; ?></a>
                       </div>
                        </div>
                       <h4 style="color:rgb(58 57 179);"><?php echo $heading; ?></h4>
                        <p><?php echo $content; ?>
                        </p>
                    </div>
                    <div>
                   
                    <p style="
    width: fit-content;
    border-radius: 10px;
    padding: 2px 10px;
    font-size: 22px;
    display: flex;
    align-items: center;
    justify-content: center;" > <i class="fa-solid fa-phone" style="margin-right: 10px;" ></i> Call <?php echo $number; ?></p>
                    </div>
                    <div class="hr-line-dashed"></div>

                    
                </div>
            </div>
        </div>
    </div>
    <?php
}
    ?>
</div>    
        
    </body>   
    
</html>




                    