<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Camping_creation</title>
  <!-- custom css cdn -->
   <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$files = glob('camping-img/*'); // Get all file names in the folder

foreach ($files as $file) {
    if (is_file($file)) { // Check if it's a file
        unlink($file); // Delete the file
    }
}
?>
<style>
  #label{
    padding: 10px;
    border-radius: 10px;
    display: flex;
    background: #2e91c240;
    border: 1px solid #2e91c240;
    width: 100%;
  }
</style>
<section>
  <div class="main-form-container">
    <div id="form_section" class="form-container">
      <div class="login-form form-wraper ">
        <div>
          <div class="form-title">
            <h2>Google Camping</h2>
          </div>
          <form method="POST" action="google.php" enctype="multipart/form-data">
          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter Name" class="myInput" name="name" type="text" />
              </span>
            </div>
          </div>
          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter URL" class="myInput" name="url" type="text" />
              </span>
            </div>
          </div>
          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter Heading" class="myInput" name="heading" type="text" />
              </span>
            </div>
          </div>
          
          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter Content" class="myInput" name="content" type="text" />
              </span>
            </div>
          </div> 

          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter Number" class="myInput" name="number" type="text" />
              </span>
            </div>
          </div>

          <div class="action-button">
            <button name="proceed-button" type="submit">Proceed</button>
          </div>
          </form>
        </div>
      </div>
      <!-- facebook start  -->
      <div class="signUp-form form-wraper">
        <div>
          <div class="form-title">
            <h2>Facebook Camping</h2>
          </div>
          <form method="POST" action="facebook.php" enctype="multipart/form-data" >  
          <label for="logo-photo" id="label" >Main-photo</label>      
          <div class="input-group">
            <div class="box">
              <span>
                <input class="myInput" type="file" name="photo" />
              </span>
            </div>
          </div>
          <label for="logo-photo" id="label" >Logo-photo</label>
          <div class="input-group">
            <div class="box">             
              <span>
                <input class="myInput" type="file" name="logo_photo" />
              </span>
            </div>
          </div>
          <!-- <label for="logo-photo" id="label" >Logo-Heading</label> -->
          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter Logo-Heading" class="myInput" type="text" name="maintitle" />
              </span>
            </div>
          </div>
          <!-- <label for="logo-photo" id="label" >Main Content</label> -->
          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter Main Content" class="myInput" type="text" name="subtitle" />
              </span>
            </div>
          </div>
          <div class="input-group">
            <div class="box">
              <span>
                <input placeholder="Enter Button Type" class="myInput" type="text" name="buttontype" />
              </span>
            </div>
          </div>
          <!-- <label for="logo-photo" id="label" >Bottom Content</label> -->
          <div class="input-group" style="margin-bottom: 0px;" >
            <div class="box">
              <span>
                <input placeholder="Enter Bottom Content" class="myInput" type="text" name="subcategory" />
              </span>
            </div>
          </div>
          <div class="action-button">
            <button name="proceed-button" type="submit" >Proceed</button>
          </div>
          </form>
        </div>
      </div>
    </div>
    <div id="multiple-btn" class="bg-btn-container">
      <div class="action-button">
        <button>Switch to Google</button>
      </div>
      <div class="action-button">
        <button>Switch to Facebook</button>
      </div>
    </div>

  </div>
</section>
<script>
  const inputs = document.querySelectorAll("input");
inputs.forEach(function (input) {
  input.addEventListener("focus", function () {
    const parentElement = input.parentElement.parentElement;
    parentElement.classList.add("box-animation");
  });
  input.addEventListener("blur", function () {
    const parentElement = input.parentElement.parentElement;
    parentElement.classList.remove("box-animation");
  });
});

const buttons = document.querySelectorAll("#multiple-btn button");
const form_container = document.getElementById('form_section')
buttons.forEach((button) => {
button.addEventListener("click", () => {
form_container.classList.toggle("left-right");

});
});
</script>
</body>
</html>