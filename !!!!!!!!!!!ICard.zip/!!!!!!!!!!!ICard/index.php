<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>i-Card Generator</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>

        body
        {
            background-color: rgba(64, 48, 204, 0.09);
        }
        .spn1
        {
            font-size: 24px;
            font-weight: bold;
            color: #50579C;
            font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif
        }
        form
        {
            margin-top: 10px;
            box-shadow: 0px 0px 10px;
            background-color: white;
            border-radius: 5px;
        }
    </style>

</head>
<body>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4"></div>

            <div class="col-md-4">
                <form class="form-group border p-2" action="iCard.php" method="post" enctype="multipart/form-data">
                    <center> <span class="spn1"> <i class="fa fa-info" aria-hidden="true"  style="font-size:26px"></i>-Card Generator </span> </center><br>

                    <label for="Input1">Profile Image</label>
                    <input type="file" class="form-control" id="Input1" name="file_img"><br>
                    <input type="text" class="form-control" name="c_name" placeholder="Candidate Name" required><br>
                    <input type="text" class="form-control" name="designation" placeholder="Designation" required><br>
                    <input type="text" class="form-control" name="id_number" placeholder="Id Number" required><br>
                    <input type="text" class="form-control" name="mobile" placeholder="Contact Number" required><br>
                    <input type="text" class="form-control" name="doi" placeholder="Date of Issue" required><br>
                    <textarea class="form-control" name="add" id="" cols="30" rows="3" placeholder="Address" required></textarea><br>
                    <button type="submit" class="btn btn-info" name="submit" value="submit" style="width:100%">Submit</button>

                </form>
            </div>

        </div>
    </div>


</body>
</html>