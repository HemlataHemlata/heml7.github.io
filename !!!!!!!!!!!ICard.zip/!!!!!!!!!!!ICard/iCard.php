<!DOCTYPE html>
<html lang="en">
<head>
<title>i-Card Generator</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
       
        .iCard-first
        {
            padding: 6px;
            width: 220px;
            height: 345px;
            background-color: white;
            border-radius: 8px;
            border: 1px solid black;
            background-image: url("siteImages/gw_bg.png");
            background-repeat: no-repeat;
        }
        .spn1
        {
            padding: 3px;
            font-size: 18px;
            font-weight: 500;
        }

        .profile
        {
            
            width: 100px;
            height: 110px;
            border: 2px solid rgba(220, 220, 220, 0.521);
            border-radius: 10px;
            margin-bottom: 4px;
            margin-top: 10px;
        }
        .details
        {
            font-size: 12px;
            margin-top: -5px;
            font-weight: 500;
        }

        .iCard-second
        {
            padding: 6px;
            width: 220px;
            height: 345px;
            background-color: white;
            border-radius: 8px;
            border: 1px solid black;
            background-image: url("siteImages/gw_bg.png");
            background-repeat: no-repeat;
        }
        .spn2
        {
            margin-top: 12px;
            width: 65%;
        }

        


    </style>

</head>
<body>

<?php

    $profile_image = "";
    if(isset($_POST['submit']))
    {
        $c_name = $_POST['c_name'];
        $designation = $_POST['designation'];
        $id = $_POST['id_number'];
        $mobile = $_POST['mobile'];
        $doi = $_POST['doi'];
        $add = $_POST['add'];

    
        $name=$_FILES['file_img']['name'];
        $target_dir ="images/";
        $filecount =1;
        $files = glob($target_dir . "*");
        if ($files)
        {
            $filecount = count($files)+1;
        }
        $image_name = 'images/' . $filecount. '.png' ;
        $target_file =$target_dir . basename($_FILES["file_img"]["name"]);
        //Select file type
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        // Valid file extensions
        $extensions_arr = array("jpg","jpeg","png","gif");
        $image_base64 = base64_encode(file_get_contents($_FILES['file_img']['tmp_name']));
        $image ='data:slider_img/'.$imageFileType.';base64,'.$image_base64;
        move_uploaded_file($_FILES['file_img']['tmp_name'],$image_name);

        $profile_image = $image_name;
    }

?>
 <!-- first page start -->
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <br>
                <center>
                <div class="iCard-first">
                
                        <span class="spn1"> GENOVIQ WEB Pvt. Ltd.</span>
                        <br>
                        <img class="profile" src="<?php echo $profile_image; ?>">
                        <br>
                        <p style="font-size: 14px; font-weight: bold;"> <?php echo $c_name; ?> <br>
                        <?php echo $designation; ?> </p>

                        <p class="details"><b> ID:</b> <?php echo $id; ?> <br>
                            <b> Contact:</b> +91-<?php echo $mobile; ?> <br>
                            <b> Date of Issue:</b> <?php echo $doi; ?> <br>
                            <b> Address:</b> <?php echo $add; ?> 
                        </p>

                </div>
                </center>
                <br>
            </div>
        </div>
    </div>
<!-- //first page ends -->


<!-- second page start -->
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <br>
                <center>
                <div class="iCard-second">
                
                        <img src="siteImages/logo.png" class="spn2">
                        <br><br>
                        <p style="font-size: 14px; font-weight: 500; color: #006FBC;">
                            <u> Address : Varanasi, UP, 221002 <br>
                            Email : genoviqweb@gmail.com</u> 
                        </p>

                        <p style="font-size: 14px; margin-top: -16px;">
                            <b> Website : genoviqweb.com</b> <br>
                            <b> Contact : +91-8922999900</b> <br>
                        </p>
                        <p style="font-size:13px; font-weight: 500;">
                            <b> Services : </b> Digital Marketing, Website Development, Mobile Application, Internship
                        </p>

                </div>
                </center>
                <br>
            </div>
        </div>
    </div>
<!-- //secont page ends -->

</body>
</html>