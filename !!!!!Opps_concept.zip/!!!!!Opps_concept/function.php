<?php
session_start();
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS' ,'');
define('DB_NAME', 'oops_data');
class DB_con
{
	function __construct()
	{
$mysqli = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
$this->dbs=$mysqli;
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }
	}
	
	public function insert($name,$mobile,$address)
	{
	$result=mysqli_query($this->dbs,"insert into `form_data`(`name`,`mobile`,`address`) values('$name','$mobile','$address')");
	return $result;
	}
	public function showdata() 
	{ 
	$result=mysqli_query($this->dbs,"SELECT * FROM `form_data`"); 
	return $result; 
	} 
	public function id_rtrv($upt_id) 
	{ 
	$result=mysqli_query($this->dbs,"SELECT * FROM `form_data` WHERE `id`='$upt_id'"); 
	return $result; 
	} 
	public function update($name,$mobile,$address,$id)
	{
	$result=mysqli_query($this->dbs,"UPDATE `form_data` SET `name`='$name',`mobile`='$mobile',`address`='$address'
	           WHERE `id`='$id'");
	return $result;
	}
	public function delete($dlt_id)
	{
	$result=mysqli_query($this->dbs,"DELETE FROM `form_data` WHERE `id`='$dlt_id'");
	return $result;
	}
} 
?>