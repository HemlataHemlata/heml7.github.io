<!DOCTYPE html>
<html lang="en">

<head>
   
	
   
</head>

<body>
	
	<form method="post">
		
		<input type="text" name="name" placeholder="name">
		<input type="text" name="mobile" placeholder="mobile">
		<input type="text" name="address" placeholder="address">
		<button type="submit" name="submit" >Done</button>
		<button type="submit" name="show_data">Show</button>
	</form>

	<?php
	
	include_once("function.php");
    $insertdata=new DB_con();
	$fetchdata=new DB_con();
	$id_fetch=new DB_con();
	$updatedata=new DB_con();
	$deletedata=new DB_con();
	
	if(isset($_POST['submit']))
	{
	$name=$_POST['name'];
	$mobile=$_POST['mobile'];
	$address=$_POST['address'];
	$sql=$insertdata->insert($name,$mobile,$address);
	if($sql)
	{
	echo "<script>alert('Data inserted');</script>";
	}
	else
	{
	echo "<script>alert('Data not inserted');</script>";
	}
	}
	
	if(isset($_POST['show_data']))
	{
	?><br>
	<table border="2">
	<tr><th>#</th><th>Name</th><th>Mobile</th><th>Address</th><th>Action</tr>
	<?php
  $sql=$fetchdata->showdata();
  $i=1;
   foreach($sql as $res)
	{
	?>
    <tr>
		<td><?php echo $i; ?></td>
		<td><?php echo $res['name']; ?></td>
		<td><?php echo $res['mobile']; ?></td>
		<td><?php echo $res['address']; ?></td>
		<td>
		<a href="?dlt_id=<?php echo $res['id']; ?>">Delete</a>
		<a href="?upt_id=<?php echo $res['id']; ?>">Update</a>
		</td>
	</tr>
	<?php
	   $i++;
	}
	?>
	</table>
	<?php
	}
	
	if(isset($_GET['upt_id']))
	{
		$upt_id=$_GET['upt_id'];
		//$upt_sql=$id_fetch->id_rtrv($upt_id);
		 $sql=$id_fetch->id_rtrv($upt_id);
		$res=mysqli_fetch_assoc($sql);
		//echo $res['name'];
		?>
	<form method="post">
		<br>
		<input type="hidden" name="id" value="<?php echo $res['id']; ?>">
		<input type="text" name="name" value="<?php echo $res['name']; ?>">
		<input type="text" name="mobile" value="<?php echo $res['mobile']; ?>">
		<input type="text" name="address" value="<?php echo $res['address']; ?>">
		<button type="submit" name="Update" >Update</button>
	</form>
	
	
	<?php
	}
		if(isset($_POST['Update']))
		{
			$name=$_POST['name'];
			$id=$_POST['id'];
			$mobile=$_POST['mobile'];
			$address=$_POST['address'];
			$sql=$updatedata->update($name,$mobile,$address,$id);
			if($sql)
			{
			echo "<script>alert('Data Update');</script>";
			}
			else
			{
			echo "<script>alert('Failed');</script>";
			}
		}
	
	
	if(isset($_GET['dlt_id']))
	{
		$dlt_id=$_GET['dlt_id'];
		 $sql=$deletedata->delete($dlt_id);
		
		if($sql)
			{
			echo "<script>alert('Done');
			window.location.href='index';
			</script>";
			
			}
			else
			{
			echo "<script>alert('Failed');
			window.location.href='index';
			</script>";
			}
		
	}
	?>
	
</body>
</html>