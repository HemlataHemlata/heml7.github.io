<?php
    session_start();
    if (!isset($_SESSION['swt_admin_name'])) {
        header("Location: ../index");
    }
?>

<!DOCTYPE html>
<html>

<head>
    <?php include 'inc/head.php'; ?>
</head>

<body>
    <div id="wrapper">

        <?php include 'inc/navbar.php'; ?>

        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">

                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Dashboard <small>Summary of your App</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li class="active">Data</li>
                        </ol>
                    </div>
                </div>

                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-green">
                            <div class="panel-left pull-left green">
                                <i class="fa fa-bar-chart-o fa-5x"></i>

                            </div>
                            <div class="panel-right pull-right">
                                <h3>8,457</h3>
                                <strong> Enquiries</strong>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-blue">
                            <div class="panel-left pull-left blue">
                                <i class="fa fa-shopping-cart fa-5x"></i>
                            </div>

                            <div class="panel-right pull-right">
                                <h3>52,160 </h3>
                                <strong> Sales</strong>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-red">
                            <div class="panel-left pull-left red">
                                <i class="fa fa fa-comments fa-5x"></i>

                            </div>
                            <div class="panel-right pull-right">
                                <h3>15,823 </h3>
                                <strong> Comments </strong>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                        <div class="panel panel-primary text-center no-boder bg-color-brown">
                            <div class="panel-left pull-left brown">
                                <i class="fa fa-users fa-5x"></i>

                            </div>
                            <div class="panel-right pull-right">
                                <h3>36,752 </h3>
                                <strong>No. of Visits</strong>

                            </div>
                        </div>
                    </div> -->
                </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>

    <script src="assets/js/easypiechart.js"></script>
    <script src="assets/js/easypiechart-data.js"></script>

    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>

</body>

</html>