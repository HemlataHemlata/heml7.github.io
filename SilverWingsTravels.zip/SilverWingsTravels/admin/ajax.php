<?php
    session_start();
    include '../inc/dbConnection.php';

    if(isset($_POST['loginAdmin']))
    {
        $userId = md5(base64_encode(mysqli_real_escape_string($con, $_POST['userId'])));
        $pass = md5(base64_encode(mysqli_real_escape_string($con, $_POST['password'])));

        $sql = " SELECT * FROM `swt_admin` WHERE `user_id`='$userId' AND `pass`='$pass' ";
        $result = mysqli_query($con, $sql);
        if(mysqli_num_rows($result) > 0)
        {
            $row = mysqli_fetch_assoc($result);

            $_SESSION['swt_admin_name'] = $row['name'];
            echo "Done";
        }
        else
        {
            echo "Error";
        }
    }
    elseif(isset($_POST['addSlider']))
    {
        $img="";
        if(!empty($_FILES['img']['name']))
        {
            $target_dir ="slider-img/";
            $filecount =1;
            $files = glob($target_dir . "*");
            if ($files) $filecount = count($files)+1; 

            $img = 'slider-img/' . md5(time()) .'_'. $filecount . 'main.png' ;   
            move_uploaded_file($_FILES['img']['tmp_name'],$img);
        }
        
        $sql = " INSERT INTO `swt_slider`(`image`) VALUES('$img') ";
        if(mysqli_query($con, $sql))
        {
            echo "Done";
        }
        else
        {
            echo "Error";
        }
    }
    else
    {
        header("Location: ../index");
    }

?>