<?php
    include '../inc/dbConnection.php';
    if(isset($_POST['deleteImage']))
    {
        $imgID = $_POST['imgID'];
        $sql = " DELETE FROM `swt_slider` WHERE `id`=$imgID ";
        if(mysqli_query($con, $sql))
        {
            echo "<script>
                window.location.href = 'slider';
            </script>";
        }
        else
        {
            echo "<script>
                alert('! Error');
                window.location.href = 'slider';
            </script>";
        }
    }
    else
    {
        header("Location: index");
    }

?>