<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Silver Wing Travels</title>
    <!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <style>
        .outer-body {
            background-color: white;
            padding: 20px;
            box-shadow: 0px 0px 7px #93BC73 inset;
        }

        .vsl-h3 {
            text-align: center;
            color: #93BC73;
            font-weight: bold;
            margin-top: -20px;
            margin-bottom: 30px;
        }

        .outer-body a {
            text-decoration: none;
            color: #93BC73;
            font-weight: 600;
        }

        input[type="text"], input[type="password"] {
            height: 40px;
            padding: 5px;
            padding-left: 8px;
        }

        button {
            height: 42px;
        }
    </style>
</head>

<body style="background-color: #93BC73;">

    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4" style="margin-top: 120px;">
                
                <div class="outer-body"> 
                    <h3 class="vsl-h3"><img src="../assets/img/favicon.png"> <br> Welcome Back</h3>
                    <form id="frmAdminLogin" class="form-group">
                        <input type="text" name="userId" class="form-control" placeholder="Enter User Id *" required>
                        <br>
                        <input type="password" name="password" class="form-control" placeholder="Enter Password *" required>
                        <br>
                        <input type="hidden" name="loginAdmin" value="OK">
                        <button type="submit" class="btn btn-success btn-block" id="loginBtn">Login</button>
                    </form>
                    <center>
                        <a href="../index"><i class="fa fa-home"></i>&nbsp;Back To Home</a>
                    </center>
                </div>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
    <?php include '../inc/myMsg.php'; ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        $("#frmAdminLogin").submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            document.getElementById("loginBtn").disabled = true;
            document.getElementById("loginBtn").innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: formData,
                success: function(data) {
                    if (data == "Done") {
                        myMsg('! Welcome Back Admin');
                        window.location.href = 'dashboard';
                    } else {
                        myMsg('! Invalid User Id Or Password');
                        document.getElementById("frmAdminLogin").reset();
                        document.getElementById("loginBtn").disabled = false;
                        document.getElementById("loginBtn").innerHTML = 'Login';
                    }
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });
    </script>

</body>

</html>