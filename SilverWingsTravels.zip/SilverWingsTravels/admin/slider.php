<?php
session_start();
if (!isset($_SESSION['swt_admin_name'])) {
    header("Location: ../index");
}
?>

<!DOCTYPE html>
<html>

<head>
    <?php include 'inc/head.php'; ?>
</head>

<body>
    <div id="wrapper">

        <?php include 'inc/navbar.php'; ?>

        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">

                        <h3 class="page-header">
                            Slider Images &nbsp; <button class="btn btn-info" data-toggle="modal" data-target="#myModal"> + Add New </button>
                        </h3>

                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-12">
                        <!-- Advanced Tables -->
                        <div class="panel panel-default">
                            <!-- <div class="panel-heading">
                                Advanced Tables
                            </div> -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Image</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            include '../inc/dbConnection.php';
                                            $sql = " SELECT * FROM `swt_slider` ";
                                            $res = mysqli_query($con, $sql);
                                            if (mysqli_num_rows($res) > 0) {
                                                $count = 0;
                                                foreach ($res as $row) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count . "</td>";
                                                    echo "<td><img src='". $row['image'] ."' style='width: 65px'></td>";
                                                    ?>
                                                        <td>
                                                            <form action="task" method="POST">
                                                                <input type="hidden" name="imgID" value="<?php echo $row['id'] ?>">
                                                                <button type="submit" name="deleteImage"><i class="fa fa-trash-o"></i></button>
                                                            </form>
                                                        </td>
                                                    <?php
                                                    echo "</tr>";
                                                    $count++;
                                                }
                                            } else {
                                                echo "<tr>";
                                                echo "<td colspan='6' style='text-align: center; color: red;'>No Data Available...</td>";
                                                echo "</tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                        <!--End Advanced Tables -->
                    </div>
                </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>


        <!-- Modal -->
        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content" style="padding: 20px; width: 340px; margin:auto">
                    <h3>+ Add New Slider Image</h3>
                    <hr>
                    <form id="frmAddSlider" class="form-group">
                        <label for="">Select an image [1200px * 750px] :</label>
                        <input type="file" name="img" id="" class="form-control" required>
                        <input type="hidden" name="addSlider" value="OK">
                        <hr>
                        <button type="submit" class="btn btn-success btn-block" id="sbtButton">Add New</button>

                        <button type="button" class="btn btn-danger btn-block" data-dismiss="modal" style="margin-top: 10px;">Close</button>
                    </form>

                </div>

            </div>
        </div>

        <?php include '../inc/myMsg.php'; ?>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script>
            $("#frmAddSlider").submit(function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                document.getElementById("sbtButton").disabled = true;
                document.getElementById("sbtButton").innerHTML = '<i class="fa fa-spinner fa-spin" style="font-size: 20px;"></i>';
                $.ajax({
                    url: 'ajax.php',
                    type: 'POST',
                    data: formData,
                    success: function(data) {
                        if (data == "Done") {
                            myMsg('! Slider Image Successfuly Added');
                            document.getElementById("frmAddSlider").reset();
                            document.getElementById("sbtButton").disabled = false;
                            document.getElementById("sbtButton").innerHTML = 'Add New';
                        } else {
                            myMsg('! Oop\'s Something went wroung');
                            document.getElementById("frmAddSlider").reset();
                            document.getElementById("sbtButton").disabled = false;
                            document.getElementById("sbtButton").innerHTML = 'Add New';
                        }
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
            });
        </script>



        <!-- /. PAGE WRAPPER  -->
        <!-- /. WRAPPER  -->
        <!-- JS Scripts-->
        <!-- jQuery Js -->
        <script src="assets/js/jquery-1.10.2.js"></script>
        <!-- Bootstrap Js -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- Metis Menu Js -->
        <script src="assets/js/jquery.metisMenu.js"></script>
        <!-- DATA TABLE SCRIPTS -->
        <script src="assets/js/dataTables/jquery.dataTables.js"></script>
        <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function() {
                $('#dataTables-example').dataTable();
            });
        </script>
        <!-- Custom Js -->
        <script src="assets/js/custom-scripts.js"></script>

</body>

</html>