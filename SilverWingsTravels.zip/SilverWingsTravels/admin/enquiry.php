<?php
    session_start();
    if (!isset($_SESSION['swt_admin_name'])) {
        header("Location: ../index");
    }
?>

<!DOCTYPE html>
<html>

<head>
    <?php include 'inc/head.php'; ?>
</head>

<body>
    <div id="wrapper">

        <?php include 'inc/navbar.php'; ?>

        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="page-header">
                            All Enquiries
                        </h3>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-md-12">
                        <!-- Advanced Tables -->
                        <div class="panel panel-default">
                            <!-- <div class="panel-heading">
                                Advanced Tables
                            </div> -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Subject</th>
                                                <th>Message</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                include '../inc/dbConnection.php';
                                                $sql = " SELECT * FROM `swt_enquiry` ";
                                                $res = mysqli_query($con, $sql);
                                                if(mysqli_num_rows($res) > 0)
                                                {
                                                    $count = 0;
                                                    foreach($res as $row)
                                                    {   
                                                        echo "<tr>";
                                                            echo "<td>".$count."</td>";
                                                            echo "<td>".$row['name']."</td>";
                                                            echo "<td>".$row['email']."</td>";
                                                            echo "<td>".$row['phone']."</td>";
                                                            echo "<td>".$row['subject']."</td>";
                                                            echo "<td>".$row['message']."</td>";
                                                        echo "</tr>";
                                                        $count++;
                                                    }
                                                }
                                                else
                                                {
                                                    echo "<tr>";
                                                            echo "<td colspan='6' style='text-align: center; color: red;'>No Data Available...</td>";
                                                        echo "</tr>";
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                        <!--End Advanced Tables -->
                    </div>
                </div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
        <!-- /. WRAPPER  -->
        <!-- JS Scripts-->
        <!-- jQuery Js -->
        <script src="assets/js/jquery-1.10.2.js"></script>
        <!-- Bootstrap Js -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- Metis Menu Js -->
        <script src="assets/js/jquery.metisMenu.js"></script>
        <!-- DATA TABLE SCRIPTS -->
        <script src="assets/js/dataTables/jquery.dataTables.js"></script>
        <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function() {
                $('#dataTables-example').dataTable();
            });
        </script>
        <!-- Custom Js -->
        <script src="assets/js/custom-scripts.js"></script>

</body>

</html>