<?php
    include 'inc/dbConnection.php';
    if(isset($_POST['submitEnquiry']))
    {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $subject = $_POST['subject'];
        $phone = $_POST['phone'];
        $msg = $_POST['msg'];

        $sql = " INSERT INTO `swt_enquiry` (`name`, `email`, `subject`, `phone`, `message`) 
        VALUES ('$name', '$email', '$subject', '$phone', '$msg') ";

        if(mysqli_query($con, $sql))
        {
            echo "Done";
        }
        else
        {
            echo "Error";
        }
    }
    else
    {
        header("Location: index");
    }






?>