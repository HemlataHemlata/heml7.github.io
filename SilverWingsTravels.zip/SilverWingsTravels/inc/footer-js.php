<!--Jquery js-->
<script src="assets/js/jquery.min.js"></script>
<!-- Popper JS -->
<script src="assets/js/popper.min.js"></script>
<!--Bootstrap js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--Owl-Carousel js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--Lightgallery js-->
<script src="assets/js/lightgallery-all.js"></script>
<script src="assets/js/custom_lightgallery.js"></script>
<!--Slicknav js-->
<script src="assets/js/jquery.slicknav.min.js"></script>
<!--Magnific js-->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!--Nice Select js-->
<script src="assets/js/jquery.nice-select.min.js"></script>
<!-- Datepicker JS -->
<script src="assets/js/jquery.datepicker.min.js"></script>
<!--ClockPicker JS-->
<script src="assets/js/jquery-clockpicker.min.js"></script>
<!--Main js-->
<script src="assets/js/main.js"></script>