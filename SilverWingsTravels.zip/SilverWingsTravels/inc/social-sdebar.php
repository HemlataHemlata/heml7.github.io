<style>

  .icon-bar {
    position: fixed;
    bottom: 0;
    right: 15px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    z-index: 125485455;
    width: 55px;
  }

  .icon-bar a {
    display: block;
    text-align: center;
    padding: 14px 15px;
    transition: all 0.3s ease;
    color: white;
    font-size: 26px;
    border-radius: 50px;
    cursor: pointer;
  }

  .icon-bar a:hover {
    background-color: #FFCC29;
  }

  .icon-bar-2 {
    width: 55px;
    position: fixed;
    bottom: 0;
    left: 15px;
    right: 0;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    z-index: 125485455;
  }

  .icon-bar-2 a {
    border-radius: 50px;
    display: block;
    text-align: center;
    padding: 14px 14px;
    width: 55px;
    transition: all 0.3s ease;
    color: white;
    font-size: 26px;
    cursor: pointer;
  }

  .icon-bar-2 a:hover {
    background-color: #FFCC29;
  }

  .whatsapp {
    background: #00E676;
    color: white;
  }

  .linkedin {
    background: #007bb5;
    color: white;
  }

</style>


<div class="icon-bar">
  <a href="https://wa.me/917408889696?text=Hi, I'm interested in car booking" class="whatsapp"><i class="fa fa-whatsapp"></i></a>
</div>

<div class="icon-bar-2">
  <a href="tel:7408889696" class="linkedin" onclick="openReviewModal()"><i class="fa fa-phone" style="color: white;"></i></a>
</div>