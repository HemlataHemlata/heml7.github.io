<!-- spackbar for Notification message --------------------------------------------------------  -->
<style>
#snackbar {
  visibility: hidden;
  height: 45px;
  margin-left: 0px;
  background-image: linear-gradient(to right, #920F87, #3E0019);
  color: #fff;
  text-align: center;
  border-radius: 2px;
  padding: 10px;
  padding-left: 20px;
  position: fixed;
  z-index: 130000000 ;
  right: 0;
  top: 5px;
  font-size: 17px;
  border-top-left-radius: 50px;
  border-bottom-left-radius: 50px;
}

#snackbar.show {
  visibility: visible;
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 3.5s;
}

@-webkit-keyframes fadein {
  from {bottom: 0; opacity: 0;} 
  to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {bottom: 30px; opacity: 1;} 
  to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}
</style>

<div id="snackbar">Some text some message..</div>

<script>
    function myMsg(str) 
    {
        var x = document.getElementById("snackbar");
        x.innerHTML = str;
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    }
</script>