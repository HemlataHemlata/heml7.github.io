<!-- Header Top Area Start ->
<section class="gauto-header-top-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="header-top-left">
                    <p>Need Help?: <i class="fa fa-phone"></i> Call: +321 123 45 978</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="header-top-right">
                    <a href="#">
                        <i class="fa fa-key"></i>
                        login
                    </a>
                    <a href="#">
                        <i class="fa fa-user"></i>
                        register
                    </a>
                    <div class="dropdown">
                        <button class="btn-dropdown dropdown-toggle" type="button" id="dropdownlang" data-toggle="dropdown" aria-haspopup="true">
                            <img src="assets/img/en.png" alt="lang" /> English
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownlang">
                            <li><img src="assets/img/ca.png" alt="lang" /> Canada</li>
                            <li><img src="assets/img/fa.png" alt="lang" /> French</li>
                            <li><img src="assets/img/ja.png" alt="lang" /> Japanese</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!- Header Top Area End -->


<!-- Main Header Area Start -->
<header class="gauto-main-header-area">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="site-logo">
                    <a href="index">
                        <img src="assets/img/logo.png" alt="gauto" style="height: 55px;" />
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-sm-9">
                <div class="header-promo">
                    <div class="single-header-promo">
                        <div class="header-promo-icon">
                            <img src="assets/img/globe.png" alt="globe" />
                        </div>
                        <div class="header-promo-info">
                            <h3>123 i BLW Colony</h3>
                            <p>Varanasi, Uttar Pradesh</p>
                        </div>
                    </div>
                    <div class="single-header-promo">
                        <div class="header-promo-icon">
                            <img src="assets/img/clock.png" alt="clock" />
                        </div>
                        <div class="header-promo-info">
                            <h3>Mon to Sun</h3>
                            <p>6:00am - 11:00pm</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="header-action">
                    <a href="tel:7408889696"><i class="fa fa-phone"></i> Request a call</a>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Main Header Area End -->


<!-- Mainmenu Area Start -->
<section class="gauto-mainmenu-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="mainmenu">
                    <nav>
                        <ul id="gauto_navigation" style="text-align: center;">
                            <li class="active"><a href="index">home</a></li>
                            <li><a href="about">about</a></li>
                            <li>
                                <a href="service">Service</a>
                            </li>
                            <li>
                                <a href="car-listing">cars</a>
                                <!-- <ul>
                                    <li><a href="">car listing</a></li>
                                    <li><a href="car-booking.html">car booking</a></li>
                                </ul> -->
                            </li>
                            <li><a href="contact">contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
            <style>
                
                @media only screen and (min-width: 600px) {
                    .vsl-navbar {
                        display: none;
                    }
                }
                
            </style>
            <div class="col-lg-12 col-sm-12 vsl-navbar">
                <div class="main-search-right">
                    <!-- Responsive Menu Start -->
                    <div class="gauto-responsive-menu"></div>
                    <!-- Responsive Menu Start -->

                    <!-- Cart Box Start -->
                    <div class="header-cart-box">
                        <!-- <div class="login dropdown">
                            <button class="dropdown-toggle cart-icon" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span>2</span>
                            </button>
                            <div class="dropdown-menu cart-dropdown" aria-labelledby="dropdownMenu1">
                                <ul class="product_list">
                                    <li>
                                        <div class="cart-btn-product">
                                            <a class="product-remove" href="#">
                                                <i class="fa fa-times"></i>
                                            </a>
                                            <div class="cart-btn-pro-img">
                                                <a href="#">
                                                    <img src="assets/img/cart-1.png" alt="product" />
                                                </a>
                                            </div>
                                            <div class="cart-btn-pro-cont">
                                                <h4><a href="#">CAR SPOILERS</a></h4>
                                                <p>Quantity 2</p>
                                                <span class="price">
                                                    $29.99
                                                </span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="cart-btn-product">
                                            <a class="product-remove" href="#">
                                                <i class="fa fa-times"></i>
                                            </a>
                                            <div class="cart-btn-pro-img">
                                                <a href="#">
                                                    <img src="assets/img/cart-2.jpg" alt="product" />
                                                </a>
                                            </div>
                                            <div class="cart-btn-pro-cont">
                                                <h4><a href="#">CAR SPOILERS</a></h4>
                                                <p>Quantity 2</p>
                                                <span class="price">
                                                    $29.99
                                                </span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <div class="cart-subtotal">
                                    <p>
                                        Subtotal :
                                        <span class="drop-total">$59.98</span>
                                    </p>
                                </div>
                                <div class="cart-btn">
                                    <a href="#" class="cart-btn-1">View Cart</a>
                                    <a href="#" class="cart-btn-2">Checkout</a>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <!-- Cart Box End -->

                    <!-- Search Box Start -->
                        <!-- <div class="search-box">
                            <form>
                                <input type="search" placeholder="Search">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div> -->
                    <!-- Search Box End -->

                </div>
            </div>
        </div>
    </div>
</section>
<!-- Mainmenu Area End -->