<!-- Title -->
<title>Silver Wings Travels</title>
<meta name="google-site-verification" content="9Y3I6He4g5bROwAPNsbbt9507GMwo76r9LsU3KqGEJc" />
<link rel="canonical" href="http://silverwingstravels.in/" />

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="description" content="We are the fastest growing online car rental services provider that provides online taxi service on the lowest rate. We make available the taxi booking & corporate car rental services. We provide with the well trained, well dressed and the best referred Chauffer’s of the town.While they drive vehicle, you will enjoy the different world altogether.To serve you better, We give you a wide range of choices between rental car & taxi across India.Our services includes Chauffeur drive cars, ranging from luxury to ordinary car brands. We also provides exclusive railway transfers and airport transfers for pickup and drop facilities. ">

<meta name="keyword" content="taxi, car, rent, hire, transport,info.silverwingstravels@gmail.com, 7408889696, 7408889666, BLW, Durgakund, Assi,  Varanasi, kashi, varuna, silver wings travel, travel agency, travel agency near me, agent travel, agency travel, agency travel near me, best travel agency, luxury travel agency, best travel agency in india, best travel agency in india, best travel agency in kashi, best travel agency in delhi, Silver Wings Travels travel agency, travel agency car, travel agency mini bus,travel agency tempo Traveller, Tour operator, Vacation packages, Holiday deals, Travel planning, Destination management, Adventure travel, Luxury travel, Group tours, Travel itinerary, Honeymoon packages, Family vacations, Budget travel, Travel consultants, Online travel agency, Travel specials, Last-minute deals, Popular tourist destinations, Adventure travel, Cultural experiences, Road trips, Solo travel">

<meta name="author" content="Silver Wings Travels">


<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon.png">
<!--Bootstrap css-->
<link rel="stylesheet" href="assets/css/bootstrap.css">
<!--Font Awesome css-->
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<!--Magnific css-->
<link rel="stylesheet" href="assets/css/magnific-popup.css">
<!--Owl-Carousel css-->
<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
<!--Animate css-->
<link rel="stylesheet" href="assets/css/animate.min.css">
<!--Datepicker css-->
<link rel="stylesheet" href="assets/css/jquery.datepicker.css">
<!--Nice Select css-->
<link rel="stylesheet" href="assets/css/nice-select.css">
<!-- Lightgallery css -->
<link rel="stylesheet" href="assets/css/lightgallery.min.css">
<!--ClockPicker css-->
<link rel="stylesheet" href="assets/css/jquery-clockpicker.min.css">
<!--Slicknav css-->
<link rel="stylesheet" href="assets/css/slicknav.min.css">
<!--Site Main Style css-->
<link rel="stylesheet" href="assets/css/style.css">
<!--Responsive css-->
<link rel="stylesheet" href="assets/css/responsive.css">