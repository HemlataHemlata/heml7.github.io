<?php

    $serverName = "localhost";
    $userName = "root";
    $pswd = "";
    $dbName = "silver_wing_travel";

    $con = mysqli_connect($serverName, $userName, $pswd, $dbName);
    if(!$con)
    {
        echo "<br><br> <span style='color: red; font-size: 48px;'> Database Connection Failed !</span>";
    }

?>