<footer class="gauto-footer-area">
    <div class="footer-top-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="single-footer">
                        <div class="footer-logo">
                            <a href="#">
                                <img src="assets/img/logo.png" alt="footer-logo" />
                            </a>
                        </div>
                        <p>
                            Car booking is an essential step in planning a tour with your family. If you are planning to visit 
                            Varanasi, then you can book a car rental service.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="single-footer quick_links">
                        <h3>Quick Links</h3>
                        <ul class="quick-links">
                            <li><a href="index">Home</a></li>
                            <li><a href="about">About</a></li>
                            <li><a href="service">Services</a></li>
                        </ul>
                        <ul class="quick-links">
                            <li><a href="contact">Contact us</a></li>
                            <li><a href="car-listing">Cars</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="single-footer">
                        <h3>Address</h3>
                        <ul>
                            <li>
                                <div class="single-footer-post">
                                    <div class="footer-post-text">
                                        <h3>
                                            N 12/430-W-3K Bajardiha, Varanasi <br>
                                            B.O. : BLW, Durgakund, Assi
                                        </h3>
                                        <h3>
                                            Call: 7408889666, 7408889696
                                        </h3>
                                    </div>
                                </div>
                            </li>
                            
                           
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="copyright">
                        <p>Designed and Developed By <a href="http://www.genoviqweb.com" style="color: white;">GWPL</a></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="footer-social">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fa fa-google"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php include 'inc/social-sdebar.php'; ?>