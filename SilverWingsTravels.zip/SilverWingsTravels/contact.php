<!DOCTYPE html>
<html lang="en-US">

<head>
   <?php include 'inc/head.php'; ?>
</head>

<body>


   <!-- Header Top Area Start -->
   <?php include 'inc/navbar.php'; ?>


   <!-- Contact Area Start -->
   <section class="gauto-contact-area section_70">
      <div class="container">
         <div class="row">
            <div class="col-lg-7">
               <div class="contact-left">
                  <h3>Get in touch</h3>
                  <form id="frmContact">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="single-contact-field">
                              <input type="text" name="name" placeholder="Your Name" required>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="single-contact-field">
                              <input type="email" name="email" placeholder="Email Address" required>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="single-contact-field">
                              <input type="text" name="subject" placeholder="Subject" required>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="single-contact-field">
                              <input type="tel" name="phone" placeholder="Phone Number" required>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="single-contact-field">
                              <textarea name="msg" placeholder="Write here your message" required></textarea>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="single-contact-field">
                              <button type="submit" class="gauto-theme-btn" id="sbtButton" style="width: 200px;">
                                 <i class="fa fa-paper-plane"></i> Send Message
                              </button>
                           </div>
                        </div>
                     </div>
                     <input type="hidden" name="submitEnquiry" value="OK">
                  </form>
               </div>
            </div>
            <!-- lg5-->
            <div class="col-lg-5">
               <div class="contact-right">
                  <h3>Contact information</h3>
                  <div class="contact-details">
                     <p><i class="fa fa-map-marker"></i> 123 i BLW Colony Varanasi </p>
                     <div class="single-contact-btn">
                        <h4>Email Us</h4>
                        <a href="#">info.silverwingstravels@gmail.com</a>
                     </div>
                     <div class="single-contact-btn">
                        <h4>Call Us</h4>
                        <a href="tel:7408889696">740-888-9696</a>
                     </div>
					  <div class="single-contact-btn">
                        <h4>GST No.</h4>
						  <a href="#" style="text-transform: uppercase;">09CCNPK6717R1ZL</a>
                     </div>
                     <div class="social-links-contact">
                        <h4>Follow Us:</h4>
                        <ul>
                           <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                           <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                           <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                           <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                           <li><a href="#"><i class="fa fa-google"></i></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- Contact Area End -->
   <?php include 'inc/myMsg.php'; ?>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
   <script>
      $("#frmContact").submit(function(e) {
         e.preventDefault();
         var formData = new FormData(this);
         document.getElementById("sbtButton").disabled = true;
         document.getElementById("sbtButton").innerHTML = '<i class="fa fa-spinner fa-spin" style="font-size: 20px;"></i>';
         $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            success: function(data) {
               if (data == "Done") {
                  window.location.href='welcome';                  
                  // myMsg('! Enquiry Submited Successfuly');
                  document.getElementById("frmContact").reset();
                  document.getElementById("sbtButton").disabled = false;
                  document.getElementById("sbtButton").innerHTML = '<i class="fa fa-paper-plane"></i> Send Message';
               } else {
                  myMsg('! Invalid User Id Or Password');
                  document.getElementById("frmContact").reset();
                  document.getElementById("sbtButton").disabled = false;
                  document.getElementById("sbtButton").innerHTML = '<i class="fa fa-paper-plane"></i> Send Message';
               }
            },
            cache: false,
            contentType: false,
            processData: false
         });
      });
   </script>



   <!-- Footer Area Start -->
   <?php include 'inc/footer.php'; ?>
   <!-- Footer Area End -->
   <?php include 'inc/footer-js.php'; ?>

</body>

</html>