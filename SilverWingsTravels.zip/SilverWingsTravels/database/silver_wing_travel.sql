-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2024 at 07:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `silver_wing_travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `swt_admin`
--

CREATE TABLE `swt_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `swt_admin`
--

INSERT INTO `swt_admin` (`id`, `name`, `user_id`, `pass`, `created_at`, `modified_at`) VALUES
(1, 'Silver Wing Travels', '62f6ebd7948ee15af8db5f080001d67c', '62f6ebd7948ee15af8db5f080001d67c', '2023-07-05 05:04:28', '2023-07-05 05:04:28');

-- --------------------------------------------------------

--
-- Table structure for table `swt_enquiry`
--

CREATE TABLE `swt_enquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `message` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `swt_enquiry`
--

INSERT INTO `swt_enquiry` (`id`, `name`, `email`, `subject`, `phone`, `message`, `created_at`) VALUES
(1, 'testing demo', 'hello@gmail.com', 'demo ', '0101010102', 'NANANANA', '2024-07-23 06:27:57'),
(2, 'testing', 'demo@gmail.com', 'hello demo', '9878675432', 'NANAN', '2024-07-23 06:29:31'),
(3, 'testing', 'fifteen@gmail.com', 'fsdfs', '9087654321', 'NANA', '2024-07-23 06:33:07'),
(4, 'Bunny', 'bunny23@gmail.com', 'Bunny Subject', '2323232390', 'Silver Wings Travels', '2024-07-23 06:34:40'),
(5, 'crystal', 'crystal@gmail.com', 'Enquiry', '2239092376', 'NANA', '2024-07-23 06:45:37'),
(6, 'Jiya', 'jiya@gmail.com', 'Enquiry', '0101010102', 'NANANA', '2024-07-23 07:14:14'),
(7, 'Alexandra', 'alexandra23@gmail.com', 'Alexandra', '2323552390', 'Alexandra Testing', '2024-07-23 07:15:32');

-- --------------------------------------------------------

--
-- Table structure for table `swt_slider`
--

CREATE TABLE `swt_slider` (
  `id` int(11) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `ceated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `swt_admin`
--
ALTER TABLE `swt_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `swt_enquiry`
--
ALTER TABLE `swt_enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `swt_slider`
--
ALTER TABLE `swt_slider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `swt_admin`
--
ALTER TABLE `swt_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `swt_enquiry`
--
ALTER TABLE `swt_enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `swt_slider`
--
ALTER TABLE `swt_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
