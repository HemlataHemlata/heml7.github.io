<!DOCTYPE html>
<html lang="en-US">

<head>
   <?php include 'inc/head.php'; ?>
</head>

<body>


   <!-- Header Top Area Start -->
   <?php include 'inc/navbar.php'; ?>

   <!-- Breadcromb Area Start -->
   <section class="gauto-breadcromb-area section_70">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="breadcromb-box">
                  <h3>Car Listing</h3>
                  <ul>
                     <li><i class="fa fa-home"></i></li>
                     <li><a href="index">Home</a></li>
                     <li><i class="fa fa-angle-right"></i></li>
                     <li>car listing</li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- Breadcromb Area End -->


   <!-- Car Listing Area Start -->
   <section class="gauto-car-listing section_70">
      <div class="container">
         <div class="row">
            <div class="col-lg-8">
               <div class="car-listing-right">
                  <div class="property-page-heading">
                     <h3>Our Popular Car Fleets</h3>
                  </div>
                  <div class="car-grid-list">

                     <div class="row">
                        <div class="col-lg-6">
                           <div class="single-offers">
                              <div class="offer-image">
                                 <a href="#">
                                    <img src="assets/img/cars/artiga.png" alt="offer 1" />
                                 </a>
                              </div>
                              <div class="offer-text">
                                 <a href="#">
                                    <h3>Maruti Suzuki Ertiga</h3>
                                 </a>
                                 <div class="offer-action">
                                    <a href="tel:7408889696" class="offer-btn-1">Call Now</a>
                                    <a href="contact" class="offer-btn-1">Contact Us</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="single-offers">
                              <div class="offer-image">
                                 <a href="#">
                                    <img src="assets/img/cars/cysta.png" alt="offer 1" />
                                 </a>
                              </div>
                              <div class="offer-text">
                                 <a href="#">
                                    <h3>Toyota Innova Crysta</h3>
                                 </a>
                                 <div class="offer-action">
                                    <a href="tel:7408889696" class="offer-btn-1">Call Now</a>
                                    <a href="contact" class="offer-btn-1">Contact Us</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-6">
                           <div class="single-offers">
                              <div class="offer-image">
                                 <a href="#">
                                    <img src="assets/img/cars/dizir.png" alt="offer 1" />
                                 </a>
                              </div>
                              <div class="offer-text">
                                 <a href="#">
                                    <h3>Maruti Suzuki Dzire</h3>
                                 </a>
                                 <div class="offer-action">
                                    <a href="tel:7408889696" class="offer-btn-1">Call Now</a>
                                    <a href="contact" class="offer-btn-1">Contact Us</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="single-offers">
                              <div class="offer-image">
                                 <a href="#">
                                    <img src="assets/img/cars/innova.png" alt="offer 1" />
                                 </a>
                              </div>
                              <div class="offer-text">
                                 <a href="#">
                                    <h3>Toyota Innova</h3>
                                 </a>
                                 <div class="offer-action">
                                    <a href="tel:7408889696" class="offer-btn-1">Call Now</a>
                                    <a href="contact" class="offer-btn-1">Contact Us</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-6">
                           <div class="single-offers">
                              <div class="offer-image">
                                 <a href="#">
                                    <img src="assets/img/cars/mini-bus.png" alt="offer 1" />
                                 </a>
                              </div>
                              <div class="offer-text">
                                 <a href="#">
                                    <h3>Mini Bus</h3>
                                 </a>
                                 <div class="offer-action">
                                    <a href="tel:7408889696" class="offer-btn-1">Call Now</a>
                                    <a href="contact" class="offer-btn-1">Contact Us</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-6">
                           <div class="single-offers">
                              <div class="offer-image">
                                 <a href="#">
                                    <img src="assets/img/cars/tempu-traveler.png" alt="offer 1" />
                                 </a>
                              </div>
                              <div class="offer-text">
                                 <a href="#">
                                    <h3>Tempo Traveller</h3>
                                 </a>
                                 <div class="offer-action">
                                    <a href="tel:7408889696" class="offer-btn-1">Call Now</a>
                                    <a href="contact" class="offer-btn-1">Contact Us</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                  </div>
               </div>
            </div>
            <div class="col-lg-4">
               <div class="car-list-left">
                  <div class="sidebar-widget">
                     <form id="carListing">
                        <center>
                           <h3 style="margin-bottom: 30px;">Send Your Enquiry Now </h3>
                        </center>
                        <p>
                           <input type="text" name="name" placeholder="Your Name *" required />
                        </p>
                        <p>
                           <input type="text" name="email" placeholder="Email Address *" required />
                        </p>
                        <p>
                           <input type="text" name="subject" placeholder="Subject *" required />
                        </p>
                        <p>
                           <input type="text" name="phone" placeholder="Phone Number *" required>
                        </p>
                        <p>
                           <input type="text" name="msg" placeholder="Write Your Message Here *" style="height: 70px;" />
                        </p>
                        <p style="margin-top: 40px;">
                           <button type="submit" class="gauto-theme-btn" id="sbtButton">
                              <i class="fa fa-paper-plane"></i> Send Message
                           </button>
                        </p>
                        <input type="hidden" name="submitEnquiry" value="OK">
                     </form>
                  </div>

                  <img src="assets/img/about.png" alt="" style="margin-top: 70px;">
               </div>
            </div>

         </div>
      </div>
   </section>
   <!-- Car Listing Area End -->

   <?php include 'inc/myMsg.php'; ?>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
   <script>
      $("#carListing").submit(function(e) {
         e.preventDefault();
         var formData = new FormData(this);
         document.getElementById("sbtButton").disabled = true;
         document.getElementById("sbtButton").innerHTML = '<i class="fa fa-spinner fa-spin" style="font-size: 20px;"></i>';
         $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: formData,
            success: function(data) {
               if (data == "Done") {
                  myMsg('! Enquiry Submited Successfuly');
                  document.getElementById("carListing").reset();
                  document.getElementById("sbtButton").disabled = false;
                  document.getElementById("sbtButton").innerHTML = '<i class="fa fa-paper-plane"></i> Send Message';
               } else {
                  myMsg('! Invalid User Id Or Password');
                  document.getElementById("carListing").reset();
                  document.getElementById("sbtButton").disabled = false;
                  document.getElementById("sbtButton").innerHTML = '<i class="fa fa-paper-plane"></i> Send Message';
               }
            },
            cache: false,
            contentType: false,
            processData: false
         });
      });
   </script>


   <!-- Footer Area Start -->
   <?php
   include 'inc/footer.php';
   include 'inc/footer-js.php';
   ?>

</body>

</html>