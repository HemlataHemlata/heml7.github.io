
   <?php
}


elseif($Event=='Decoration')
{
  ?>
   <div class="container">
      <div class="row align-items-center">
      <div class="col-lg-5" id="display-wrap-show">
            <h2 class="title">What <span>Decoration</span> We
               Offer
            </h2>
            <p class=" mt-3 ">we specialize in transforming ordinary spaces into extraordinary settings for a wide range of occasions.</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
         <div class="col-lg-7">
            <div class="row card-items">
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-laptop"></i> -->
                        <img src="assets/img/Evm/d-1.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Event Decor</h4>
                        <p class="card-text"> Whether it’s a grand wedding reception or an intimate birthday party, we create stunning decor that aligns with your vision. From floral arrangements to lighting, we ensure every detail is exquisite.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-droplet-half"></i> -->
                        <img src="assets/img/Evm/d-3.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Themed Decor</h4>
                        <p class="card-text">Our team specializes in creating captivating event themes, designing décor, and styling venues. <br/> From lighting to catering, sound, vision, and entertainment, we pay attention to every detail.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-envelope-open"></i> -->
                        <img src="assets/img/Evm/d-2.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Balloon Decor</h4>
                        <p class="card-text">Balloons add a touch of whimsy and playfulness to any celebration. We offer balloon arches, centerpieces, and creative balloon installations that elevate the ambiance.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-phone"></i> -->
                        <img src="assets/img/Evm/d-4.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Lighting and Draping</h4>
                        <p class="card-text"> Lighting transforms spaces magically. Whether it’s fairy lights, chandeliers, or elegant drapery, we use lighting strategically to create an enchanting atmosphere.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-5" id="display-wrap">
            <h2 class="title">What <span>Decoration</span> We
               Offer
            </h2>
            <p class=" mt-3 ">we specialize in transforming ordinary spaces into extraordinary settings for a wide range of occasions.</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
      </div>
   </div>
   <?php
}
elseif($Event=='PreWedding')
{
  ?>
   <div class="container">
      <div class="row align-items-center">
      <div class="col-lg-5" id="display-wrap-show">
            <h2 class="title">What <span>Pre Wedding</span> We
               Offer
            </h2>
            <p class=" mt-3 ">Pre-wedding events are an exciting part of the wedding journey, and event companies offer a range of services to make these celebrations memorable. Here are some popular pre-wedding events and the services event companies typically provide:</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
         <div class="col-lg-7">
            <div class="row card-items">
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-laptop"></i> -->
                        <img src="assets/img/Evm/pw-1.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Pre-Wedding Photography and Videography</h4>
                        <p class="card-text">Our skilled photographers capture candid moments, love stories, and the chemistry between couples.
We offer both traditional and cinematic styles, tailoring the shoot to your preferences.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-droplet-half"></i> -->
                        <img src="assets/img/Evm/pw-2.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Location Selection and Planning</h4>
                        <p class="card-text">Choosing the perfect backdrop for your pre-wedding shoot is crucial. We assist in selecting picturesque locations.
Whether it’s a serene garden, a historic monument, or an urban setting, we help you find the ideal spot.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-envelope-open"></i> -->
                        <img src="assets/img/Evm/pw-3.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Themed decorations</h4>
                        <p class="card-text">Themed decorations add a touch of magic and personality to any event.</br>Tablecloths, napkins, and table runners should align with the theme.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-phone"></i> -->
                        <img src="assets/img/Evm/pw-4.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Wall Decorations</h4>
                        <p class="card-text">Wall decorations play a pivotal role in transforming any space, adding personality, warmth, and visual interest. Whether you’re aiming for a cozy home or an elegant event</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-5" id="display-wrap">
            <h2 class="title">What <span>Pre Wedding</span> We
               Offer
            </h2>
            <p class=" mt-3 ">Pre-wedding events are an exciting part of the wedding journey, and event companies offer a range of services to make these celebrations memorable. Here are some popular pre-wedding events and the services event companies typically provide:</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
      </div>
   </div>
   <?php
}
elseif($Event=='CorporateParty')
{
  ?>
   <div class="container">
      <div class="row align-items-center">
      <div class="col-lg-5" id="display-wrap-show">
            <h2 class="title">What <span>Corporate Party</span> We
               Offer
            </h2>
            <p class=" mt-3 ">When it comes to corporate events, there are various services and solutions that event companies offer to create memorable and impactful experiences. Here are some key offerings:</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
         <div class="col-lg-7">
            <div class="row card-items">
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-laptop"></i> -->
                        <img src="assets/img/Evm/ev-3.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Event Planning and Coordination</h4>
                        <p class="card-text">We help you choose the perfect location for your event, considering factors like capacity, ambiance, and accessibility.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-droplet-half"></i> -->
                        <img src="assets/img/Evm/cp-1.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Event Design and Creative Solutions</h4>
                        <p class="card-text">Our team collaborates with you to create a unique brand identity for your event. This includes custom logos, color schemes, and visual elements that resonate with your audience.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-envelope-open"></i> -->
                        <img src="assets/img/Evm/cp-2.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Event Sponsorship Opportunities</h4>
                        <p class="card-text">Brand Exposure: Sponsors align their brand with your event’s audience and objectives, reaching a wider audience.
Industry Exclusivity: Sponsors may secure exclusivity within their industry or product category.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-phone"></i> -->
                        <img src="assets/img/Evm/cp-3.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Event Strategy and Business Intelligence</h4>
                        <p class="card-text">Define Your Goals, Set specific, measurable, attainable, relevant, and time-bound (SMART) goals for your event. These goals provide direction and help measure progress.
</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-5" id="display-wrap">
            <h2 class="title">What <span>Corporate Party</span> We
               Offer
            </h2>
            <p class=" mt-3 ">When it comes to corporate events, there are various services and solutions that event companies offer to create memorable and impactful experiences. Here are some key offerings:</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
      </div>
   </div>
   <?php
}

elseif($Event=='HaldiCeremony')
{
  ?>
   <div class="container">
      <div class="row align-items-center">
      <div class="col-lg-5" id="display-wrap-show">
            <h2 class="title">What <span>Haldi Ceremony</span> We
               Offer
            </h2>
            <p class=" mt-3 ">Let’s explore the offerings related to the Haldi ceremony, a joyous and lively pre-wedding ritual in Indian weddings:</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
         <div class="col-lg-7">
            <div class="row card-items">
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-laptop"></i> -->
                        <img src="assets/img/Evm/h-1.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Haldi Ceremony Overview</h4>
                        <p class="card-text">The Haldi ceremony involves applying a paste of turmeric, sandalwood powder, and rose water to the bride and groom’s bodies. This cleansing ritual is believed to bring purity and protect against negative energies.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-droplet-half"></i> -->
                        <img src="assets/img/Evm/h-2.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Significance of Haldi</h4>
                        <p class="card-text">Skin Benefits, Turmeric and sandalwood are known for their anti-inflammatory and germ-fighting properties. Applying the haldi paste a day before the wedding results in glowing skin on the big day.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-envelope-open"></i> -->
                        <img src="assets/img/Evm/h-3.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Decor and Fun</h4>
                        <p class="card-text">Event management companies offer creative and personalized Haldi decoration options. In Kerala, for example, Haldi decor blends tradition, culture, and local charm.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-phone"></i> -->
                        <img src="assets/img/Evm/h-4.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Fun Moments</h4>
                        <p class="card-text">The entire family dances, celebrates, and shares in the joy of applying haldi to the couple.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-5" id="display-wrap">
            <h2 class="title">What <span>Haldi Ceremony</span> We
               Offer
            </h2>
            <p class=" mt-3 ">Let’s explore the offerings related to the Haldi ceremony, a joyous and lively pre-wedding ritual in Indian weddings:</p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal" data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
      </div>
   </div>
   <?php
}

elseif($Event=='SocialEvents')
{
  ?>
   <div class="container">
      <div class="row align-items-center">
      <div class="col-lg-5" id="display-wrap-show">
            <h2 class="title">What <span>Social Events</span> We
               Offer
            </h2>
            <p class=" mt-3 ">Social events are vibrant occasions that bring people together, fostering connections, joy, and shared experiences. </p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal"
             data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
         <div class="col-lg-7">
            <div class="row card-items">
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-laptop"></i> -->
                        <img src="assets/img/Evm/s-1.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Conferences</h4>
                        <p class="card-text">Multifaceted gatherings that blend keynotes, panels, breakout sessions, and roundtables. They foster learning and networking simultaneously.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-droplet-half"></i> --> 
                        <img src="assets/img/Evm/s-2.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title">Award Galas</h4>
                        <p class="card-text">Celebrate team achievements and individual successes through prestigious award ceremonies that acknowledge hard work and dedication.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-envelope-open"></i> -->
                        <img src="assets/img/Evm/s-3.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Consumer Fairs</h4>
                        <p class="card-text"> Themed fairs where vendors display products and services aligned with specific niches, enabling engaged interactions with potential consumers.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6">
                  <div class="card">
                     <div class="card-body">
                        <!-- <i class="bi bi-phone"></i> -->
                        <img src="assets/img/Evm/s-4.jpg" class="img-fluid img-fix" alt="">
                        <h4 class="card-title"> Expert Panel Discussions</h4>
                        <p class="card-text">Curate panel sessions that assemble experts for in-depth discussions, whether as standalone events or integrated within conferences.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-5" id="display-wrap">
            <h2 class="title">What <span>Social Events</span> We
               Offer
            </h2>
            <p class=" mt-3 ">Social events are vibrant occasions that bring people together, fostering connections, joy, and shared experiences. </p>
            <!-- <a class="btn btn-primary my-5" href="index#booking">Book now </a> -->
            <button type="button" class="btn btn-outline-danger btn-lg my-5" data-toggle="modal"
             data-target="#myModal" onclick="openEnquiryModal()">Book Now</button>
         </div>
      </div>
   </div>