 <!-- Required meta tags -->
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>UI Portfolio - Personal Category Bootstrap Responsive Website Template - Home : W3Layouts</title>

    <!-- google-fonts -->
    <link href="http://fonts.googleapis.com/css2?family=Dosis:wght@300;400;500;600;800&amp;display=swap" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&amp;display=swap" rel="stylesheet">
    <!-- //google-fonts -->

    <!-- Template CSS Style link -->
    <link rel="stylesheet" href="assets/css/style-liberty.css">
