
<!doctype html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
   <?php
   include('link.php');
   ?>
</head>

<body>
<script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src='https://www.googletagmanager.com/gtag/js?id=G-98H8KRKT85'></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-98H8KRKT85');
</script>

<meta name="robots" content="noindex">
<body><link rel="stylesheet" href="../../../../../../assests/css/font-awesome.min.css">
<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#w3lDemoBar.w3l-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#w3lDemoBar.w3l-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#w3lDemoBar.w3l-demo-bar span.w3l-icon {
  display: block;
}

#w3lDemoBar.w3l-demo-bar a:hover {
  opacity: 1;
}

#w3lDemoBar.w3l-demo-bar .w3l-icon svg {
  color: #e6ebff;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#w3lDemoBar.w3l-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#w3lDemoBar.w3l-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}


/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}



@media (max-width: 992px) {
  #w3lDemoBar.w3l-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #w3lDemoBar.w3l-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #w3lDemoBar.w3l-demo-bar a.mobile-mode{
      display: none;
  }
  #w3lDemoBar.w3l-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #w3lDemoBar.w3l-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>



    <!--header-->
<?php
include('header.php');
?>
    <!--//header-->

    <!-- banner section -->
    <section id="home" class="w3l-banner pt-5">
        <div class="container pt-lg-5 pt-md-4">
            <div class="row pt-lg-5 pt-4">
                <div class="col-lg-7 banner-info-grid pt-lg-0 pt-5">
                    <h1 class="mb-3">Hi, I'm Hemlata</h1>
                    <h3 class="mb-4" > <span class="typed-text"></span><span class="cursor">&nbsp</span> </h3>
                    <p>I love Web designing and Developing. I Can
                        give your business a new Creative start right away!</p>
                    
                    <a class="btn btn-primary btn-style mt-5 me-2" href="contact"> Hire Me </a>
                    <a class="btn btn-style transparent-btn mt-5" href="#portfolio"> My Portfolio </a>
                    
                </div>
                <div class="col-lg-5 text-lg-end my-image mt-lg-0 mt-4">
                    <img src="assets/images/self-banner.png" class="img-fluid" />
                </div>
            </div>
        </div>
    </section>
    <!-- //banner section -->


    <!-- About Section-->
    <section class="w3l-about py-5" id="about">
        <div class="container py-md-5 py-2">
            <div class="row w3l-row">
                <div class="col-lg-5 my-image pe-lg-5 mb-lg-0 mb-md-5 mb-4">
                    <img src="assets/images/about.jpg" alt="" class="img-fluid">
                </div>
                <div class="col-lg-7 w3l-about-info px-lg-4 align-center">
                    <h6 class="w3l-title-small mb-1">My Biography</h6>
                    <h3 class="w3l-title-main mb-2">A Lead UI Designer & Web Developer based in India</h3>
                    <p class="my-4 pe-lg-5">I love Web design and Developing. I Can give your business a new Creative start right away! Contact me and we will discuss your projects!</p>
                    <div class="my-info mt-4">
                        <div class="single-info"><span>Name:</span>
                            <p>Hemlata</p>
                        </div>
                        <div class="single-info"><span>From:</span>
                            <p>Delhi, India</p>
                        </div>
                        <div class="single-info"><span>Email:</span>
                            <p><a href="mailto:heml21604@gmail.com"><span class="__cf_email__" data-cfemail="4b2e332a263b272e0b262a222765282426">heml21604@gmail.com</span></a></p>
                        </div>
                        <div class="single-info"><span>Phone:</span>
                            <p><a href="tel:+91 8851150463">+91 8851150463</a></p>
                        </div>
                    </div>

                    <ul class="follow-social mt-lg-5 mt-4">
                        <li>
                            <h5 class="me-md-3">Follow me on </h5>
                        </li>

                        <li><a href="#"><span class="fab fa-behance"></span></a>
                        </li>

                        <li><a href="https://www.linkedin.com/in/hemlata-hemlata"><span class="fab fa-linkedin-in"></span></a>
                        </li>

                        <li><a href="#">
                                <span class="fab fa-facebook-f"></span></a></li>

                        <li><a href="#"><span class="fab fa-twitter"></span></a></li>

                    </ul>
                    <div class="w3l-btn">
                        <a href="contact" class="btn btn-style btn-primary mt-lg-5 mt-4 me-md-2">Hire me</a>
                        <a href="#" class="btn btn-style btn-secondary mt-lg-5 mt-4 download">Download CV</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //About Section-->


    <!-- Services Section -->
    <section class="about-section py-5">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="title-heading-w3 mx-auto text-center mb-sm-5 mb-4">
                <h3 class="w3l-title-main">What I do for you</h3>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-6">
                    <div class="about-single">
                        <div class="about-icon mb-4">
                            <i class="fas fa-chalkboard"></i>
                        </div>
                        <div class="about-content">
                            <h5 class="mb-3"><a href="#url">Web Development</a></h5>
                            <p>Web development involves creating, building, and maintaining websites and web applications. It encompasses various aspects, including web design, web programming, server administration, and database management. Web developers utilize languages such as HTML, CSS, and JavaScript to structure and style web pages, as well as to make them interactive and dynamic.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-single">
                        <div class="about-icon mb-4">
                            <i class="fab fa-app-store"></i>
                        </div>
                        <div class="about-content">
                            <h5 class="mb-3"><a href="#url"> App development</a></h5>
                            <p>
App development involves the process of creating software applications that run on various platforms such as mobile devices, desktop computers, or web browsers. It encompasses designing, developing, testing, and deploying applications to meet specific user needs or solve particular problems.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-lg-0 mt-3">
                    <div class="about-single">
                        <div class="about-icon mb-4">
                            <i class="fas fa-camera-retro"></i>
                        </div>
                        <div class="about-content">
                            <h5 class="mb-3"><a href="#url"> Photoshop</a></h5>
                            <p>Photoshop is a powerful and versatile graphics editing software developed by Adobe Inc. It is widely used by professionals and enthusiasts alike for manipulating and enhancing digital images, creating artwork, designing graphics for print or web, and much more.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="w3l-btn text-center">
                <a href="services" class="btn btn-border mt-lg-5 mt-4 me-2">
                    More services <span class="fas fa-long-arrow-alt-right"></span></a>
            </div>
        </div>
    </section>
    <!-- //Services Section -->





    <section class="w3l-skills py-5" id="skills">
        <div class="container py-lg-5 py-md-4 py-3">
            <div class="row">
                <div class="col-lg-6 pe-lg-5">
                    <img src="assets/images/about1.jpg" alt="" class="img-fluid">
                </div>
                <div class="col-lg-6 mt-lg-0 mt-5 w3l-content-6 px-lg-4 align-self-center">
                    <h6 class="w3l-title-small mb-2">My skills</h6>
                    <h3 class="w3l-title-main">My Featured skills</h3>
                    <p class="mt-4">"I specialize in branding and strategy, and I'm deeply passionate about crafting exceptional websites that not only work flawlessly but also leave a lasting impact. With a constant drive to impress the audience, I am always ready to showcase my creativity." </p>
                    <div class="progress-info mt-5">
                        <h6 class="progress-tittle">UI/UX Design</h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                    <div class="progress-info">
                        <h6 class="progress-tittle">Ideas &amp; Technology
                        </h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                    <div class="progress-info">
                        <h6 class="progress-tittle">Branding Design</h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                    <div class="progress-info mb-0">
                        <h6 class="progress-tittle">Responsive Web Design</h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Why Choose Us Section-->
    <section class="w3l-whychooseus pt-5" id="about1">
        <div class="container pt-lg-0 pt-md-4 pt-2">
            <div class="row align-items-center">
                <div class="col-lg-7 pe-lg-5 align-items-center">
                    <div class="row two-grids">
                        <div class="col-sm-6 grids_info d-flex">
                            <i class="fab fa-wordpress-simple"></i>
                            <div class="detail ms-3">
                                <h4 class="w3l-subtitle">Web Development</h4>
                                <p>Web developers utilize languages such as HTML, CSS, and JavaScript to structure and style web pages, as well as to make them interactive and dynamic.
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-6 grids_info d-flex mt-sm-0 mt-4">
                            <i class="fab fa-css3-alt"></i>
                            <div class="detail ms-3">
                                <h4 class="w3l-subtitle">Design Trends</h4>
                                <p>In web design, trends often revolve around user experience and interactivity, with features like responsive design, scroll-triggered animations, and immersive multimedia experiences gaining popularity. 
                                </p>
                            </div>
                        </div>
                        <!-- <div class="col-sm-6 grids_info d-flex mt-md-5 mt-4">
                            <i class="fas fa-chart-line"></i>
                            <div class="detail ms-3">
                                <h4 class="w3l-subtitle">Research & Analysis</h4>
                                <p>Research and analysis play a crucial role in informing decision-making processes across various domains. In business, market research helps companies understand customer needs, evaluate competitors, and identify opportunities for growth. 
                                </p>
                            </div>
                        </div> -->
                        <!-- <div class="col-sm-6 grids_info d-flex mt-md-5 mt-4">
                            <i class="fas fa-headset"></i>
                            <div class="detail ms-3">
                                <h4 class="w3l-subtitle">Customer support</h4>
                                <p>Lorem ipsum viverra libero set. Pellen ut justo, in ligula at.
                                </p>
                            </div>
                        </div> -->
                        <div class="col-sm-6 grids_info d-flex mt-md-5 mt-4">
                            <i class="fas fa-mobile-alt"></i>
                            <div class="detail ms-3">
                                <h4 class="w3l-subtitle">Responsive design</h4>
                                <p>Responsive design ensures that a website adapts dynamically to the device on which it is being viewed, whether it's a desktop computer, laptop, tablet, or smartphone. This adaptation involves adjusting the layout, content, and functionality of the website to ensure readability, usability, and accessibility regardless of the screen size or orientation.
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-6 grids_info d-flex mt-md-5 mt-4">
                            <i class="fas fa-layer-group"></i>
                            <div class="detail ms-3">
                                <h4 class="w3l-subtitle">PSD Design</h4>
                                <p>In web design, PSD files are commonly used to create website layouts, user interface elements, and graphics. Designers can design individual pages or entire website templates using Photoshop, incorporating elements such as headers, navigation menus, buttons, and images. These PSD files can then be exported and converted into HTML, CSS, or other web-compatible formats for implementation.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 ps-lg-5 my-image mt-lg-0 mt-4">
                    <img src="assets/images/banner.png" alt="" class="img-fluid">
                </div>

            </div>
        </div>
    </section>
    <!-- //Why Choose Us Section-->



    
    <!-- Stats Section-->
    <section class="w3l-stats-section py-5" id="stats">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="w3l-stats-inner-inf py-lg-4">
                <div class="row stats-con text-center">
                    <div class="col-lg-3 col-6 stats_info counter_grid">
                        <p class="counter"> 250 </p>
                        <h3>Finished Projects</h3>
                    </div>
                    <div class="col-lg-3 col-6 stats_info counter_grid">
                        <p class="counter"> 2500 </p>
                        <h3>Working Hours</h3>
                    </div>
                    <div class="col-lg-3 col-6 stats_info counter_grid mt-lg-0 mt-sm-5 mt-5">
                        <p class="counter"> 1280 </p>
                        <h3>Online Support</h3>
                    </div>
                    <div class="col-lg-3 col-6 stats_info counter_grid mt-lg-0 mt-sm-5 mt-5">
                        <p class="counter"> 180 </p>
                        <h3>Happy Customers</h3>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- //Stats Section-->


    <!-- portfolio -->
    <section class="w3-gallery py-5" id="portfolio">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="title-heading-w3 mx-auto text-center mb-sm-5 mb-4">
                <h3 class="w3l-title-main mb-2">My Success Work</h3>
            </div>
            <div class="row portfolio-area clearfix p-0 m-0">
                <div class="col-lg-4 col-md-6 portfolio-item2 content" data-id="id-1" data-type="cat-item-1">
                    <span class="image-block">
                        <a class="image-zoom" href="assets/images/eventvilla.jpg" data-gal="prettyPhoto[gallery]">
                            <div class="content-overlay"></div>
                            <img src="assets/images/eventvilla.jpg" class="img-fluid w3layouts agileits" alt="portfolio-img" style="height:235px; width: 100%;">
                            <div class="content-details fadeIn-bottom">
                                <h3 class="content-title">event Villa</h3>
                                <p class="content-text">This is a short description</p>
                            </div>
                        </a>
                    </span>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item2 content mt-md-0 mt-4" data-id="id-2" data-type="cat-item-2">
                    <span class="image-block">
                        <a class="image-zoom" href="assets/images/shipping.jpg" data-gal="prettyPhoto[gallery]">
                            <div class="content-overlay"></div>
                            <img src="assets/images/shipping.jpg" class="img-fluid w3layouts agileits" alt="portfolio-img" style="height:235px; width: 100%;">
                            <div class="content-details fadeIn-bottom">
                                <h3 class="content-title">Golden Emerald Shipping Services </h3>
                                <p class="content-text">This is a short description</p>
                            </div>
                        </a>
                    </span>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item2 content mt-lg-0 mt-4" data-id="id-3" data-type="cat-item-3">
                    <span class="image-block">
                        <a class="image-zoom" href="assets/images/commercial.jpg" data-gal="prettyPhoto[gallery]">
                            <div class="content-overlay"></div>
                            <img src="assets/images/commercial.jpg" class="img-fluid w3layouts agileits" alt="portfolio-img" style="height:235px; width: 100%;">
                            <div class="content-details fadeIn-bottom">
                                <h3 class="content-title">commercial Brokers</h3>
                                <p class="content-text">This is a short description</p>
                            </div>
                        </a>
                    </span>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item2 content mt-4" data-id="id-4" data-type="cat-item-4">
                    <span class="image-block">
                        <a class="image-zoom" href="assets/images/petrol.jpg" data-gal="prettyPhoto[gallery]">
                            <div class="content-overlay"></div>
                            <img src="assets/images/petrol.jpg" class="img-fluid w3layouts agileits" alt="portfolio-img" style="height:235px; width: 100%;">
                            <div class="content-details fadeIn-bottom">
                                <h3 class="content-title">petroleum Trading</h3>
                                <p class="content-text">This is a short description</p>
                            </div>
                        </a>
                    </span>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item2 content mt-4" data-id="id-5" data-type="cat-item-5">
                    <span class="image-block">
                        <a class="image-zoom" href="assets/images/logistic.jpg" data-gal="prettyPhoto[gallery]">
                            <div class="content-overlay"></div>
                            <img src="assets/images/logistic.jpg" class="img-fluid w3layouts agileits" alt="portfolio-img" style="height:235px; width: 100%;">
                            <div class="content-details fadeIn-bottom">
                                <h3 class="content-title">logistic</h3>
                                <p class="content-text">This is a short description</p>
                            </div>
                        </a>
                    </span>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item2 content mt-4" data-id="id-7" data-type="cat-item-6">
                    <span class="image-block">
                        <a class="image-zoom" href="assets/images/finance.jpg" data-gal="prettyPhoto[gallery]">
                            <div class="content-overlay"></div>
                            <img src="assets/images/finance.jpg" class="img-fluid w3layouts agileits" alt="portfolio-img" style="height:235px; width: 100%;">
                            <div class="content-details fadeIn-bottom">
                                <h3 class="content-title">finance </h3>
                                <p class="content-text">This is a short description</p>
                            </div>
                        </a>
                    </span>
                </div>
                <div class="col-lg-4 col-md-6 portfolio-item2 content mt-4" data-id="id-7" data-type="cat-item-6">
                    <span class="image-block">
                        <a class="image-zoom" href="assets/images/valiant.jpg" data-gal="prettyPhoto[gallery]">
                            <div class="content-overlay"></div>
                            <img src="assets/images/valiant.jpg" class="img-fluid w3layouts agileits" alt="portfolio-img" style="height:235px; width: 100%;">
                            <div class="content-details fadeIn-bottom">
                                <h3 class="content-title">valiant Communication </h3>
                                <p class="content-text">This is a short description</p>
                            </div>
                        </a>
                    </span>
                </div>
            </div>
            <!--end portfolio-area -->
        </div>
        <!-- //gallery container -->
    </section>
    <!-- //portfolio -->


    <!--/brands-->
    <section class="w3l-brands py-md-5 py-4">
        <div class="container py-lg-2">
            <div class="align-items-center">
                <div id="owl-demo" class="owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/images/logo1.png" class="img-fluid" alt="Brand">
                    </div>
                    <div class="item">
                        <img src="assets/images/logo2.png" class="img-fluid" alt="Brand">
                    </div>

                    <div class="item">
                        <img src="assets/images/logo3.png" class="img-fluid" alt="Brand">
                    </div>

                    <div class="item">
                        <img src="assets/images/logo4.png" class="img-fluid" alt="Brand">
                    </div>

                    <div class="item">
                        <img src="assets/images/logo5.png" class="img-fluid" alt="Brand">
                    </div>

                    <div class="item">
                        <img src="assets/images/logo1.png" class="img-fluid" alt="Brand">
                    </div>
                    <div class="item">
                        <img src="assets/images/logo2.png" class="img-fluid" alt="Brand">
                    </div>

                    <div class="item">
                        <img src="assets/images/logo3.png" class="img-fluid" alt="Brand">
                    </div>

                    <div class="item">
                        <img src="assets/images/logo4.png" class="img-fluid" alt="Brand">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //brands -->



     <!-- footer -->
<?php
include('footer.php');
?>
    <!-- //footer -->



    <!-- Js scripts -->
    <!-- move top -->
    <button onclick="topFunction()" id="movetop" title="Go to top">
        <span class="fas fa-level-up-alt" aria-hidden="true"></span>
    </button>
    <script data-cfasync="false" src="../../../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("movetop").style.display = "block";
            } else {
                document.getElementById("movetop").style.display = "none";
            }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>
    <!-- //move top -->

    <!-- common jquery plugin -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- //common jquery plugin -->

    <!-- theme switch js (light and dark)-->
    <script src="assets/js/theme-change.js"></script>
    <!-- //theme switch js (light and dark)-->

    <!--search-bar-->
    <script src="assets/js/search.js"></script>
    <!--//search-bar-->

    <!--/stats-number-counter-->
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/jquery.countup.js"></script>
    <script>
        $('.counter').countUp();

    </script>
    <!--//stats-number-counter-->

    <!--/owlcarousel-->
    <script src="assets/js/owl.carousel.js"></script>
    <!-- //brands-->
    <script>
        $(document).ready(function() {
            $("#owl-demo").owlCarousel({
                loop: true,
                autoplay: true,
                autoplaySpeed: 1500,
                nav: false,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 2,
                        nav: false
                    },
                    568: {
                        items: 3,
                        nav: false
                    },
                    768: {
                        items: 4,
                        nav: false
                    }
                }
            })
        })

    </script>
    <!-- //brands-->

    <!-- /typig-text-->
    <script>
        const typedTextSpan = document.querySelector(".typed-text");
        const cursorSpan = document.querySelector(".cursor");

        const textArray = ["Web Designer", "Web Developer", "Freelancer"];
        const typingDelay = 200;
        const erasingDelay = 10;
        const newTextDelay = 100; // Delay between current and next text
        let textArrayIndex = 0;
        let charIndex = 0;

        function type() {
            if (charIndex < textArray[textArrayIndex].length) {
                if (!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
                typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
                charIndex++;
                setTimeout(type, typingDelay);
            } else {
                cursorSpan.classList.remove("typing");
                setTimeout(erase, newTextDelay);
            }
        }

        function erase() {
            if (charIndex > 0) {
                // add class 'typing' if there's none
                if (!cursorSpan.classList.contains("typing")) {
                    cursorSpan.classList.add("typing");
                }
                typedTextSpan.textContent = textArray[textArrayIndex].substring(0, 0);
                charIndex--;
                setTimeout(erase, erasingDelay);
            } else {
                cursorSpan.classList.remove("typing");
                textArrayIndex++;
                if (textArrayIndex >= textArray.length) textArrayIndex = 0;
                setTimeout(type, typingDelay);
            }
        }

        document.addEventListener("DOMContentLoaded", function () { // On DOM Load initiate the effect
            if (textArray.length) setTimeout(type, newTextDelay + 250);
        });
    </script>
    <!-- //typig-text-->


    <!-- jQuery-Photo-filter-lightbox-portfolio-plugin -->
    <script src="assets/js/jquery-1.7.2.js"></script>
    <script src="assets/js/jquery.quicksand.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="assets/js/jquery.prettyPhoto.js"></script>
    <!-- //jQuery-Photo-filter-lightbox-portfolio-plugin -->

    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function () {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function () {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });
    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>
    <!-- //disable body scroll which navbar is in active -->

    <!--bootstrap-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap-->
    <!-- //Js scripts -->


<script>(function(){if (!document.body) return;var js = "window['__CF$cv$params']={r:'87e02430fea18dea',t:'MTcxNDczODE1OC40MjMwMDA='};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../../../../../cdn-cgi/challenge-platform/h/g/scripts/jsd/d0ff3ebede6b/main.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>

</html>