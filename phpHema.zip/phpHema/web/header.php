<header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg stroke">
                <!-- <h1>
                    <a class="navbar-brand" href="index">
                        <i class="fab fa-asymmetrik"></i> Hemlata
                    </a>
                </h1> -->
                <!-- if logo is image enable this  --> 
            <a class="navbar-brand" href="index">
                <img src="assets/images/hh.png" alt="Your logo" title="Your logo" style="height:140px;" />
            </a> 
                <button class="navbar-toggler collapsed bg-gradient" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul class="navbar-nav ms-lg-auto align-items-center">
                        <li class="nav-item active">
                            <a class="nav-link" href="index">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.html">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link dropdown-toggle" href="#url" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Blog <span class="fas fa-angle-down"></span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="blog-nosidebar.html">Blog - no sidebar</a>
                                <a class="dropdown-item" href="blog-right-sidebar.html">Blog - right sidebar</a>
                                <a class="dropdown-item" href="blog-left-sidebar.html">Blog - left Sidebar</a>
                                <a class="dropdown-item" href="blogsingle-nosidebar.html">Blog Single - no sidebar</a>
                                <a class="dropdown-item" href="blogsingle-right-sidebar.html">Blog Single - right
                                    sidebar</a>
                                <a class="dropdown-item" href="blogsingle-left-sidebar.html">Blog Single - left
                                    sidebar</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link dropdown-toggle" href="#url" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Pages <span class="fas fa-angle-down"></span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="error.html">404 Page</a>
                                <a class="dropdown-item" href="email-template.html">Email Template</a>
                                <a class="dropdown-item" href="landing-single.html">Landing Page</a>
                                <a class="dropdown-item" href="shortcodes.html">Shortcodes</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact">Contact</a>
                        </li>

                        <!--/right-btn-->
                        <div class="header-btn mx-2">
                            <a class="btn btn-style btn-primary mr-lg-5" href="contact"> Hire Me</a>
                        </div>
                        <!--/right-btn-->

                    </ul>
                </div>

                <!-- search -->
                <ul class="cd-header-buttons px-lg-2">
                    <li>
                    <a class="cd-search-trigger" href="#cd-search">
                        <span></span>
                    </a>
                    </li>
                </ul>
                <div id="cd-search" class="cd-search">
                    <form action="#url" method="post">
                        <input name="Search" type="search" placeholder="Click enter after typing...">
                    </form>
                </div>
                <!-- //search -->
                
                <!-- toggle switch for light and dark theme -->
                <div class="cont-ser-position">
                    <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox">
                                <div class="mode-container">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div>
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>