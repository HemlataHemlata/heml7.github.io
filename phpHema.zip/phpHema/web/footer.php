<footer class="text-center">
    <div class="footer py-5">
        <div class="container py-md-4">
            <div clss="footer-logo">
                <a class="logo" href="index">
                    <!-- <i class="fab fa-asymmetrik"></i> UI Portfolio -->
                    <img src="assets/images/hh.png" alt="logo-img" style="height: 135px;">
                </a>
            </div>
            <div class="footer-contact-info mt-4">
                <ul>
                    <li>
                        <a href="tel:+91 8851150463" class="contact-text-sub">
                            <span class="fas fa-phone me-2"></span>+91 8851150463</a>
                    </li>
                    <li>
                        <a href="https://p.w3layouts.com/cdn-cgi/l/email-protection#aec7c0c8c1eecbd6cfc3dec2cb80cdc1c3" class="contact-text-sub">
                            <span class="fas fa-envelope me-2"></span><span class="__cf_email__" data-cfemail="365f58505976534e575b465a531855595b">[email&#160;protected]</span> </a>
                    </li>
                    <li>
                        <p class="contact-text-sub"> 
                            <span class="fas fa-map-marker me-2"></span>Delhi Shahdara.</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container py-4">
        <div class="row footer-grids">
            <div class="col-lg-6 copyright text-lg-start text-center align-center">
                <p>© 2024 UI Portfolio. All Rights Reserved | Design by <a href="#"> Hemlata</a> </p>
            </div>
            <div class="col-lg-6 text-lg-end text-center mt-lg-0 mt-4">
                <div class="social">
                    <ul>
                        <li><a href="#url"><span class="fab me-2 fa-facebook-f"></span></a></li>
                        <li><a href="#url"><span class="fab me-2 fa-twitter"></span></a></li>
                        <li><a href="#url"><span class="fab me-2 fa-google-plus"></span></a></li>
                        <li><a href="#url"><span class="fab me-2 fa-pinterest"></span></a></li>
                        <li><a href="#url"><span class="fab me-2 fa-vk"></span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>