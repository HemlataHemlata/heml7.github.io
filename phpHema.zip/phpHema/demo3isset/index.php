<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>demo-isset</title>
</head>
<body>

<form action="hello.php" method="post">
      <p>First Name: <input type="text" name="first_name"/> </p>
      <p>Last Name: <input type="text" name="last_name" /> </p>
      <input type="submit" value="Submit" />
   </form>

   
</body>
</html>
<?php
include('connection.php');
$hello = null;
// false because $hello is null
if (isset($hello)) {
  echo "Hello World<br>";
}

$india = 0;
// true because $india is set
if (isset($india)) {
  echo "Hello India";
}
?>