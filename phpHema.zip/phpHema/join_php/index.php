<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>join php</title>
    <?php
    include('include/link.php');
    ?>
</head>
<body>
<div class="container">
    <div class="text-center bg-secondary " >
<h1 class="text-white py-1">Personal Details</h1>
    </div>
<div class="row gutters">
<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
		<div class="account-settings">
			<div class="user-profile">
				<div class="user-avatar">
					<img src="assets/img/photo.png" alt="Photo Admin">
				</div>
				<h5 class="user-name">Simran Rajput</h5>
				<h6 class="user-email">heml21604@gmail.com</h6>
			</div>
			<div class="about">
				<h5>About</h5>
				<p>I'm Simran. Full Stack Developer I enjoy creating user-centric, delightful and human experiences. <br>
                "I bring my crazy designs to life by putting them into code."
                </p>
			</div>
		</div>
	</div>
</div>
</div>
<div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
    <form id="myform" method="POST" >
		<div class="row gutters">            
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<h6 class="mb-2 text-primary">Personal Details</h6>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="fullName">Full Name</label>
                    <input type="hidden" name="action_code" id="action_code" value="DestinationPackage">
					<input type="text" class="form-control" id="fullName" name="name" placeholder="Enter full name">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="eMail">Email</label>
					<input type="email" class="form-control" id="eMail" name="email" placeholder="Enter email ID">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="phone">Phone</label>
					<input type="text" class="form-control" id="phone" name="phone" placeholder="Enter phone number">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="website">Website URL</label>
					<input type="url" class="form-control" id="website" name="url" placeholder="Website url">
				</div>
			</div>
		</div>
		<div class="row gutters">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<h6 class="mt-3 mb-2 text-primary">Address</h6>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="Street">Street</label>
					<input type="name" class="form-control" id="Street" name="Street" placeholder="Enter Street">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="ciTy">City</label>
					<input type="name" class="form-control" id="ciTy" name="city" placeholder="Enter City">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="sTate">State</label>
					<input type="text" class="form-control" id="sTate" name="state" placeholder="Enter State">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="zIp">Zip Code</label>
					<input type="text" class="form-control" id="zIp" name="zip" placeholder="Zip Code">
				</div>
			</div>
		</div>
		<div class="row gutters">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<div class="text-right">
					<button type="button" id="submit" name="submit" class="btn btn-secondary"> <a href="fetch" style="text-decoration: none; color: aliceblue; " >show Data</a>
                        </button>
					<button type="submit" name="submit" id="submit" value="submit" class="btn btn-primary">Update</button>
				</div>
			</div>
		</div>
        </form>
	</div>
</div>
</div>
</div>
</div>

 <script type="text/javascript" >
    $(document).ready(function (e) {
 $("#myform").on('submit',(function(e) {
 	//debugger;   
  e.preventDefault();
  $.ajax({
  url: "insertphp.php", 
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   
   success: function(data)
      {
  	 if(data =='Invalid')
    {
        alert('Fail');						
    }
    else
    {
        alert('Your Information has been Submitted');
        // loadcontent();
        document.getElementById("myform").reset();
    }
      },
          
    });
 }));


});
 </script>
 
 <!-- ajax cdn  -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</body>
<?php
// include('include/footerjs.php');
?>
</html>