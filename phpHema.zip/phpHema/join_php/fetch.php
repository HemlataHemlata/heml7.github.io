<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include('include/link.php');
    ?>
    <title>Fetch data</title>
</head>

<body onload="loadcontent()">

 <!-- fetch data start -->
<script type="text/javascript">
    function loadcontent(){
        AcceptDriver('showdata');
    }
function AcceptDriver()
		{
		var AcceptId='AcceptId';
		// alert(AcceptId);
		// debugger;
		$.ajax({
		url: "showdata.php",
		method: "POST",
		data: {
		AcceptId: AcceptId,
		},
		success: function(data)
		{
		$("#showdata").html(data);
		}
		});

		}
</script>
<div id="showdata"></div>
 <!-- fetch data end -->
  
  <!-- delete start -->
  <script>
function deleted(dataid)
		{
		var dataid=dataid;
		$.ajax({
		url: "delete.php",
		method: "POST",
		data: {
            dataid: dataid,
		},
		success: function(data)
		{
        if(data=='Failed')
        {
alert('Failed')
        }
        else{
            alert('Done');
AcceptDriver(); 

        }
		}
		});

		}
  </script>
<!-- delete end -->
 <!-- update script start  -->
 <!-- <script>
function update(updid)
		{
		var updid=updid;
		$.ajax({
		url: "update.php",
		method: "POST",
		data: {
            updid: updid,
		},
		success: function(data)
		{
        if(data=='Failed')
        {
alert('Failed')
        }
        else{
            alert('Done');
AcceptDriver(); 

        }
		}
		});

		}
  </script> -->
  <!-- update script end  -->
</body>
</html>