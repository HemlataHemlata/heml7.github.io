<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data</title>
	<?php
    include('include/link.php');
    ?>
</head>
<body>

<div class="container">
    <div class="text-center bg-secondary " >
<h1 class="text-white py-1">Personal Details</h1>
    </div>
<div class="row gutters">
<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
		<div class="account-settings">
			<div class="user-profile">
				<div class="user-avatar">
					<img src="assets/img/photo.png" alt="Photo Admin">
				</div>
				<h5 class="user-name">Simran Rajput</h5>
				<h6 class="user-email">heml21604@gmail.com</h6>
			</div>
			<div class="about">
				<h5>About</h5>
				<p>I'm Simran. Full Stack Developer I enjoy creating user-centric, delightful and human experiences. <br>
                "I bring my crazy designs to life by putting them into code."
                </p>
			</div>
		</div>
	</div>
</div>
</div>
<div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
    <?php

if(isset($_GET['updid'])) {
    include('include/connection.php');
    $id=$_GET['updid'];

	 $sql = "SELECT persnl.id,persnl.personal_id,persnl.name,persnl.email,persnl.phone,persnl.url, otherd.id,otherd.personal_id,otherd.street,otherd.city,otherd.state,otherd.zipcode FROM personal_details persnl INNER JOIN other_details otherd WHERE persnl.personal_id=otherd.personal_id AND persnl.id='$id'";
	//echo $sql = "SELECT persnl,otherd FROM personal_details persnl INNER JOIN other_details otherd WHERE persnl.personal_id=otherd.personal_id AND persnl.id='$id=otherd.id='$id'";
    $result=mysqli_query($con,$sql);
    $row=mysqli_fetch_assoc($result);

 ?>
    <form method="POST" id="myform" >
		<div class="row gutters">            
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<h6 class="mb-2 text-primary">Personal Details</h6>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="fullName">Full Name</label>
                    <input type="hidden" name="action_code" id="action_code" value="DestinationPackage" value="<?php echo $row['id']; ?>">
					<input type="text" class="form-control" id="fullName" name="name" placeholder="Enter full name" value="<?php echo $row['name']; ?>" >
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="eMail">Email</label>
					<input type="email" class="form-control" id="eMail" name="email" placeholder="Enter email ID" value="<?php echo $row['email']; ?>">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="phone">Phone</label>
					<input type="text" class="form-control" id="phone" name="phone" placeholder="Enter phone number" value="<?php echo $row['phone']; ?>">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="website">Website URL</label>
					<input type="url" class="form-control" id="website" name="url" placeholder="Website url" value="<?php echo $row['url']; ?>">
				</div>
			</div>
		</div>
		<div class="row gutters">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<h6 class="mt-3 mb-2 text-primary">Address</h6>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="Street">Street</label>
					<input type="name" class="form-control" id="Street" name="Street" placeholder="Enter Street" value="<?php echo $row['street']; ?>">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="ciTy">City</label>
					<input type="name" class="form-control" id="ciTy" name="city" placeholder="Enter City" value="<?php echo $row['city']; ?>">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="sTate">State</label>
					<input type="text" class="form-control" id="sTate" name="state" placeholder="Enter State" value="<?php echo $row['state']; ?>">
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
					<label for="zIp">Zip Code</label>
					<input type="text" class="form-control" id="zIp" name="zip" placeholder="Zip Code" value="<?php echo $row['zipcode']; ?>">
				</div>
			</div>
		</div>
		<div class="row gutters">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<div class="text-right">
					<button type="submit" name="submit" id="submit" value="submit" class="btn btn-primary">Edit Update</button>
				</div>
			</div>
		</div>
        </form>
        <?php
}
?> 
	</div>
</div>
</div>
</div>
</div>   
<script type="text/javascript" >
    $(document).ready(function (e) {
 $("#myform").on('submit',(function(e) {
 	//debugger;   
  e.preventDefault();
  $.ajax({
  url: "updatedata.php", 
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   
   success: function(data)
      {
  	 if(data =='Invalid')
    {
        alert('Fail');						
    }
    else
    {
        alert('Your Information Update successful');
        // loadcontent();
        document.getElementById("myform").reset();
    }
      },
          
    });
 }));


});
 </script>
</body>
</html>