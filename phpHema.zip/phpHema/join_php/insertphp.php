<?php
if(isset($_POST['action_code']))
{ 
DestinationPackage();
}

function DestinationPackage() {

$con = mysqli_connect('localhost','root','','hema_database');
    $username=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $url=$_POST['url'];
    $Street=$_POST['Street'];
    $city=$_POST['city'];
    $state=$_POST['state'];
    $zip=$_POST['zip'];

    $maxid= "SELECT MAX(id) FROM `personal_details`";
    $max = mysqli_query($con,$maxid);
    $personal_id = mysqli_fetch_array($max);
    $res = 'personal_id' . $personal_id[0]+1;

    $sqli = "INSERT INTO `personal_details` (`personal_id`,`name`,`email`,`phone`,`url`) VALUES ('$res','$username','$email','$phone','$url')";
    $query = mysqli_query($con,$sqli);

   // second table insert data 
    if($query>0){
      $sql = "INSERT INTO `other_details` (`personal_id`,`street`,`city`,`state`,`zipcode`) VALUES ('$res','$Street','$city','$state','$zip')";
      $query1 = mysqli_query($con,$sql);

      if($query1>0){
         echo "Done";
      }
      else{
         echo "Invalid";
      }
    }
    else{
      echo "Invalid";
   }  
 
}
//}
?>


 