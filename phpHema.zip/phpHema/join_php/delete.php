<?php

if(isset($_POST['dataid'])) {
    include('include/connection.php');
    echo $id=$_POST['dataid'];
//    echo  $fire = "DELETE FROM `personal_details` WHERE `id`='$id'";
$fire = "DELETE persnl,otherd FROM personal_details persnl INNER JOIN other_details otherd WHERE persnl.personal_id = '$id' AND otherd.personal_id='$id'";
$result = mysqli_query($con,$fire);
// echo mysqli_error($con);
    if($result>0){
        echo "Records deleted successfully";
    }
    else{
        echo "Failed";
    }

}
 ?>