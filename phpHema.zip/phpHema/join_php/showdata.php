<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include('include/link.php');
    ?>
    <title>Fetch data</title>
</head>

<body>
<?php
include('include/connection.php');
if(isset($_POST['AcceptId'])){
    $var=$_POST['AcceptId'];

?>
<section class="container mt-5">
 <div class="row">
    <div class="col-md-12">
<div class="card">
    <div class="card-header d-flex" style="justify-content: space-between;" >
        <h4>Personal Details</h4>
        <button onclick="history.go(-1)" type="button" class="btn btn-secondary">Go Back</button>
    </div>
    <div class="card-body">
        <table class="table text-center">
  <thead>
    <tr>
      <th>Serial no.</th>
      <th>Personal_id</th>
      <th>Name</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Url</th>
      <th>Address</th>
      <th>City</th>
      <th>State</th>
      <th>ZipCode</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
        include('include/connection.php');


		$i=1;
      // Fetch data from the database
                // $query = "SELECT * FROM `personal_details`"; 
                 $query="SELECT persnl.personal_id,persnl.name,persnl.email,persnl.phone,persnl.url, otherd.id,otherd.personal_id,otherd.street,otherd.city,otherd.state,otherd.zipcode FROM personal_details persnl INNER JOIN other_details otherd WHERE persnl.personal_id=otherd.personal_id ORDER BY persnl.id DESC";
                $result = mysqli_query($con, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
					echo "<td>" . $i++ . "</td>";
                    echo "<td>" . $row['personal_id'] . "</td>";
					echo "<td>" . $row['name'] . "</td>";
					echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['phone'] . "</td>";
                    echo "<td>" . $row['url'] . "</td>";
                    echo "<td>" . $row['street'] . "</td>";
                    echo "<td>" . $row['city'] . "</td>";
                    echo "<td>" . $row['state'] . "</td>";
                    echo "<td>" . $row['zipcode'] . "</td>";
                     ?>
                     <td class="d-flex"> <a href="update?updid=<?php echo $row['id'] ?>"> <button type="button" class="btn btn-primary"><i class="fa fa-edit"></i></button></a> &nbsp;
                <button type="button" class="btn btn-danger" onclick="deleted('<?php echo $row ['personal_id'];?>')"><i class="fa fa-trash"></i></button>
              </td> 
                    
                   <?php echo "</tr>";
                }
                ?>
  </tbody>
</table>
    </div>
</div>
    </div>
 </div>
</section>
<?php
}
 ?>

</body>
</html>