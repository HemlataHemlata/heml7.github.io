<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>demo-isset</title>
</head>
<body>

<form action="hello.php" method="post">
      <p>First Name: <input type="text" name="first_name"/> </p>
      <!-- <p>Last Name: <input type="text" name="last_name" /> </p> -->
      <p>Email: <input type="text" name="email"/></p>
      <p>Phone: <input type="text" name="phone"/></p>
      <!-- <p>Message: <input type="text" name="message"/></p> -->
      <input type="submit" value="Submit" name="submitbutton"/>
   </form>

</body>
</html>
<?php
include('connection.php');
if(isset($_POST['submitbutton'])){

$name=$_POST['first_name'];
// $lastname=$_POST['last_name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
// $message=$_POST['message'];
// echo "$name";
// echo "$email";
// echo "$phone";
// echo "$message";
// echo "$lastname";
$query="INSERT INTO `self-detail` (`name`, `email`, `phone`) VALUES('$name', '$email', '$phone')";
$result=mysqli_query($conn,$query);
if($result){
echo " data inserted";
}
else{
   echo "data is not inserted";
}
// show data from database
// echo "<br> id: ". $row["id"]. " - Name: ". $row["firstname"]. " " . $row["email"] . "<br>" . $row["phone"] . "<br>" . $row["message"] . "<br>";
}
$sql="SELECT * FROM `self-detail` ORDER BY `id` DESC";
$result1=mysqli_query($conn,$sql);
foreach($result1 as $row){
   echo "<br> id: ". $row["id"]. "<br>". " - Name: ". $row["name"]. "<br> ". " - Email: " . $row["email"] . "<br>" . " - phone: "  . $row["phone"] . "<br>" ."<br>";
}
?>