<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Display Data from Database</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- ajax cdn  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <h1>Data from Database</h1>
        <table class="table table-bordered" id="datatable" >
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone Number </th>
                    <!-- <th>Message</th> -->
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include('connection.php');

                // Fetch data from the database
                $query = "SELECT * FROM `self-details` ORDER BY `id` DESC"; // Replace 'eventvilla' with your table name
                // $sql="SELECT * FROM `eventvilla` ORDER BY `id` DESC";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['phone'] . "</td>";
                    // echo "<td>" . $row['MESSAGE'] . "</td>"; ?>
                    <td><a href='?id=<?php echo $row['id']?>'> <button>Delete</button> </a> &nbsp; 
                    <a href="?UDTId=<?php echo $row['id'] ?>"><button>Update</button></a> </td>
                   <?php echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="https://rzp.io/i/BRBHARkR4"  id="btnstart" type="button" ><button>Payment</button></a> 
         <button onclick="start()" id="btnstart" type="button">Download</button>
    </div>
    <script type="text/javascript" >
function start(){
    alert();
    $("#datatable").table2excel({
        filename: "Alldata.xls"
    });
}
    </script>
   

    <?php
    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $sql="DELETE FROM `self-details` WHERE `id`='$id'";
        $result=mysqli_query($conn,$sql);
        if($result>0)
        {
            echo "
            <script>
           alert('Done');
           window.location.href='table.php';
            </script>
            ";
        }
        else{
            echo "Fail  ";
        }
    }
    if(isset($_GET['UDTId']))
    {
        $id=$_GET['UDTId'];
        $sql="SELECT * FROM `self-details` WHERE `id`='$id'";
        $result=mysqli_query($conn,$sql);
        $row=mysqli_fetch_assoc($result); ?>
<form action="#" method="post">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
      <p>First Name: <input type="text" name="first_name" value="<?php echo $row['name']; ?>"/> </p>
      <!-- <p>Last Name: <input type="text" name="last_name" /> </p> -->
      <p>Email: <input type="text" name="email" value="<?php echo $row['email']; ?>"/></p>
      <p>Phone: <input type="text" name="phone" value="<?php echo $row['phone']; ?>"/></p>
      <!-- <p>Message: <input type="text" name="message" value="<?php // echo $row['MESSAGE']; ?>"/></p> -->
      <input type="submit" value="Submit" name="updatebutton"/>
   </form>

<?php
    }
    if(isset($_POST['updatebutton'])){
        $id=$_POST['id'];
        $name=$_POST['first_name'];
        $EMAIL=$_POST['email'];
        $phone=$_POST['phone'];
        // $message=$_POST['message'];
        $update="UPDATE `self-details` SET `name`='$name', `email`='$EMAIL', `phone`='$phone' WHERE `id`='$id'";
        $result=mysqli_query($conn,$update);
         
        if($result>0)
        {
            echo "
            <script>
           alert('Done');
           window.location.href='table.php';
            </script>
            ";
        }
        else{
            echo "Fail  ";
        }
    }
    ?>
    <!-- Include Bootstrap JS -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="table2excel.js" type="text/javascript"></script>
</body>
</html>
