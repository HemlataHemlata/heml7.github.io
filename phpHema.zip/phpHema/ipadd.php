<style>
    div{
        border: 1px solid blueviolet;
        padding: 10px;
        width: 350px;
    }
</style> 
<!-- find ip address with php code -->
<div>
<?php
$host = gethostname();
$ip = gethostbyname($host);
echo "Server IP address: $ip";
?>
</div>
</br>

<!-- find oerating system with php  -->
<!-- The php_uname() function returns a string containing information about the operating system, including the machine type, release, and version. -->
<div>
<?php
$os = php_uname();
echo "Operating System: $os";
?>
</div>
</br>

<!-- find wifi name -->
<div>
<?php
$ip = "192.168.1.13"; // Replace with the IP address of your router or gateway
$command = "nbtstat -A $ip";
$output = exec($command);
echo "Local machine name: $output";
?>
</div>
</br>

<!-- find current time and date -->
<div>
<?php
$currentDateTime = date('Y-m-d H:i:s');
echo "Current date and time: $currentDateTime";
?>
</div>

<!-- start right click disable script  -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
   $(document).bind("contextmenu",function(e){
      return false;
   });
});
</script>
<!-- end right click disable script  -->
