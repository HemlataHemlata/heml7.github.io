<?php
   echo "<h3>First Name: " . $_GET['first_name'] . "<br />" . 
   "Last Name: " . $_GET['last_name'] . "</h3>";
?>