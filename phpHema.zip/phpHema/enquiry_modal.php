 
 
 <!-- enquiry modal -------------------------------- -->
<?php //include 'inc/myMsg.php'; ?>
 <style>
     .enquiry-modal {
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         width: 100%;
         background: rgba(0, 0, 0, 0.6);
         height: 100%;
         position: fixed;
         left: 50%;
         transform: translate(-50%, -50%) scale(0.1);
         visibility: hidden;
         top: 50%;
         transform: translate(-50%, -50%) scale(1);
         z-index: 125485456;
         box-shadow: 0px 0px 5px #ffffff;
     }

     .enquiry-modal .inner-body {
         width: 350px;
         background-color: #FFFFFF;
         margin: auto;
         margin-top: 100px;
         padding: 15px;
         border-radius: 4px;
     }

     .enquiry-modal .inner-body h4 {
         color: #1F3A6F;
         text-align: center;
         font-weight: bold;
     }

     .enquiry-modal .inner-body p {
         text-align: center;
         margin-top: 10px;
         margin-bottom: 20px;
         font-weight: 500;
     }

     .enquiry-modal .inner-body input[type='text'],
     input[type='email'] {
         height: 42px;
         margin-bottom: 15px;
     }

     .enquiry-modal .inner-body textarea {
         height: 42px;
         margin-bottom: 15px;
     }

     .enquiry-modal .inner-body button {
         border: 2px solid #1F3A6F;
         background: #1F3A6F;
         outline: none;
         padding: 8px 30px 8px 30px;
         color: white;
     }

     .open-enquiry-modal {
         visibility: visible;
     }

     .enquiry-modal i {
         color: #1F3A6F;
     }
 </style>

 <div class="enquiry-modal" id="enquiry">
     <div class="inner-body">
         <h4>
             ENQUIRY FORM <br>
         </h4>
         <p style="line-height: 21px;">
             If You have any queries, <br> kindly take a moment to fill up this form
         </p>
         <form id="modalEnquiry" method="POST">
             <input name="name" type="text" class="form-control" placeholder="Enter your name*" required 
             style="border: 1.5px solid #1F3A6F;">
             <input name="email" type="email" class="form-control" placeholder="Enter your Email*" required 
             style="border: 1.5px solid #1F3A6F;">
             <input name="mobile" type="text" class="form-control" placeholder="Enter your Mobile*" required 
             style="border: 1.5px solid #1F3A6F;" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
             <textarea name="msg" class="form-control" cols="30" rows="2" placeholder="Enter your Message*" required 
             style="border: 1.5px solid #1F3A6F;"></textarea>

             <input type="hidden" name="category" value="Enquiry Modal">
             <input type="hidden" name="sub_category" value="General Enquiry">
             <input type="hidden" name="submitNewEnquiry" value="OK">

             <button id="modalBtn" type="submit" name="modal_enq" >Submit</button>
             <button style="border: 2px solid #1F3A6F; background: transparent; color: black" 
             onclick="closeEnquiryModal()">Close</button>
         </form>
     </div>
 </div>


 <script>
     function openEnquiryModal() {
         let popup = document.getElementById("enquiry");
         popup.classList.add("open-enquiry-modal");
     }

     function closeEnquiryModal() {
         let popup = document.getElementById("enquiry");
         popup.classList.remove("open-enquiry-modal");
     }
 </script>



 

 <!-- *************************************** Career Form********************************************************* -->
 
 <div class="enquiry-modal" id="career">
     <div class="inner-body">
         <h4>
             Submit Your Resume <br>
         </h4>
         <p style="line-height:4px;">
             <br />
         </p>
         <form id="modalCareer" method="post" enctype="multipart/form-data">
             <input name="name" type="text" class="form-control" placeholder="Enter your name*" required 
             style="border: 1.5px solid #1F3A6F;">
             <input name="email" type="email" class="form-control" placeholder="Enter your Email*" required 
             style="border: 1.5px solid #1F3A6F;">
             <input name="mobile" type="text" class="form-control" placeholder="Enter your Mobile*" required 
             style="border: 1.5px solid #1F3A6F;" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
             <input name="subject" type="text" class="form-control"  placeholder="Enter your Subject*" required 
             style="border: 1.5px solid #1F3A6F;">
              <input name="Resume" type="file" class="form-control"  required 
             style="border: 1.5px solid #1F3A6F;" accept="application/pdf" placeholder="Resume"><br />
             <button id="modalBtn" type="submit" name="career_enq">Submit</button>
             <button style="border: 2px solid #1F3A6F; background: transparent; color: black" 
             onclick="closeCareerModal()">Close</button>
         </form>
     </div>
 </div>

 <script>
     function openCareerModal() {
         let popup = document.getElementById("career");
         popup.classList.add("open-enquiry-modal");
     }

     function closeCareerModal() {
         let popup = document.getElementById("career");
         popup.classList.remove("open-enquiry-modal");
     }
 </script>


 <!-- *************************************** product zoom********************************************************* -->
 
 <div class="enquiry-modal" id="zoom_pro" >
     <div class="inner-body" style="height: 400px; width: 400px;">
         
          <h3 onClick="closezoomModal()" style="cursor: pointer;">x</h3>
    <div class="inner-body">
      <img id="vsl-popup-image" src="" alt="Star Beta" style="height:350px; width: 350px; margin-top:-130px;">
    </div>
     </div>
 </div>

 <script>
     function openzoomModal(img) {
         let popup = document.getElementById("zoom_pro");
		  document.getElementById("vsl-popup-image").src = img;
         popup.classList.add("open-enquiry-modal");
     }

     function closezoomModal() {
         let popup = document.getElementById("zoom_pro");
         popup.classList.remove("open-enquiry-modal");
     }
 </script>


 <?php
if(isset($_POST['modal_enq']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$msg=$_POST['msg'];
	$today=date('Y-m-d');
	$sql="INSERT INTO `starbeta_modal`(`name`, `email`, `mobile`, `message`, `date`) 
	VALUES ('$name','$email','$mobile','$msg','$today')";
	$result=mysqli_query($mysqli,$sql);
	if($result>0)
	{
		echo "
		<script>
		alert('Your inquiry has been successfully inserted. Admin will contact you soon.');
		window.location.href='index';
		</script>
		";
	}
	else
	{
		echo "
		<script>
		alert('Sorry!  Try Again');
		window.location.href='index';
		</script>
		";
		
	}
}

if(isset($_POST['career_enq']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$subject=$_POST['subject'];
	$today=date('Y-m-d');	
	$target_dir = "Student-Pdf/"; 
	$filecount =1;
	$files = glob($target_dir . "*");
	if ($files)
	{
	$filecount = count($files)+1;
	}
	$encode=$today.time();
	$final="StarBeta-Career-".base64_encode($encode)."-".$filecount;
	$pdf_file = $final.'.pdf'; 
	$pdf_file1 ="Student-Pdf/".$final.'.pdf';
	$uOk = 1; 
	move_uploaded_file($_FILES["Resume"]["tmp_name"],$pdf_file1);

	$sql="INSERT INTO `starbeta_career`(`name`, `email`, `mobile`, `subject`, `pdf_url`, `date`) 
	VALUES ('$name','$email','$mobile','$subject','$pdf_file','$today')";
	$result=mysqli_query($mysqli,$sql);
	if($result>0)
	{
		echo "
		<script>
		alert('Your Resume has been successfully inserted. Admin will contact you soon.');
		window.location.href='index';
		</script>
		";
	}
	else
	{
		echo "
		<script>
		alert('Sorry!  Try Again');
		window.location.href='index';
		</script>
		";
		
	}
}
?>

 <!-- ******************************************************************************************************************************** -->
 
 
