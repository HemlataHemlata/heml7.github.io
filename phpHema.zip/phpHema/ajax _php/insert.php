<?php
include('connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- bootstrap css cdn  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- ajax cdn  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <title>Ajax php</title>
</head>
<body onload="loadcontent()">

<div class="container"><br>
<h1 class="text-center">Insert Data Using Ajax</h1>
<br>
<div class="col-lg-8 m-auto">
<form  id="myform" method="post">
    <div class="form-group mt-3">
<label>Username</label>
<input type="hidden" name="action_code" id="action_code" value="DestinationPackage">
<input type="text" name="username" class="form-control">
    </div>
    <div class="form-group mt-3">
<label>Password</label>
<input type="text" name="password" class="form-control">
    </div>
    <input type="submit" name="submit" id="submit" value="submit" class="btn btn-success mt-3">
</form>

</div>

</div>
<!-- fetch data script start -->
<script type="text/javascript">
    function loadcontent(){
        AcceptDriver('showdata');
    }
function AcceptDriver()
		{
		var AcceptId='AcceptId';
		// alert(AcceptId);
		// debugger;
		$.ajax({
		url: "fetch.php",
		method: "POST",
		data: {
		AcceptId: AcceptId,
		},
		success: function(data)
		{
		$("#showdata").html(data);
		}
		});

		}
</script>
<div id="showdata"></div>

<script type="text/javascript">
// $(document).ready(function(){
// var form = $('myform');
// $('#submit').click(function(){
// $.ajax({ 
// url : form.attr("action"),
// type : 'post',
// data : $("#myform input").serialize(),
// success: function(data){
//     console.log(data);
// }
// });
// });
// });
$(document).ready(function (e) {
 $("#myform").on('submit',(function(e) {
 	//debugger;   
  e.preventDefault();
  $.ajax({
  url: "insertphp.php", 
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   
   success: function(data)
      {
  	 if(data =='Invalid')
    {
        alert('Fail');						
    }
    else
    {
        // alert('Done');
        loadcontent();
        document.getElementById("myform").reset();
    }
      },
          
    });
 }));
});


// delete start
function deleted(dataid)
		{
		var dataid=dataid;
		$.ajax({
		url: "fetch.php",
		method: "POST",
		data: {
            dataid: dataid,
		},
		success: function(data)
		{
        if(data=='Failed')
        {
alert('Failed')
        }
        else{
            alert('Done');
AcceptDriver(); 

        }
		}
		});

		}
// delete end
</script>

<!-- bootstrap js cdn  -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>