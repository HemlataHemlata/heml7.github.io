<?php
if(isset($_POST['action_code']))
{ 
DestinationPackage();
}

function DestinationPackage() {

$con = mysqli_connect('localhost','root','','ajax');
// mysqli_select_db($con,'ajax');
// extract($_POST);
//if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $sqli = "INSERT INTO `ajaxinsert` (`name`,`password`) VALUES ('$username','$password')";
    $query = mysqli_query($con,$sqli);
 if($query>0){
    echo "Done";
 }
 else{
    echo "Invalid";
 }
}
//}
?>


 