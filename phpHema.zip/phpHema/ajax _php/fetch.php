<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- bootstrap css cdn  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- ajax cdn  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <title>Ajax php</title>
</head>
<?php
include('connection.php');
if(isset($_POST['AcceptId'])){
    $var=$_POST['AcceptId'];

?>
<body>
<section class="container mt-5">
 <div class="row">
    <div class="col-md-12">
<div class="card">
    <div class="card-header">
        <h4>show data</h4>
    </div>
    <div class="card-body">
        <table class="table text-center">
  <thead>
    <tr>
      <th>S no.</th>
      <th>Name</th>
      <th>Password</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
        include('connection.php');
		$i=1;
      // Fetch data from the database
                $query = "SELECT * FROM `ajaxinsert`"; 
                $result = mysqli_query($con, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
					echo "<td>" . $i++ . "</td>";
					echo "<td>" . $row['name'] . "</td>";
					echo "<td>" . $row['password'] . "</td>";
                     ?>
                     <td><button type="button" class="btn btn-primary">Update</button>
                <button type="button" class="btn btn-danger" onclick="deleted(<?php echo $row ['id'];?>)">Delete</button>
              </td> 
                    
                   <?php echo "</tr>";
                }
                ?>
  </tbody>
</table>
    </div>
</div>
    </div>
 </div>
</section>
<?php
}
elseif(isset($_POST['dataid'])) {
    include('connection.php');
    echo $id=$_POST['dataid'];
   echo  $fire = "DELETE FROM `ajaxinsert` WHERE `id`='$id'";
    $result = mysqli_query($con,$fire);
echo mysqli_error($con);
    if($result>0){
        echo "Done";
    }
    else{
        echo "Failed";
    }

}
 ?>
 <!-- bootstrap js cdn  -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>