<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hotel-booking-task</title>
    <!-- bootstra cdn  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
    <main>
        <section class="py-5" >
            <div class="container" >
                <div class="header text-center " >
<h3>Hotel Reservation Form</h3>
<p>Please complete the form below.</p>
                </div>
            <form id="myform" method="POST">
                <div class="row">
    <div class="mb-3 col-md-6 ">
    <label class="form-label">Name*</label>
    <input type="text" name="name" class="form-control" placeholder="Enter Your Name" required>
  </div>
  <div class="mb-3 col-md-6">
    <label class="form-label">Email*</label>
    <input type="email" name="email" class="form-control" placeholder="@gmail.com" required>
  </div>
  <div class="mb-3 col-md-6 ">
    <label class="form-label">Phone*</label>
    <input name="phone" type="text" class="form-control" placeholder="Enter your Mobile" required 
             oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
  </div>
  <div class="mb-3 col-md-6 ">
    <label class="form-label">Number of Guests*</label>
    <input type="number" name="guest" class="form-control" required >
  </div>
  <div class="mb-3 col-md-6 ">
    <label class="form-label">Arrival Date & Time*</label>
    <input type="date" name="arrival" class="form-control" value="<?php echo date("Y-m-d") ?>" required>
  </div>
  <div class="mb-3 col-md-6 ">
    <label class="form-label">Departure Date & Time*</label>
    <input type="date" name="departure" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">No. of Rooms*</label>
    <input type="number" name="room" class="form-control" required>
  </div>  
  </div>
  <button type="submit" name="submit" id="submit" value="submit" class="btn btn-success">Submit</button>
</form>
            </div>
        </section>
    </main>
    <?php
include('connection.php');
if(isset($_POST['submit'])){

$name=$_POST['name'];
$arrival= date('Y-m-d', strtotime($_POST['arrival'])) ;
$departure= date('Y-m-d', strtotime($_POST['departure']));
$guest=$_POST['guest'];
$room=$_POST['room'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$status="Booked";
$totalroom=5;
$query1 = "select * from hotel_booking where `status`='$status' AND `departure` between '$arrival' AND '$departure'";
$result=mysqli_query($con,$query1);
if ($result->num_rows > 0) {
    echo "Room is not available for the selected dates.";
  }
  else{
    $query2 = "select SUM(no_rooms) from hotel_booking where status='$status' AND `departure` between '$arrival' AND '$departure'";
    $result=mysqli_query($con,$query2);
    $res1= mysqli_fetch_array($result);
    echo $res2= $res1[0];
    
 $query="INSERT INTO `hotel_booking` (`name`, `email`, `phone`,`no-guests`,`arrival`,`departure`,`no-rooms`,`status`,`total_room`) VALUES('$name', '$email', '$phone','$guest','$arrival','$departure','$room','$status','$totalroom')";
$result=mysqli_query($con,$query);
if($result){
  echo mysqli_error($con);
echo " <script>
           alert('the data has been inserted.');
            </script>";
}
else{
   "<script>
   alert('Data not inserted')
   </script>";
}
  }
}
    ?>
    <!-- bootstrap js cdn  -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>